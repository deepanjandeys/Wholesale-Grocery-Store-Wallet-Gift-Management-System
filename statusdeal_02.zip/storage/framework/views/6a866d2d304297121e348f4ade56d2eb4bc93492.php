;
<?php $__env->startSection('page_title','Customer Negative Balance Warning List'); ?>
<?php $__env->startSection('Customer_select','active'); ?>
<?php $__env->startSection('container'); ?>
<?php echo e($AJAX_ROOT=Config::get('constants.AJAX_ROOT')); ?>

<section class="get_in_touch">
        <h1 class="title">Customer Negative Balance List</h1>
        
        <div class="container d-none">
          <form id="myForm">
        
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Search</label>
              </div>
              <div class="form-field col-lg-9">
              <input type="search" name="search" placeholder="customer name/mobile/address" class="input-text" value="">
              </div>
              <div class="form-field col-lg-1">
                <input type="submit" name="search-btn" class="btn btn-primary" value="search">
              </div>
            </div>
       
            </form>
          </div>
    </section>
    <div class="container">
            <div class="contact-form row">
              <div class="col-lg-8 overflow-scroll">
                <h4>List of Customer with Negative Balance </h4>
                <table class="table table-responsive table-dark table-light">
                  <tr> 
                     
                    <th>
                      Cust id
                    </th>
                    <th>
                      Customer Name
                    </th>
                    <th>
                      Mobile No.
                    </th>
                    <th>
                      Balance
                    </th>
                    <th>
                      Credit limit
                    </th>
                  </tr>
                  <?php if(count($customers)>0): ?>
                  <?php 
                  $today=strtotime(date('d-m-Y'));
                  ?>
                  <tbody>
                                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                           
                                                <td><?php echo e($list->id); ?></td>
                                                <td><?php echo e($list->name); ?></td>
                                                <td><?php echo e($list->mobile); ?></td>
                                                <td style="text-align:right;"><?php echo e($list->balance); ?></td>
                                                <td style="text-align:right;">
                                                  <?php echo e($list->credit_limit); ?>

                                                </td>
                                              </tr>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                      <?php else: ?>
                      <tbody>
                        <tr>
                          <td colspan="10">Nothing to show</td>
                        </tr>
                      </tbody>
                      <?php endif; ?>
                </table>
                <form action="<?php echo e(route('admin.sendNegtiveBalanceWarning')); ?>" method="post">
                <?php echo csrf_field(); ?> <input type="submit" class="btn btn-primary" value="Send Alert Message" /></form>
              </div>
              <div class="col-lg-4 overflow-scroll">
                <h4>Last Sent Messages</h4>
                <table class="table table-responsive table-dark table-light">
                  <tr> 
                     
                    <th>
                      id
                    </th>
                    <th>
                      Month
                    </th>
                    <th>
                      Year
                    </th>
                    <th>
                      Date Time
                    </th>
                  </tr>
                  <?php if(count($lastMonthAlert)>0): ?>
                  
                  <tbody>
                                            <?php $__currentLoopData = $lastMonthAlert; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                           
                                                <td><?php echo e($list->id); ?></td>
                                                <td><?php echo e($list->name); ?></td>
                                                <td><?php echo e($list->year); ?></td>
                                                <td><?php echo date('d-M-y h:i:s A',strtotime($list->date_time));?></td>
                                                </tr>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                      <?php else: ?>
                      <tbody>
                        <tr>
                          <td colspan="10">Nothing to show</td>
                        </tr>
                      </tbody>
                      <?php endif; ?>
                </table>
                
              </div>
            </div>
            
            
        </div>
<script type="text/javascript">
  function setDefaultPassword(id) {
    if (confirm("do You want to reset password to default password !") == false) 
    {
  return;
    } 
   $.ajax({
    type: "POST",
    url: '<?php echo e($AJAX_ROOT); ?>/admin/setDefaultPassword',
    data: { id: id, _token: '<?php echo e(csrf_token()); ?>' },
    success: function (data) 
    {
        //console.log(' ** '+ data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
            $('#divPwd'+id).html(obj.msg);
           
            }
        else
        {
            $('#divPwd'+id).html('');
           
        }
    
    },
    error: function (data, textStatus, errorThrown) {
        console.log(data+' '+textStatus+' '+errorThrown);
 
    },
});
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\statusdeal\resources\views/admin/customerLastMonthAlert.blade.php ENDPATH**/ ?>