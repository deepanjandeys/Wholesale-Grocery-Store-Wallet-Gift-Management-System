;
<?php $__env->startSection('page_title','Edit API Key'); ?>
<?php $__env->startSection('setting_select','active'); ?>
<?php $__env->startSection('container'); ?>
<h2 class="title-1 m-b-10">API Key</h2>
<a href="<?php echo e(url('admin/dashboard')); ?>" >
<button type="button" class="btn btn-success" title="Back"><i class="bi bi-box-arrow-left"></i></button>
</a>
         <div class="row m-t-30">
                            
                                <div class="col-lg-12">
                                    
                                <div class="card bg-dark text-light">
                                    <div class="card-body">
                                        <form action="<?php echo e(route('manage_apikey_process')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group mb-2">
                                                <label for="key" class="control-label mb-1">key</label>
                                                <input id="key" name="key" type="text" value="<?php echo e($key); ?>" class="form-control" aria-required="true" aria-invalid="false" readonly >
                                                
                                                    <?php $__errorArgs = ['key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger" role="alert">
                                                    <?php echo e($message); ?>

                                                    </div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                
                                            </div>
                                            <?php if($key==''): ?>
                                             <button id="key-button" name="submit" type="submit" class="btn btn-lg btn-info btn-block">
                                                    Generate Key
                                                </button>
                                             <input type="hidden" name="submit_type" value="gen">   
                                            <?php else: ?>

                                                <button id="key-button" name="submit" type="submit" class="btn btn-lg btn-info btn-block">
                                                    Re-generate Key
                                                </button>
                                            <input type="hidden" name="submit_type" value="re-gen">
                                             <?php endif; ?>
                                            <?php if($active==1): ?>
                                            <label for="active" class="control-label mb-1">active</label>
                                            <?php else: ?> 
                                             <label for="active" class="control-label mb-1">in active</label>
                                            <?php endif; ?>

                                            <label for="created_at" class="control-label mb-1">created_at <?php echo e($created_at); ?></label>
                                           
                                            <div class="form-group d-none">
                                                <label for="active" class="control-label mb-1">active</label>
                                                <input id="active" name="active" type="text" value="<?php echo e($active); ?>" class="form-control" aria-required="true" aria-invalid="false" class="d-none" >
                                                    <?php $__errorArgs = ['active'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger" role="alert">
                                                    <?php echo e($message); ?>

                                                    </div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="form-group d-none">
                                                <label for="created_at" class="control-label mb-1">created_at <?php echo e($created_at); ?></label>
                                                <input id="created_at" name="created_at" type="text" value="<?php echo e($created_at); ?>" class="form-control" aria-required="true" aria-invalid="false" class="d-none" >
                                                    <?php $__errorArgs = ['created_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger" role="alert">
                                                    <?php echo e($message); ?>

                                                    </div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            
                                            <div class="d-none">
                                                <input type="hidden" name="name" value="<?php echo e($name); ?>">
                                                <button id="callback-button" type="submit" class="btn btn-lg btn-info btn-block">
                                                    Submit
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\test.mt\api\resources\views/admin/edit_APIkey.blade.php ENDPATH**/ ?>