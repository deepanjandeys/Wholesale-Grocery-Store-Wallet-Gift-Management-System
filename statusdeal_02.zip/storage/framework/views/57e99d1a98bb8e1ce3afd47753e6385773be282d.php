;
<?php $__env->startSection('page_title','Dashboard'); ?>
<?php $__env->startSection('dashboard_select','active'); ?>
<?php $__env->startSection('container'); ?>

<section class="get_in_touch">
        <h1 class="title"><?php echo e(Config::get('constants.SITE_NAME')); ?> Sign Up</h1>
        <form action="<?php echo e(route('cust.signUp')); ?>" method="post">
            <?php echo csrf_field(); ?>
        <div class="container">
          <?php if(session('error')): ?>
<div class="alert alert-danger"><?php echo e(session('error')); ?></div>
<?php endif; ?>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="name" class="label">Name </label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="name" id="name" class="input-text" value="<?php echo e(old('name')); ?>">
                  
              </div>

              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Mobile No.</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="number" name="mobile" id="mobile" class="input-text" value="<?php echo e(old('mobile')); ?>">
                   
              </div>
            </div>
            <div class="row">
              <div class="col-lg-6">
              <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <div class="alert alert-danger" role="alert">
                    <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="col-lg-6">
              <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <div class="alert alert-danger" role="alert">
                    <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

              </div>
            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="DateOfBirth" class="label">Date Of Birth</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="DateOfBirth" id="DateOfBirth" class="input-text" value="<?php echo e(old('DateOfBirth')); ?>">
                   
              </div>

              <div class="form-field col-lg-2">
                  <label for="password" class="label">password</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="password" name="password" id="password" class="input-text" value="<?php echo e(old('password')); ?>">
                   
              </div>
            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="email" class="label">email</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="email" id="email" class="input-text" value="<?php echo e(old('email')); ?>">
                   
              </div>

              <div class="form-field col-lg-2">
                  <label for="gender" class="label">gender</label>
              </div>
              <div class="form-field col-lg-4">
                <select name="gender" class="input-text">
                  <option value="0"></option>
                  <option value="1">Male</option>
                  <option value="2">Female</option>
                  <option value="3">Other</option>
                </select>
                   
              </div>
            </div>
            <div class="row">
              <div class="col-lg-6"><?php $__errorArgs = ['DateOfBirth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <div class="alert alert-danger" role="alert">
                    <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
              <div class="col-lg-6">
              <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <div class="alert alert-danger" role="alert">
                    <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                <label for="address" class="label">address</label>
              </div>
              <div class="form-field col-lg-10">
                <textarea id="address" name="address" class="input-text"><?php echo e(old('address')); ?></textarea>
                 
              </div>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <div class="alert alert-danger" role="alert">
                    <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="contact-form row">
              
               <div class="form-field col-lg-6">
                Are you existing Customer, <a href="/customer">Login</a> here
               </div>
               <div class="form-field col-lg-6">
                <input type="hidden" name="id" value="0">
                <input class="submit-btn" type="submit" value="Submit" name="Submit">
               </div>
            </div>
        </div>
      </form>
    </section>
<script>

    $('#DateOfBirth').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

    $('#DateOfBirth').val('');
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\statusdeal\resources\views/admin/sign_up.blade.php ENDPATH**/ ?>