;
<?php $__env->startSection('page_title','Dashboard'); ?>
<?php $__env->startSection('dashboard_select','active'); ?>
<?php $__env->startSection('container'); ?>
<?php echo e($AJAX_ROOT=Config::get('constants.AJAX_ROOT')); ?>

<section class="get_in_touch">
        <h1 class="title"><?php echo e(Config::get('constants.SITE_NAME')); ?> Customer Edit</h1>
        <form action="<?php echo e(route('admin.customer_process')); ?>" method="post">
            <?php echo csrf_field(); ?>
        <div class="container">
          <?php if(session('error')): ?>
<div class="alert alert-danger"><?php echo e(session('error')); ?></div>
<?php endif; ?>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="name" class="label">Name </label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="name" id="name" class="input-text" value="<?php echo e($name); ?>">
                  
              </div>

              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Mobile No.</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="number" name="mobile" id="mobile" class="input-text" value="<?php echo e($mobile); ?>" readonly>
                   
              </div>
            </div>
            <div class="row">
              <div class="col-lg-6">
              <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <div class="alert alert-danger" role="alert">
                    <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="col-lg-6">
              <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <div class="alert alert-danger" role="alert">
                    <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

              </div>
            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="DateOfBirth" class="label">Date Of Birth</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="DateOfBirth" id="DateOfBirth" class="input-text" value="<?php echo e($DateOfBirth); ?>">
                   
              </div>

              <div class="form-field col-lg-2">
                  <label for="password" class="label">password</label>
              </div>
              <div class="form-field col-lg-4">
              <a href="javascript:void(0)" 
                  onclick="setDefaultPassword(<?php echo e($id); ?>)">Reset Password</a>
                  <div id="divPwd<?php echo e($id); ?>"></div>
                </div>
            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="email" class="label">email</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="email" id="email" class="input-text" value="<?php echo e($email); ?>">
                   
              </div>

              <div class="form-field col-lg-2">
                  <label for="gender" class="label">gender</label>
              </div>
              <div class="form-field col-lg-4">
                <?php 
                $a='selected';
                $b='';
                $c='';
                $d='';

                if($gender=='1')
                  $b='selected';
                elseif ($gender=='2') 
                  $c='selected';
                elseif ($gender=='3')
                  $d='selected';
                ?>

                <select name="gender" class="input-text">
                  <option value="0" <?php echo e($a); ?>></option>
                  <option value="1" <?php echo e($b); ?>>Male</option>
                  <option value="2" <?php echo e($c); ?>>Female</option>
                  <option value="3" (($d}}>Other</option>
                </select>
                   
              </div>
            </div>
            <div class="row">
              <div class="col-lg-6"><?php $__errorArgs = ['DateOfBirth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <div class="alert alert-danger" role="alert">
                    <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
              <div class="col-lg-6">
              <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <div class="alert alert-danger" role="alert">
                    <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                <label for="address" class="label">Address</label>
              </div>
              <div class="form-field col-lg-10">
                <textarea id="address" name="address" class="input-text"><?php echo e($address); ?></textarea>
                 
              </div>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <div class="alert alert-danger" role="alert">
                    <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
                        <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="name" class="label">Approved </label>
              </div>
              <div class="form-field col-lg-4">
                  <select id="isApproved" name="isApproved" class="input-text"aria-required="true" aria-invalid="false" required>
                                                        <?php $__currentLoopData = $approves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($isApproved==$list->id): ?>
                                                        <option selected value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
                                                            <?php else: ?>
                                                        <option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                           
                                                    <?php $__errorArgs = ['isApproved'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger" role="alert">
                                                    <?php echo e($message); ?>

                                                    </div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  
              </div>

              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Status</label>
              </div>
              <div class="form-field col-lg-4">
                   <select id="status" name="status" class="input-text" aria-required="true" aria-invalid="false" required>
                                                        <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($status==$list->id): ?>
                                                        <option selected value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
                                                            <?php else: ?>
                                                        <option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                           
                                                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger" role="alert">
                                                    <?php echo e($message); ?>

                                                    </div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                   
              </div>
            </div>
            <div class="contact-form row">

              <div class="form-field col-lg-2">
                  <label for="credit_limit" class="label">Credit limit</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="credit_limit" id="credit_limit" class="input-text" value="<?php echo e($credit_limit); ?>">
                   
              </div>
               <div class="form-field col-lg-6 float-end">
                <input type="hidden" name="id" value="<?php echo e($id); ?>">
                <input class="submit-btn" type="submit" value="Submit" name="Submit">
               </div>
            </div>
        </div>
        
                                            
      </form>
</section>
<script type="text/javascript">

    $('#DateOfBirth').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

  <?php if($DateOfBirth=='') { ?>
    $('#DateOfBirth').val('');
    <?php 
  }
    ?>
  function setDefaultPassword(id) {
    if (confirm("do You wabt to reset password to default password !") == false) 
    {
  return;
    } 
   $.ajax({
    type: "POST",
    url: '<?php echo e($AJAX_ROOT); ?>/admin/setDefaultPassword',
    data: { id: id, _token: '<?php echo e(csrf_token()); ?>' },
    success: function (data) 
    {
        //console.log(' ** '+ data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
            $('#divPwd'+id).html(obj.msg);
           
            }
        else
        {
            $('#divPwd'+id).html('');
           
        }
    
    },
    error: function (data, textStatus, errorThrown) {
        console.log(data+' '+textStatus+' '+errorThrown);
 
    },
});
}
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\statusdeal\resources\views/admin/customer_edit.blade.php ENDPATH**/ ?>