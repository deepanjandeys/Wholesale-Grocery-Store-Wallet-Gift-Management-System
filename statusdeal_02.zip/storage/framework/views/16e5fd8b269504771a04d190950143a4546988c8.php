;
<?php $__env->startSection('page_title','image edit'); ?>
<?php $__env->startSection('Setting_select','active'); ?>
<?php $__env->startSection('container'); ?>
<script type="text/javascript">
function readURL(input) {
    
  if (input.files && input.files[0]) {
    var reader = new FileReader();
    
    reader.onload = function(e) {
      $('#ProductImage').attr('src', e.target.result);
    }
    
    reader.readAsDataURL(input.files[0]);
  }
}
</script>
<section class="get_in_touch">
        <h1 class="title"><?php echo e(Config::get('constants.SITE_NAME')); ?> Image edit</h1>
        <form action="<?php echo e(route('image_save')); ?>" enctype="multipart/form-data" method="post">
            <?php echo csrf_field(); ?>
        <div class="container">
          <?php if(session('error')): ?>
<div class="alert alert-danger"><?php echo e(session('error')); ?></div>
<?php endif; ?>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Type</label>
              </div>
              <div class="form-field col-lg-4">
                  
                  <select name="img_type" id="img_type" class="input-text font-weight-bold" >
                        <option value=""></option>
                        <?php $__currentLoopData = $image_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($img_type==$list->id): ?>
                    <option selected value="<?php echo e($list->id); ?>" ><?php echo e($list->name); ?></option>
                            <?php else: ?>
                    <option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
              </div>
              <div class="form-field col-lg-1">
                  
              </div>
              <div class="form-field col-lg-4">
                  
                  

              </div>

            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="caption" class="label">Caption </label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="caption" id="caption" class="input-text" value="<?php echo e(old('caption')); ?>">
                  
              </div>
 
              <div class="form-field col-lg-2">
                  <label for="sub_caption" class="label">sub caption</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="sub_caption" id="sub_caption" class="input-text" value="<?php echo e(old('sub_caption')); ?>">
                   
              </div>
            </div>
            <div class="row">
              <div class="col-lg-6">
              <?php $__errorArgs = ['caption'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <div class="alert alert-danger" role="alert">
                    <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="col-lg-6">
              <?php $__errorArgs = ['sub_caption'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <div class="alert alert-danger" role="alert">
                    <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

              </div>
            </div>
            
            <div class="form-group">
                                        <div class="row">
                                            <div class="col-9">
                                                <label for="file" class="control-label mb-1">Image</label>
                                                <input id="filename" name="filename" type="file" accept="image/*" value="<?php echo e($filename); ?>" class="form-control" aria-required="true" aria-invalid="false" onchange="readURL(this)" <?php echo e($image_required); ?>>
                                                    <?php $__errorArgs = ['filename'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger" role="alert">
                                                    <?php echo e($message); ?>

                                                    </div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="col-3">
                                                    <?php if($filename !=''): ?>
                                                         <img id="ProductImage" src="<?php echo e(asset('/storage/media').'/'.$filename); ?>" style="width:150px;" alt="<?php echo e(asset('/storage/media').'/'.$filename); ?>" />
                                                    <?php else: ?> 
                                                     <img id="ProductImage" src="<?php echo e(asset('/storage/media').'/NoImage.png'); ?>" style="width:150px;" alt="<?php echo e(asset('/storage/media').'/NoImage.png'); ?>" />
                                                    <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
        
            <div class="contact-form row">
              
               <div class="form-field col-lg-6">
                
               </div>
               <div class="form-field col-lg-6">
                <input type="hidden" name="id" value="<?php echo e($id); ?>">
                <input class="submit-btn" type="submit" value="Submit" name="Submit">
               </div>
            </div>
        </div>
      </form>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\statusdeal\resources\views/admin/edit_image.blade.php ENDPATH**/ ?>