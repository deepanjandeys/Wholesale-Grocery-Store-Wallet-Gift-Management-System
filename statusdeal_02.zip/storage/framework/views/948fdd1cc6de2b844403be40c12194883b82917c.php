;
<?php $__env->startSection('page_title','Customer Password Change successfully'); ?>
<?php $__env->startSection('login_select','active'); ?>
<?php $__env->startSection('container'); ?>
<script type="text/javascript">
  function SignUp_click()
  {
    window.location='/sign_up';
  }
  
 </script>
<section class="get_in_touch">
        <h1 class="title"><?php echo e(Config::get('constants.SITE_NAME')); ?> Customer Password changed Successfully</h1>
        
        <div class="container">
           <?php if(session('error')): ?>
<div class="alert alert-danger"><?php echo e(session('error')); ?></div>
<?php endif; ?>
            <div class="contact-form row">
              <div class="form-field col-lg-4">
                  <label for="user" class="label">User </label>
              </div>
              <div class="form-field col-lg-4">
                  <label for="user" class="label"><?php echo e($name); ?> </label>
              </div>
              <input type="hidden" name="id" value="<?php echo e($id); ?>">
            </div>
        </div>
     
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\statusdeal\resources\views/admin/customer_password_change_success.blade.php ENDPATH**/ ?>