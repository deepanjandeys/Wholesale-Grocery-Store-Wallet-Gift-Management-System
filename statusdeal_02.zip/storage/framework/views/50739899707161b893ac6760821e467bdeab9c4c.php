;
<?php $__env->startSection('page_title','Dashboard'); ?>
<?php $__env->startSection('dashboard_select','active'); ?>
<?php $__env->startSection('container'); ?>
<script type="text/javascript">
  function dashboard()
  {
    window.location='/customer/dashboard';
  }
  function home_click()
  {
    window.location='/';
  }
 </script>
<section class="get_in_touch">
      <h1 class="title"><?php echo e(Config::get('constants.SITE_NAME')); ?> add Purchase Amount</h1>
        <form action="<?php echo e(route('customer.PurchaseAmount_process')); ?>" method="post">
            <?php echo csrf_field(); ?>
        <div class="container">
          <?php if(session('error')): ?>
<div class="alert alert-danger"><?php echo e(session('error')); ?></div>
<?php endif; ?>
            <div class="contact-form row ">
              <div class="form-field col-lg-12 myClass" style="color:white;font-weight: bold;">
                  <label for="name" class="label">Name <?php echo e($name); ?> </label> 
                  <label for="mobile" class="label">Mobile No. <?php echo e($mobile); ?></label>
              </div>
              
            </div>
            
            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="DateOfBirth" class="label">Purchase Date</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="purchaseDate" id="purchaseDate" class="input-text" value="<?php echo e(old('purchaseDate')); ?>">
                   
              </div>

              <div class="form-field col-lg-2">
                  <label for="amount" class="label">Amount</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="amount" id="amount" class="input-text" value="<?php echo e(old('amount')); ?>">
                   
              </div>
            </div>
            <div class="row">
              <div class="col-lg-6"><?php $__errorArgs = ['purchaseDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <div class="alert alert-danger" role="alert">
                    <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
              <div class="col-lg-6">
              <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <div class="alert alert-danger" role="alert">
                    <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                <label for="remarks" class="label">Remarks</label>
              </div>
              <div class="form-field col-lg-10">
                <textarea id="remarks" name="remarks" class="input-text" placeholder="optional"><?php echo e(old('remarks')); ?></textarea>
                 
              </div>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <?php $__errorArgs = ['remarks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <div class="alert alert-danger" role="alert">
                    <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="contact-form row">
              
               <div class="form-field col-lg-6">
              click here to go <a href="javascript:void(0)" onclick="dashboard()">Dashboard</a>
               </div>
               <div class="form-field col-lg-6">
                <input type="hidden" name="custId" value="<?php echo e($custId); ?>">
                <input type="hidden" name="id" value="<?php echo e($id); ?>">
                <input class="submit-btn" type="submit" value="Submit" name="Submit">
               </div>
            </div>
        </div>
      </form>
    </section>
<script>

    $('#purchaseDate').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\statusdeal\resources\views/admin/addPurchaseAmount.blade.php ENDPATH**/ ?>