;
<?php $__env->startSection('page_title','Dashboard'); ?>
<?php $__env->startSection('dashboard_select','active'); ?>
<?php $__env->startSection('container'); ?>

<span class="d-none">
    <?php echo e($typeName=session()->get('typeName')); ?>

    <?php echo e($ADMIN_ID=session()->get('ADMIN_ID')); ?>

    <?php echo e($AJAX_ROOT=Config::get('constants.AJAX_ROOT')); ?>

</span>
<style type="text/css">
    .myClass
    {
    background-image: var(--bs-gradient);
    }
</style>
<?php 
if(isset($_GET['Date_FROM']))
    $Date_FROM=$_GET['Date_FROM'];
else
    $Date_FROM=date('d-m-Y');

if(isset($_GET['Date_TO']))
    $Date_TO=$_GET['Date_TO'];
else
    $Date_TO=date('d-m-Y');
?>



<section class="get_in_touch">
        <h1 class="title"><?php echo e($typeName); ?>  Dashboard </h1>
        <form action="<?php echo e(route('admin.auth')); ?>" method="post">
            <?php echo csrf_field(); ?>
        <div class="container">
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Month</label>
              </div>
              <div class="form-field col-lg-4">
                  
                  <select name="month" id="month" class="input-text font-weight-bold" >
                        <option value=""></option>
                        <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($month==$list->id): ?>
                    <option selected value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
                            <?php else: ?>
                    <option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
              </div>
              <div class="form-field col-lg-1">
                  <label for="year" class="label">Year</label>
              </div>
              <div class="form-field col-lg-4">
                  
                  <select name="year" id="year" class="input-text font-weight-bold" >
                        <option value=""></option>
                        <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($year==$list->value): ?>
                    <option selected ><?php echo e($list->value); ?></option>
                            <?php else: ?>
                    <option ><?php echo e($list->value); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

              </div>

            </div>

            <div class="contact-form row">
              <div class="form-field col-lg-7">
                  <label for="purchaseAmount" class="label">Purchase Amount</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="purchaseAmount" id="purchaseAmount" class="input-text" value="<?php echo e(number_format($purchaseAmount,2)); ?>" readonly >
              </div>
             
              <div class="form-field col-lg-1">
                
                   <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalShowDetails" onclick="showViewDetails(<?php echo e($month); ?>,<?php echo e($year); ?>)"> ...</button>
              </div>
            </div>

            <div class="contact-form row">
              <div class="form-field col-lg-7">
                  <label for="targetAmount" class="label">Gift Target Amount</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="targetAmount" id="targetAmount" class="input-text" value="<?php echo e(number_format($targetAmount,2)); ?>" readonly >
              </div>
              
              <div class="form-field col-lg-1">
                  
              </div>
            </div>

            <div class="contact-form row">
              <div class="form-field col-lg-7">
                  <label for="credit_limit" class="label">Credit Limit</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="credit_limit" id="credit_limit" class="input-text" value="<?php echo e(number_format($credit_limit,2)); ?>" readonly >
              </div>
              
              <div class="form-field col-lg-1">
                  
              </div>
            </div>
<hr class="my-3">
            
            <div class="contact-form row">
              
               <div class="form-field col-lg-6">
                <input type="hidden" id="custId" value="<?php echo e($ADMIN_ID); ?>">
               </div>
               <div class="form-field col-lg-6">

                <input class="submit-btn" type="button" onclick="giftAchieve_click()" value="Gift Achieved" name="giftAchieved">
               </div>
            </div>
        </div>
    </form>
<img src="<?php echo e(asset('admin_assets/img/qr.jpg')); ?>" class="img-fluid"/>    
</section>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add purchase amount </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <div id="divPrevEntry">Please wait, previous purchase entry Rs <?php echo e($preEntryAmount); ?> yet to Approved</div>
      </div>
      <div class="modal-footer">
        <input type="hidden" id="curPurchaseId" >
        <button type="button" class="btn btn-secondary" data-dismiss="modal">close</button>
        <button type="button" class="btn btn-primary d-none">Yes</button>
      </div>
    </div>
  </div>
</div>
<!-- Modal -->
<div class="modal fade" id="exampleModalShowDetails" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">View Purchase Amount List</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <div id="divTable">please wait</div>
      </div>
      <div class="modal-footer">
        <input type="hidden" id="curPurchaseId" >
        <button type="button" class="btn btn-secondary" data-dismiss="modal">close</button>
        <button type="button" class="btn btn-primary d-none">Yes</button>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
function addPurchaseAmount_click()
{
    var custId = $('#custId').val();
    window.location="/customer/addPurchaseAmount/"+custId;
}
function giftAchieve_click()
{
    var custId = $('#custId').val();
    window.location="/customer/giftAchieve/"+custId;
}

function showViewDetails(month,year) {
    var custId = $('#custId').val();
    //console.log(month+' '+year+' '+custId);
   $.ajax({
    type: "POST",
    url: '<?php echo e($AJAX_ROOT); ?>/customer/getViewDetails',
    data: { custId: custId,month,year, _token: '<?php echo e(csrf_token()); ?>' },
    success: function (data) 
    {
        console.log(' ** '+ data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
            $('#divTable').html(obj.str);
           
            }
        else
        {
            $('#divTable').html('');
           
        }
    
    },
    error: function (data, textStatus, errorThrown) {
        console.log(data+' '+textStatus+' '+errorThrown);
 
    },
});
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\statusdeal\resources\views/admin/cust_dashboard.blade.php ENDPATH**/ ?>