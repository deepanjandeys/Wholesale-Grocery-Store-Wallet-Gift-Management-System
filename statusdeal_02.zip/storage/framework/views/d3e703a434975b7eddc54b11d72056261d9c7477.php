;
<?php $__env->startSection('page_title','Dashboard'); ?>
<?php $__env->startSection('dashboard_select','active'); ?>
<?php $__env->startSection('container'); ?>

<span class="d-none">
    <?php echo e($typeName=session()->get('typeName')); ?>

    <?php echo e($ADMIN_ID=session()->get('ADMIN_ID')); ?>

</span>
<style type="text/css">
    .myClass
    {
    background-image: var(--bs-gradient);
    }
</style>
<?php 
if(isset($_GET['Date_FROM']))
    $Date_FROM=$_GET['Date_FROM'];
else
    $Date_FROM=date('d-m-Y');

if(isset($_GET['Date_TO']))
    $Date_TO=$_GET['Date_TO'];
else
    $Date_TO=date('d-m-Y');
?>



<section class="get_in_touch">
        <h1 class="title"><?php echo e($typeName); ?>  Dashboard </h1>
        <form action="<?php echo e(route('admin.auth')); ?>" method="post">
            <?php echo csrf_field(); ?>
        <div class="container">
            <div class="contact-form row">
              <div class="form-field col-2">
                  <label for="mobile" class="label">Month</label>
              </div>
              <div class="form-field col-4">
                  
                  <select name="month" id="month" class="input-text font-weight-bold" >
                        <option value=""></option>
                        <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($month==$list->id): ?>
                    <option selected ><?php echo e($list->name); ?></option>
                            <?php else: ?>
                    <option ><?php echo e($list->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
              </div>
              <div class="form-field col-1">
                  <label for="year" class="label">Year</label>
              </div>
              <div class="form-field col-4">
                  
                  <select name="year" id="year" class="input-text font-weight-bold" >
                        <option value=""></option>
                        <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($year==$list->value): ?>
                    <option selected ><?php echo e($list->value); ?></option>
                            <?php else: ?>
                    <option ><?php echo e($list->value); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

              </div>

            </div>

            <div class="contact-form row">
              <div class="form-field col-7">
                  <label for="purchaseAmount" class="label">Purchase Amount</label>
              </div>
              <div class="form-field col-4">
                  <input type="text" name="purchaseAmount" id="purchaseAmount" class="input-text" value="<?php echo e(number_format($purchaseAmount,2)); ?>" readonly >
              </div>
             
              <div class="form-field col-1">
                
                  <a  class="btn btn-primary">...</a>
              </div>
            </div>

            <div class="contact-form row">
              <div class="form-field col-7">
                  <label for="targetAmount" class="label">Target</label>
              </div>
              <div class="form-field col-4">
                  <input type="text" name="targetAmount" id="targetAmount" class="input-text" value="<?php echo e(number_format($targetAmount,2)); ?>" readonly >
              </div>
              
              <div class="form-field col-1">
                  
              </div>
            </div>
<hr class="my-3">
            <div class="contact-form row">
              <div class="form-field col-7">
                  <label for="giftAchieveAmount" class="label">Gift Achieve Amount</label>
              </div>
              <div class="form-field col-4">
                  <input type="text" name="giftAchieveAmount" id="giftAchieveAmount" class="input-text" value="<?php echo e(number_format($giftAchieveAmount,2)); ?>" readonly >
              </div>
              
              <div class="form-field col-1">
                  
              </div>
            </div>
            <div class="contact-form row">
              
               <div class="form-field col-lg-6">
                <input type="hidden" id="custId" value="<?php echo e($ADMIN_ID); ?>">
                <input class="submit-btn" type="button" onclick="addPurchaseAmount_click()" value="Add Purchase Amount" name="addPurchaseAmount">
               </div>
               <div class="form-field col-lg-6">
                <input class="submit-btn" type="button" onclick="giftAchieve_click()" value="Gift Achieve" name="giftAchieve">
               </div>
            </div>
        </div>
    </form>
    
</section>
<script type="text/javascript">
function addPurchaseAmount_click()
{
    var custId = $('#custId').val();
    window.location="/customer/addPurchaseAmount/"+custId;
}
function giftAchieve_click()
{
    window.location="/customer/giftAchieve";
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\statusdeal\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>