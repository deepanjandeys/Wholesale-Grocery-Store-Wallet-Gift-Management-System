;
<?php $__env->startSection('page_title','Wallet Report'); ?>
<?php $__env->startSection('Report_select','active'); ?>
<?php $__env->startSection('container'); ?>

<?php if(session()->has('message')): ?>
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="badge badge-pill badge-success">Message</span>
  <?php echo e(session('message')); ?>

<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
<?php endif; ?>
<?php 
if(isset($_GET['Date_FROM']))
    $Date_FROM=$_GET['Date_FROM'];
else
    $Date_FROM=date('d-m-Y');

if(isset($_GET['Date_TO']))
    $Date_TO=$_GET['Date_TO'];
else
    $Date_TO=date('d-m-Y');
?>
<h2 class="title-1 m-b-10">Wallet Report </h2>
<form action="" method="get" >
    <div class="row">
        <div class="col-4">
            <input type="search" name="search" class="form-control" placeholder="Ordrer No./Reference No." value="<?php echo e($search); ?>">        
        </div>
        <div class="col-2">
        
        </div>
        <div class="col-2">
         
        </div>
        <div class="col-6">
            <div class="row">
                <div class="col-4">
                    <select name="Date_OPR" id="Date_OPR" class="form-control" >
                        <option value="">Date</option>
                        <?php $__currentLoopData = $compOperators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($Date_OPR==$list->name): ?>
                    <option selected ><?php echo e($list->name); ?></option>
                            <?php else: ?>
                    <option ><?php echo e($list->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                </div>
                <div class="col-4">
                <input type="search" name="Date_FROM" id="Date_FROM" class="form-control" placeholder="From" value="<?php echo e($Date_FROM); ?>">  
            </div>
            <div class="col-4">
                <input type="search" name="Date_TO" id="Date_TO" class="form-control" placeholder="To" value="<?php echo e($Date_TO); ?>">    
            </div>
            
            </div>
        </div>
        <div class="col-4">
        <button class="btn btn-primary">Search</button>   
        <a href="<?php echo e(url('admin/rechargeLog')); ?>" >
            <button type="button" class="btn btn-primary">Reset</button>
        </a>     
        </div>
    </div>
</form>

         <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-dark table-light">
                                        <thead>
                                             <tr>
                                                <th>ID</th>
                                                <th>Number</th>
                                                <th>Operator</th>
                                                <th>Circle</th>
                                                <th>Order No.</th>
                                                <th>Reference No.</th>
                                                <th>Date Time</th>
                                                <th>Amont</th>
                                                <th>Commission</th>
                                                <th>Status</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                           <?php $__currentLoopData = $walletReport; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                
                                                <td><?php echo e($list->Sl); ?></td>
                                                <td><?php echo e($list->m_bill_no); ?></td>
                                                <td>                                  
                                                </td>
                                                <td>                                  
                                               
                                                </td>
                                                <td><?php echo e($list->API_Partner_OrderId); ?></td>
                                                <td><?php echo e($list->orderNo); ?></td>
                                                <td><?php echo e($list->date_tim); ?></td>
                                                <td><?php echo e($list->rechargeAmt); ?></td>
                                                <td><?php echo e($list->Commission); ?></td>
                                                <td>
                                                <span class="text-primary"><?php echo e($list->Status); ?></span>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <?php echo e($walletReport->links()); ?>

                                <!-- END DATA TABLE-->
                            </div>
                        </div>
<script>

    $('#Date_FROM').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });
    $('#Date_TO').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

    <?php 
        if (isset($_GET['Date_FROM']))
        {
    ?>
    $('#Date_FROM').val('<?php echo $_GET['Date_FROM']; ?>');
    <?php 
    }
    ?>
     <?php 
        if (isset($_GET['Date_TO']))
        {
    ?>
    $('#Date_TO').val('<?php echo $_GET['Date_TO']; ?>');
    <?php 
    }
    ?>
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\test.mt\api\resources\views/admin/wallet.blade.php ENDPATH**/ ?>