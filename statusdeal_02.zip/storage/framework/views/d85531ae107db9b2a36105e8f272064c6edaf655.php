;
<?php $__env->startSection('page_title','Dashboard'); ?>
<?php $__env->startSection('dashboard_select','active'); ?>
<?php $__env->startSection('container'); ?>

<section class="get_in_touch">
        <h1 class="title"><?php echo e(Config::get('constants.SITE_NAME')); ?> Pending List</h1>
        
        <div class="container">
          <form>
         <div class="contact-form row">
              <div class="form-field col-2">
                  <label for="mobile" class="label">Month</label>
              </div>
              <div class="form-field col-4">
                  
                  <select name="month" id="month" class="input-text font-weight-bold" >
                        <option value=""></option>
                        <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($month==$list->id): ?>
                    <option selected value="<?php echo e($list->id); ?>" ><?php echo e($list->name); ?></option>
                            <?php else: ?>
                    <option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
              </div>
              <div class="form-field col-1">
                  <label for="year" class="label">Year</label>
              </div>
              <div class="form-field col-4">
                  
                  <select name="year" id="year" class="input-text font-weight-bold" >
                        <option value=""></option>
                        <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($year==$list->value): ?>
                    <option selected ><?php echo e($list->value); ?></option>
                            <?php else: ?>
                    <option ><?php echo e($list->value); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

              </div>

            </div>
            <div class="contact-form row">
              <div class="form-field col-2">
                  <label for="mobile" class="label">Search</label>
              </div>
              <div class="form-field col-9">
              <input type="search" name="search" placeholder="customer name/mobile/address/remarks" class="input-text" value="<?php echo e($search); ?>">
              </div>
              <div class="form-field col-1">
                <input type="submit" name="search-btn" class="btn btn-primary" value="search">
              </div>
            </div>
            </form>
          </div>
    </section>
    <div class="container">
            <div class="contact-form row">
              <div class="col-12">
                <table class="table table-responsive table-dark table-light">
                  <tr> 
                    
                    <th>
                      id
                    </th>
                    <th>
                      Date
                    </th>
                    <th>
                      Cust id
                    </th>
                    <th>
                      Customer Name
                    </th>
                    <th>
                      Mobile No.
                    </th>
                    <th>
                      Address
                    </th>
                    <th>
                      Amount
                    </th>
                    <th colspan="3" class="text-center">action</th>
                    
                    <th>
                      remarks
                    </th>
                  </tr>
                  <tbody>
                                            <?php $__currentLoopData = $customerPurchase; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                           
                                                <td><?php echo e($list->id); ?></td>
                                                <td><?php echo e($list->purchaseDate); ?></td>
                                                <td><?php echo e($list->custId); ?></td>
                                                <td><?php echo e($list->getCustomers->name); ?></td>
                                                <td><?php echo e($list->getCustomers->mobile); ?></td>
                                                <td><?php echo e($list->getCustomers->address); ?></td>
                                                <td style="text-align: right;"><?php echo e(number_format($list->amount,2)); ?></td>
                                                 <td>
                                                    <?php if($list->status==1): ?>
                                                    
                                                       
                                                    <a href="<?php echo e(url('admin/CustomerPurchase/status/0/')); ?>/<?php echo e($list->id); ?>">
                                                    <button type="button" class="btn btn-warning">Disapprove</button>
                                                    </a>
                                                   
                                                    <?php elseif($list->status==0): ?>
                                                                                                       
                                                    <a href="<?php echo e(url('admin/CustomerPurchase/status/1/')); ?>/<?php echo e($list->id); ?>">
                                                    <button type="button" class="btn btn-primary">Approve</button>
                                                    </a>    
                                                     
                                                    <?php endif; ?>
                                                    
                                                </td>
                                                 <td>               
                                                  <a href="<?php echo e(url('admin/CustomerPurchase/delete/')); ?>/<?php echo e($list->id); ?>">
                                                    <button type="button" class="btn btn-danger">Decine</button>
                                                    </a>
                                                    
                                                
                                                </td>
                                                <td>
                                                  <a href="javascript:void(0)" class="btn btn-success" >View Detail</a>
                                                </td>
                                                
                                                
                                                <td>time: <?php echo e($list->created_at); ?> <?php echo e($list->remarks); ?></td>
                                              </tr>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                </table>
              </div>
            </div>
            
            
        </div>
<script>

    $('#DateOfBirth').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\statusdeal\resources\views/admin/customerPurchase.blade.php ENDPATH**/ ?>