;
<?php $__env->startSection('page_title','Dashboard'); ?>
<?php $__env->startSection('dashboard_select','active'); ?>
<?php $__env->startSection('container'); ?>

<span class="d-none">
    <?php echo e($typeName=session()->get('typeName')); ?>

</span>
<style type="text/css">
    .myClass
    {
    background-image: var(--bs-gradient);
    }
</style>
<?php 
if(isset($_GET['Date_FROM']))
    $Date_FROM=$_GET['Date_FROM'];
else
    $Date_FROM=date('d-m-Y');

if(isset($_GET['Date_TO']))
    $Date_TO=$_GET['Date_TO'];
else
    $Date_TO=date('d-m-Y');
?>

<div class="container"> 
	<div class="row bg-primary text-light font-weight-bold mb-3 myClass">
        <div class="col-12">
            <h2 class="title-1 m-b-10"><?php echo e(Config::get('constants.SITE_NAME')); ?> <?php echo e($typeName); ?>  Dashboard</h2>
        </div>
     </div>
<form action="" method="get" >
<div class="row mb-3">
        <div class="col-lg-2 mb-1">
        <select id="Op_Code" name="Op_Code" class="form-control" aria-required="true" aria-invalid="false">
            <option value="">All Operator</option>
            <?php $__currentLoopData = $operators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($Op_Code==$list->Op_Code): ?>
                <option selected value="<?php echo e($list->Op_Code); ?>"><?php echo e($list->Op_Code); ?></option>
                <?php else: ?>
                <option value="<?php echo e($list->Op_Code); ?>"><?php echo e($list->Op_Code); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select> 
        </div>
        <div class="col-lg-2 mb-1">
        <select id="circle" name="circle" class="form-control" aria-required="true" aria-invalid="false">
            <option value="">All Circle</option>
            <?php $__currentLoopData = $circles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($circle==$list->Code): ?>
            <option selected value="<?php echo e($list->Code); ?>"><?php echo e($list->Ope_Cir_Name); ?></option>
                <?php else: ?>
            <option value="<?php echo e($list->Code); ?>"><?php echo e($list->Ope_Cir_Name); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select> 
        </div>
            <div class="col-lg-2 mb-1">
                <input type="search" name="Date_FROM" id="Date_FROM" class="form-control" placeholder="From" value="<?php echo e($Date_FROM); ?>">  
            </div>
            <div class="col-lg-2 mb-1">
                <input type="search" name="Date_TO" id="Date_TO" class="form-control" placeholder="To" value="<?php echo e($Date_TO); ?>">    
            </div>
            <div class="col-2 mb-1">
        <button class="btn btn-primary" title="Search"><i class="bi bi-search"></i></button>  
        </div>
        <div class="col-2"> 
        <a href="<?php echo e(url('admin/dashboard')); ?>" >
            <button type="button" class="btn btn-primary" title="Reset"><i class="bi bi-arrow-clockwise"></i></button>
        </a>     
        </div>
</div>
</form>
     <div class="row">
         <div class="col-lg-2 bg-dark text-light rounded myClass mx-1 mb-1">
            <h5>SUCCESS</h5>
                    &#8377; <?php echo e($sumSucsAmt); ?> (<?php echo e($countSucsAmt); ?>)
         </div>
         <div class="col-lg-2 bg-dark text-light rounded myClass mx-1 mb-1">
            <h5>NOT PROCEED</h5>
                    &#8377; <?php echo e($sumNotProcAmt); ?> (<?php echo e($countNotProcAmt); ?>)
         </div>
         <div class="col-lg-2 bg-dark text-light rounded myClass mx-1 mb-1">
            <h5>PENDING</h5>
                    &#8377; <?php echo e($sumPendingAmt); ?> (<?php echo e($countPendingAmt); ?>)
         </div>
         <div class="col-lg-2 bg-dark text-light rounded myClass mx-1 mb-1">
            <h5>FAILURE</h5>
                    &#8377; <?php echo e($sumFailureAmt); ?> (<?php echo e($countFailureAmt); ?>)
         </div>
         
         <div class="col-lg-2 bg-dark text-light rounded myClass mx-1 mb-1">
            <h5>PROFIT</h5>
                    &#8377; <?php echo e($sumCommission); ?> 
         </div>
     </div>
     <div class="row my-2">
         <div class="col-lg-3 bg-dark text-light rounded myClass mx-1 mb-1">
             <table class="table table-dark table-light my-2">
                 <tr>
                    <th>Openning Balance</th>
                    <td><?php echo e($openingBalance); ?></td>
                </tr>
                <tr>
                    <th>Total Add Fund</th>
                    <td><?php echo e($sumAddFund); ?></td>
                </tr>

                <tr>
                    <th>Total Recharge</th>
                    <td><?php echo e($sumRecharge); ?></td>
                </tr>
                <tr>
                    <th>Total Refund</th>
                    <td><?php echo e($sumRefund); ?></td>
                </tr>
             </table>
         </div>
         <div class="col-lg-3 bg-dark text-light rounded myClass mx-1 mb-1">
             

                                    <table class="table table-dark table-light my-2">
                                        <thead>
                                             <tr>
                                                <th>Operator</th>
                                                <th>Amont</th>
                                            </tr>
                                        </thead>
                                     
                                        <?php if(count($operatorsWiseSum) === 1): ?>
                                        <tbody>
                                           <?php $__currentLoopData = $operatorsWiseSum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($list->operator); ?></td>
                                                <td><?php echo e($list->sumAmt); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        <?php else: ?>
                                        <tbody>
                                           
                                            <tr>
                                                <td colspan="2">Nothing to show</td>
                                         
                                            </tr>
                                           
                                        </tbody>
                                        <?php endif; ?>
                                    </table>
                                </div>
                                   <!-- END DATA TABLE-->
                                <div class="col-lg-3 bg-dark text-light rounded myClass mx-1 mb-1">
             

                                    <table class="table table-dark table-light my-2">
                                        <tbody>
                                             <tr>
                                                <th>Balance</th>
                                                <td><?php echo e($Balance); ?></td>
                                            </tr>
                                        </tbody>
                                     
                                        
                                    </table>
                                </div>
</div>
</div>

 </div>
 <script>

    $('#Date_FROM').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });
    $('#Date_TO').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

    <?php 
        if (isset($_GET['Date_FROM']))
        {
    ?>
    $('#Date_FROM').val('<?php echo $_GET['Date_FROM']; ?>');
    <?php 
    }
    ?>
     <?php 
        if (isset($_GET['Date_TO']))
        {
    ?>
    $('#Date_TO').val('<?php echo $_GET['Date_TO']; ?>');
    <?php 
    }
    ?>
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\test.mt\api\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>