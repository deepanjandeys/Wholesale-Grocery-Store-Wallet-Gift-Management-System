;
<?php $__env->startSection('page_title','Customer Login'); ?>
<?php $__env->startSection('dashboard_select','active'); ?>
<?php $__env->startSection('container'); ?>
<script type="text/javascript">
  function SignUp_click()
  {
    window.location='/sign_up';
  }
  function forget_password()
  {
    window.location='/customer/forget_password';
  }
 </script>
 
<section class="get_in_touch">
        <h1 class="title"><?php echo e(Config::get('constants.SITE_NAME')); ?> Login</h1>
        <form action="<?php echo e(route('cust.auth')); ?>" method="post">
            <?php echo csrf_field(); ?>
        <div class="container">
           <?php if(session('error')): ?>
<div class="alert alert-danger"><?php echo e(session('error')); ?></div>
<?php endif; ?>
            <div class="contact-form row">
              <div class="form-field col-12 col-lg-4">
                  <label for="mobile" class="label">Mobile No.</label>
              </div>
              <div class="form-field col-12 col-lg-8">
                  <input type="text" name="mobile" id="mobile" class="input-text" value="<?php echo e(old('mobile')); ?>" >
              </div>
            </div>
            <div class="contact-form row">
              <div class="form-field col-12 col-lg-4">
                  <label for="password" class="label">password</label>
              </div>
              <div class="form-field col-12 col-lg-8">
                <input type="password" name="password" id="password" class="input-text" value="<?php echo e(old('password')); ?>">
              </div>
            </div>
           
            <div class="contact-form d-flex flex-column-reverse flex-lg-row ">
              
               <div class="form-field col-lg-6 text-center">
                <a class="submit-btn" href="javascript:void(0)" onclick="SignUp_click()"><span style="font-weight: normal;"> new user ?</span> Sign Up
                </a>
               </div>
               <div class="form-field col-lg-6">
                <input class="submit-btn" type="submit" value="Login" name="SignIn">
               </div>
            </div>
            <div class="row">
              <div class="col-8"></div>
              <div class="col-4">
                <a href="javascript:void(0)" onclick="forget_password()">Forget Password?</a>
              </div>
            </div>
        </div>
      </form>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\statusdeal\resources\views/admin/cust_login.blade.php ENDPATH**/ ?>