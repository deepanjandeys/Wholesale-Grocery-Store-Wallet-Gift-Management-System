;
<?php $__env->startSection('page_title','Edit Profile'); ?>
<?php $__env->startSection('setting_select','active'); ?>
<?php $__env->startSection('container'); ?>
<h2 class="title-1 m-b-10">Profile</h2>
<a href="<?php echo e(url('admin/dashboard')); ?>" >
<button type="button" class="btn btn-success"><i class="bi bi-box-arrow-left"></i></button>
</a>
<?php if(session()->has('message')): ?>
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="badge badge-pill badge-success">Message</span>
  <?php echo e(session('message')); ?>

<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
<?php endif; ?>
         <div class="row m-t-30">
                            
                                <div class="col-lg-12">
                                    
                                <div class="card bg-dark text-light">
                                    <div class="card-body">
                                        <form action="<?php echo e(route('manage_profile_process')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <label for="Member_Name" class="control-label mb-1">Name</label>
                                                <input id="Member_Name" name="Member_Name" type="text" value="<?php echo e($Member_Name); ?>" class="form-control" aria-required="true" aria-invalid="false" >
                                                
                                                    <?php $__errorArgs = ['Member_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger" role="alert">
                                                    <?php echo e($message); ?>

                                                    </div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                
                                            </div>
                                            <div class="form-group">
                                                <label for="mobile" class="control-label mb-1">Mobile</label>
                                                <input id="mobile" name="mobile" type="text" value="<?php echo e($mobile); ?>" class="form-control" aria-required="true" aria-invalid="false" >
                                                    <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger" role="alert">
                                                    <?php echo e($message); ?>

                                                    </div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="form-group">
                                                <label for="Aderess" class="control-label mb-1">Address</label>
                                                <input id="Aderess" name="Aderess" type="text" value="<?php echo e($Aderess); ?>" class="form-control" aria-required="true" aria-invalid="false" >
                                                    <?php $__errorArgs = ['Aderess'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger" role="alert">
                                                    <?php echo e($message); ?>

                                                    </div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group">
                                                <label for="email" class="control-label mb-1">email</label>
                                                <input id="email" name="email" type="text" value="<?php echo e($email); ?>" class="form-control" aria-required="true" aria-invalid="false" >
                                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger" role="alert">
                                                    <?php echo e($message); ?>

                                                    </div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="form-group">
                                                <label for="PAN_Card" class="control-label mb-1">PAN Card</label>
                                                <input id="PAN_Card" name="PAN_Card" type="text" value="<?php echo e($PAN_Card); ?>" class="form-control" aria-required="true" aria-invalid="false" >
                                                    <?php $__errorArgs = ['PAN_Card'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger" role="alert">
                                                    <?php echo e($message); ?>

                                                    </div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
<br>
                                            <div>
                                                <input type="hidden" name="Mem_ID" value="<?php echo e($Mem_ID); ?>">
                                                <button id="callback-button" type="submit" class="btn btn-lg btn-info btn-block">
                                                    Submit
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\test.mt\api\resources\views/admin/edit_profile.blade.php ENDPATH**/ ?>