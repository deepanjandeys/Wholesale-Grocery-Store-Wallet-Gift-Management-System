;
<?php $__env->startSection('page_title','Customer Transaction List'); ?>
<?php $__env->startSection('Report_select','active'); ?>
<?php $__env->startSection('container'); ?>
<span class="d-none">
  <?php echo e($AJAX_ROOT=Config::get('constants.AJAX_ROOT')); ?>

  <?php echo e($type=session()->get('ADMIN_TYPE')); ?>

</span>

<section class="get_in_touch">
        <h1 class="title">Transaction List of <?php echo e($name); ?></h1>
        
        <div class="container">
          <div class="container">
          <form id="myForm">
        <div class="contact-form row">

          <div class="form-field col-lg-2">
                  <label for="month" class="label">Month</label>
              </div>
              <div class="form-field col-lg-4">
                  
                  <select name="month" id="month" onchange="selMonth_Change()" class="input-text font-weight-bold" >
                       
                        <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($month==$list->id): ?>
                    <option selected value="<?php echo e($list->id); ?>" ><?php echo e($list->name); ?></option>
                            <?php else: ?>
                    <option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
              </div>
              <div class="form-field col-lg-1">
                  <label for="year" class="label">Year</label>
              </div>
              <div class="form-field col-lg-4">
                  
                  <select name="year" id="year" onchange="selMonth_Change()" class="input-text font-weight-bold" >
                        <option value=""></option>
                        <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($year==$list->value): ?>
                    <option selected ><?php echo e($list->value); ?></option>
                            <?php else: ?>
                    <option ><?php echo e($list->value); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

              </div>
              <div class="form-field col-lg-1">
                <input type="submit" name="search-btn" class="btn btn-primary" value="search">
              </div>
            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Date From</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="Date_From" id="Date_From" placeholder="Date From" class="input-text" value="<?php echo e($Date_From); ?>">
              </div>
              <div class="form-field col-lg-1">
                  <label for="year" class="label">To</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="Date_To" id="Date_To" placeholder="Date To" class="input-text" value="<?php echo e($Date_To); ?>">

              </div>

            </div>
            </form>
          </div>

    </section>
    <div class="container">
            <div class="contact-form row">
              <div class="col-lg-12 overflow-scroll">
                
                <table class="table table-responsive">
                  <tr>   
                   <th>Sl No</th> 
                   <th>Date</th>
                   <th>Tran type</th>
                   <th>amount</th>
                   <th>Balance</th>
                   <th>Remarks</th>
                   <th>Action</th>
                  </tr>
                  <?php if($customer_Wallet->count()>0): ?>
                  <?php 
                  $i=0;
                  $custId=$id;
                  $today=strtotime(date('d-m-Y'));
                  ?>
                  <tbody>
                                            <?php $__currentLoopData = $customer_Wallet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <?php 
 $i++;
            $created_at   =date('d-m-Y h:i:s A', strtotime($list->created_at));
            $amount         = number_format($list->amount,2);
            $balance         = number_format($list->curBalance,2);
            $id = $list->id;
            $tranType=$list->tranType;
            $tranTypes='';
            if($tranType=='0')
            {
                $tranTypes="Opening";
            }
            else if($tranType=='1')
            {
                $tranTypes='Debit';
            }
            else if($tranType=='2')
            {
                $tranTypes="Credit";
            }
            else if($tranType=='3')
            {
                $tranTypes="Withdraw";
            }
            else if($tranType=='4')
            {
                $tranTypes="Nothing";
            }
            $remarks = $list['remarks'];
            $actions='';
            if($i==$customer_Wallet->count() && ($tranType==2 || $tranType==3) && $type=='1')
            {
              $actions='<a class="btn btn-primary" data-toggle="modal" data-target="#exampleModalShowWallet" onclick="getWalletBalance('.$custId.',0,'.$id.','.$amount.')"> Edit Wallet Balance</a>';
              //$actions='<a href="javascript:void(0)" >Edit Wallet Balance</a>';
            }
  ?>                                           <tr>
                                                <td><?php echo e($i); ?></td>
                                                <td><?php echo e($created_at); ?></td>
                                                <td><?php echo e($tranTypes); ?></td>
                                                <td id="tdAmount<?php echo e($custId); ?>"><?php echo e($amount); ?></td>
                                                <td id="tdBalance<?php echo e($custId); ?>"><?php echo e($balance); ?></td>
                                                <td id="tdRemarks<?php echo e($custId); ?>"><?php echo e($remarks); ?> </td>
                                                <td><?php echo $actions; ?></td>
                                                </tr>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php if($type=='1'): ?>                        
                      <tr>
                        <td colspan="7">
                          <a href="javascript:void(0)" class="btn btn-danger" data-toggle="modal" data-target="#exampleModalShowWallet" onclick="getWalletBalance('<?php echo e($custId); ?>',2)">Withdraw Wallet Balance</a>
                        </td>
                      </tr>
                      <?php endif; ?>
                      </tbody>
                      <?php else: ?>
                      <tbody>
                        <tr>
                          <td colspan="10">Nothing to show</td>
                        </tr>
                      </tbody>
                      <?php endif; ?>
                </table>
              </div>
            </div>
            
            
        </div>
<!-- Modal -->
<div class="modal fade" id="exampleModalShowWallet" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit/Withdraw Wallet Balance</h5>
      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <div id="divTable">please wait</div>
      </div>
      <div class="modal-footer">
        <input type="hidden" id="curPurchaseId" >
        <button type="button" id="btnClose" class="btn btn-secondary" data-dismiss="modal">close</button>
        <button type="button" class="btn btn-primary d-none">Yes</button>
      </div>
    </div>
  </div>
</div>
<!-- ///////////  -->
<a href="javascript:void(0)" class="btn btn-danger d-none" data-toggle="modal" data-target="#exampleModalShowCreditLimitWarning" id="a_credit_limit">credit</a>
<!-- Modal -->
<div class="modal fade" id="exampleModalShowCreditLimitWarning" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabelCredit">Credit Limit Warning</h5>
      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <div id="divAddBalMsg">please wait</div>
      </div>
      <div class="modal-footer">
        
        <button type="button" id="btnClose" class="btn btn-secondary" data-dismiss="modal">close</button>
        <button type="button" class="btn btn-primary d-none">Yes</button>
      </div>
    </div>
  </div>
</div>
<!-- //////////  -->

<script type="text/javascript">
function selMonth_Change()
{
  var m=$('#month').val();
  var y=$('#year').val();
  //var firstDay = new Date(y, m, 1);
  
  if (m<10) 
  {
    m = '0'+m;
  }

  var firstDay = '01-'+m+'-'+y;
  var lastDay = new Date(y, m , 0); //new Date(y, m + 1, 0);
  lastDay = lastDay.getDate()+'-'+m+'-'+y;

  $('#Date_From').val(firstDay);
  $('#Date_To').val(lastDay);

//console.log(firstDay+' '+lastDay);
}
    $('#Date_From').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

    $('#Date_To').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

 function getWalletBalance(id,add,WalletId=0,amount=0) {
    
   $.ajax({
    type: "POST",
    url: '<?php echo e($AJAX_ROOT); ?>/customer/getWalletBalance',
    data: { custId: id,add:add,WalletId:WalletId,amount:amount, _token: '<?php echo e(csrf_token()); ?>' },
    success: function (data) 
    {
        //console.log(' ** '+ data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
            $('#divTable').html(obj.str);
           $('#exampleModalLabel').html(obj.action+' Wallet Balance');
            }
        else
        {
            $('#divTable').html('');
            $('#exampleModalLabel').html('Edit/Withdraw Wallet Balance');
        }
    
    },
    error: function (data, textStatus, errorThrown) {
        console.log(data+' '+textStatus+' '+errorThrown);
 
    },
});
}


function EditWalletBalance(id) {

  var EditBalance = $('#EditBalance').val();
  var WalletId = $('#WalletId').val();
  var Remarks = $('#txtRemarks').val();

  if(EditBalance==undefined)
    {
    return;
    }    
    else
    {
      EditBalance=parseFloat(EditBalance);
    }
    if(isNaN(EditBalance))
      return;

    if(WalletId==undefined)
      WalletId=0;

    if(Remarks==undefined)
    {
      Remarks = '';
    }

    Remarks=Remarks.trim();

//console.log('custId '+id+' , EditBalance '+EditBalance+' , WalletId '+WalletId);
//console.log('custId '+id+' , Remarks '+Remarks);  
   $.ajax({
    type: "POST",
    url: '<?php echo e($AJAX_ROOT); ?>/customer/editWalletBalance',
    data: { custId: id,EditBalance:EditBalance,WalletId:WalletId , Remarks:Remarks , _token: '<?php echo e(csrf_token()); ?>' },
    success: function (data) 
    {
        //console.log(' ## '+ data);
      //debugger;
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
          /*
            $('#tdRemarks'+id).html(obj.msg);    
            $('#tdBalance'+id).html(obj.newBalance+'<br><a class="btn-primary" data-toggle="modal" data-target="#exampleModalShowWallet" onclick="getWalletBalance('+obj.id+',0,'+obj.WalletId+','+obj.amount+')"> Edit Wallet Balance</a>');    
            $('#tdAmount'+id).val(obj.amount) ;
          */
          location.reload();
        }
        else
        {
            $('#divAddBalMsg'+id).html('');    
        }
      $('#btnClose').click();
    },
    error: function (data, textStatus, errorThrown) {
        console.log(data+' '+textStatus+' '+errorThrown);
 
    },
});
}

function WithdrawWalletBalance(id) {

  var WithdrawBalance = $('#WithdrawBalance').val();
  var WalletId = $('#WalletId').val();
  var Remarks = $('#txtRemarks').val();

  if(WithdrawBalance==undefined)
    {
    return;
    }    
    else
    {
      WithdrawBalance=parseFloat(WithdrawBalance);
    }
    if(isNaN(WithdrawBalance))
      return;

    if(WalletId==undefined)
      WalletId=0;

    if(Remarks==undefined)
    {
      Remarks = '';
    }
    Remarks = Remarks.trim();
 
//console.log('custId '+id+' , WithdrawBalance '+WithdrawBalance + ' , Remarks '+Remarks);
   $.ajax({
    type: "POST",
    url: '<?php echo e($AJAX_ROOT); ?>/customer/withdrawWalletBalance',
    data: { custId: id,WithdrawBalance:WithdrawBalance, Remarks: Remarks , _token: '<?php echo e(csrf_token()); ?>' },
    success: function (data) 
    {
      //console.log(' ## '+ data);
      //debugger;
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.error=='0')
        {
          /*
            $('#tdRemarks'+id).html(obj.msg);    
            $('#tdBalance'+id).html(obj.newBalance+'<br><a class="btn-primary" data-toggle="modal" data-target="#exampleModalShowWallet" onclick="getWalletBalance('+obj.id+',0,'+obj.WalletId+','+obj.amount+')"> Withdraw Wallet Balance</a>');    
            $('#tdAmount'+id).val(obj.amount) ;
          */
          location.reload();
        }
        else if (obj.error=='2') 
        {
            $('#exampleModalLabelCredit').html('Zero amount not allowed'); 
            $('#divAddBalMsg').html(obj.msg);  
             $('#a_credit_limit')[0].click();   
        }
        else if (obj.error=='3') 
        {
            $('#divAddBalMsg').html(obj.msg);  
             $('#a_credit_limit')[0].click();   
        }
        else
        {
            $('#divAddBalMsg'+id).html('');    
        }
      $('#btnClose').click();
    },
    error: function (data, textStatus, errorThrown) {
        console.log(data+' '+textStatus+' '+errorThrown);
 
    },
});
}
function setRemarks(str)
{
  $('#txtRemarks').val(str);
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\statusdeal\resources\views/admin/customerTransactionList.blade.php ENDPATH**/ ?>