;
<?php $__env->startSection('page_title','Add Fund / Payment History'); ?>
<?php $__env->startSection('AddFund_select','active'); ?>
<?php $__env->startSection('container'); ?>

<?php if(session()->has('message')): ?>
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="bg-danger text-white border-radius font-wight-bold">Message</span>
  <?php echo e(session('message')); ?>

<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
<?php endif; ?>
<h2 class="title-1 m-b-10">Payment History Trash</h2>
<div class="row mb-2">
    
    <div class="col-4">
<a href="<?php echo e(url('admin/paymentRequest')); ?>" >
<button type="button" class="btn btn-danger" title="go to Trash">Go to Payment History</button>
</a>
        
    </div>
    
</div>
         <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-dark table-striped">
                                        <thead>
                                            <tr>
                                                <th colspan="2" class="text-center">Action</th>
                                                <th>ID</th>
                                                <th>Date</th>
                                                <th>Amount</th>
                                                <th>Trasanction Mode</th>
                                                <th>Tracnction Type</th>
                                                <th>Unique Number</th>
                                                <th>Status</th>
                                             </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                
                                                <td>
                                                    <a href="<?php echo e(url('admin/paymentRequest/restore/')); ?>/<?php echo e($list->id); ?>">
                                                    <button type="button" class="btn btn-success">Restore</button>
                                                    </a>
                                                </td>
                                                <td>
                                                    <a href="<?php echo e(url('admin/paymentRequest/forceDelete/')); ?>/<?php echo e($list->id); ?>">
                                                    <button type="button" class="btn btn-danger">Delete</button>
                                                    </a>
                                                    
                                                </td>

                                                <td><?php echo e($list->id); ?></td>
                                                <td><?php echo e($list->txnDate); ?></td>
                                                <td><?php echo e($list->payAmount); ?></td>
                                                <td><?php echo e($list->tranMode); ?></td>
                                                <td><?php echo e($list->tranType); ?></td>
                                                <td><?php echo e($list->UTR_U_Number); ?></td>
                                                <td>
                                                    <?php if($list->status==1): ?>
                                                    <span class="text-primary">Approved</span>

                                                    <?php elseif($list->status==2): ?>
                                                    <span class="text-danger">Rejected</span>
                                                    <?php elseif($list->status==0): ?>
                                                    <span class="text-warning">PENDING</span>
                                                    <?php endif; ?>
                                                    
                                                </td>

                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>

                                    </table>
                                </div>
                                
                                <!-- END DATA TABLE-->
                            </div>
                        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\test.mt\api\resources\views/admin/paymentHistory-trash.blade.php ENDPATH**/ ?>