<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title><?php echo $__env->yieldContent('page_title'); ?></title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons 
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">
  -->

  <link href="<?php echo e(asset('admin_assets/img/logo.png')); ?>" rel="icon">
  <link href="<?php echo e(asset('admin_assets/img/logo.png')); ?>" rel="apple-touch-icon">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?php echo e(asset('admin_assets/vendor/aos/aos.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('admin_assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('admin_assets/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('admin_assets/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('admin_assets/vendor/glightbox/css/glightbox.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('admin_assets/vendor/swiper/swiper-bundle.min.css')); ?>" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="<?php echo e(asset('admin_assets/css/style.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('admin_assets/css/style2.css')); ?>?v=1" rel="stylesheet">

  <script src="<?php echo e(asset('admin_assets/vendor/jquery-3.2.1.min.js')); ?>"></script>

  <!-- daterange picker -->
<link rel="stylesheet" href="<?php echo e(asset('admin_assets/plugins/daterangepicker/daterangepicker.css')); ?>">
<script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
<!-- InputMask -->
<script src="<?php echo e(asset('admin_assets/plugins/moment/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin_assets/plugins/inputmask/min/jquery.inputmask.bundle.min.js')); ?>"></script>
<!-- date-range-picker -->
<script src="<?php echo e(asset('admin_assets/plugins/daterangepicker/daterangepicker.js')); ?>"></script>

  <!-- =======================================================
  * Template Name: BizLand - v3.9.1
  * Template URL: https://bootstrapmade.com/bizland-bootstrap-business-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
  <style type="text/css">
    .myClass
    {
    background-image: var(--bs-gradient);
    }
</style>

</head>

<body>
<span class="d-none">
<?php echo e($image=session()->get('ADMIN_IMAGE')); ?>

<?php echo e($name=session()->get('ADMIN_NAME')); ?>

<?php echo e($email=session()->get('ADMIN_EMAIL')); ?>

<?php echo e($type=session()->get('ADMIN_TYPE')); ?>

<?php echo e($id=session()->get('ADMIN_ID')); ?>

<?php if($image==''): ?>
<?php echo e($image="NoImage.png"); ?>

<?php endif; ?>

<?php echo e($typeName=session()->get('typeName')); ?>

<?php echo e($AJAX_ROOT=Config::get('constants.AJAX_ROOT')); ?>

</span>

  <!-- ======= Top Bar ======= -->
  <section id="topbar" class="d-flex align-items-center">
    <div class="container d-flex justify-content-center justify-content-md-between">
      <div class="contact-info d-flex align-items-center">
        <i class="bi bi-envelope d-flex align-items-center"><a href="mailto:contact@statusdeal.in">contact@statusdeal.in</a></i>
        <i class="bi bi-phone d-flex align-items-center ms-4"><span>+91 9908650547 </span></i>
      </div>
      <?php if($type =='2'): ?>
      <span class="d-none d-lg-block"> Welcome back , <?php echo e(session()->get('ADMIN_NAME')); ?> </span>
      <?php endif; ?>
      <div class="social-links d-none d-md-flex align-items-center">
        <a href="#" class="twitter"><i class="bi bi-twitter d-none"></i></a>
        <a href="https://www.facebook.com/onWhatsAppStatus" class="facebook"><i class="bi bi-facebook"></i></a>
        <a href="#" class="instagram"><i class="bi bi-instagram d-none"></i></a>
        <a href="#" class="linkedin"><i class="bi bi-linkedin d-none"></i></i></a>
      </div>
    </div>
  </section>

  <!-- ======= Header ======= -->
  <header id="header" class="d-flex align-items-center">
    <div class="container d-flex align-items-center justify-content-between">

      <h1 class="logo d-none"><a href="<?php echo e(url('/')); ?>"><?php echo e(Config::get('constants.SITE_NAME')); ?> <span>.</span></a></h1>
      <a href="/" class="logo"><img src="<?php echo e(asset('admin_assets/img/statusDeal_Logo.png')); ?>" alt="Logo" ></a>

       
      <nav id="navbar" class="navbar">
        <ul>
           <?php if($type =='1' || $type =='2'): ?>
         <li><a class="nav-link scrollto <?php echo $__env->yieldContent('dashboard_select'); ?>" href="<?php echo e(url($typeName.'/dashboard')); ?>">Dashboard </a></li>
           <?php endif; ?>
           <?php if($type =='1'): ?>
          
          <li class="dropdown"><a href="javascript:void(0)" class="nav-link scrollto <?php echo $__env->yieldContent('Purchase_select'); ?>" ><span>Purchase List</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="<?php echo e(url($typeName.'/CustomerPurchase/pending')); ?>" >Pending List</a></li>
              <li><a href="<?php echo e(url($typeName.'/CustomerPurchase/approved')); ?>">Approved List</a></li>
              <li><a href="<?php echo e(url($typeName.'/CustomerPurchase/trash')); ?>">Decline List</a></li>
              
            </ul>
          </li>
      <li class="dropdown"><a class="nav-link scrollto <?php echo $__env->yieldContent('Report_select'); ?>" href="javascript:void(0)"><span>Report</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="<?php echo e(url($typeName.'/Customer/giftAchiever')); ?>"> Gift Achievers List</a></li>
              <li><a href="<?php echo e(url($typeName.'/Customer/birthDayList')); ?>"> Birth Day List</a></li>
              <li><a href="<?php echo e(url($typeName.'/Customer/giftHistory')); ?>">Gift History</a></li>
              <li><a href="<?php echo e(url($typeName.'/CustomerPurchase/summarize')); ?>">Summurise List</a></li>
              <li><a href="<?php echo e(url($typeName.'/Customer/List')); ?>">Customer List</a></li>
              <li><a href="<?php echo e(url($typeName.'/Customer/Wallet')); ?>">Customer Wallet</a></li>
              <li><a href="<?php echo e(url($typeName.'/Customer/AllTransactions')); ?>">All Wallet Transactions</a></li>
              <li><a href="<?php echo e(url($typeName.'/Customer/InActiveList')); ?>">Customer in Active List</a></li>
            </ul>
          </li>
          
          <li class="dropdown"><a href="javascript:void(0)" class="nav-link scrollto <?php echo $__env->yieldContent('Setting_select'); ?>" ><span>Setting</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
            <li><a href="<?php echo e(url($typeName.'/targetValue')); ?>" >set Target Value</a></li>
            <li><a href="<?php echo e(url($typeName.'/defaultCreditLimit')); ?>" >set Default Credit Limit</a></li>
          <li><a href="<?php echo e(url($typeName.'/images/list/1')); ?>" >set Banner Images</a></li>
          <li><a href="<?php echo e(url($typeName.'/images/list/2')); ?>" >set Deals of the day Images</a></li>
          <li><a href="<?php echo e(url($typeName.'/changePassword')); ?>/<?php echo e($id); ?>" >Change Password</a></li>
            </ul>
          </li>
         <?php endif; ?>
         <?php if($type =='2'): ?>
         <li><a class="nav-link scrollto <?php echo $__env->yieldContent('profile_select'); ?>" href="<?php echo e(url($typeName.'/profile')); ?>/<?php echo e($id); ?>">Profile</a></li>
           <?php endif; ?>
         <?php if($type =='1' || $type =='2'): ?>
         
          <li><a class="nav-link scrollto" href="<?php echo e(url($typeName.'/logout')); ?>">log out</a></li>
        <?php else: ?>
        <li><a class="nav-link scrollto" href="<?php echo e(url('customer')); ?>">login</a></li>
        <?php endif; ?>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>
     
      <!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="main">
    <div class="main-content container">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <?php if($type =='2'): ?>
                        <div class="row">
                        <div class="col-9 text-danger" style="font-weight:bold;text-align: center;">
                          Keep as much balance as you can in your wallet and enjoy the shopping benefits. You Can Withdraw Any Amount from Available Wallet Balance At anytime with Min Service Charge.
                        </div>
                        <div class="col-3"  style="text-align:right;font-weight: bold;">
                          Wallet Balance     <a class="btn btn-primary" href="<?php echo e(url($typeName.'/Transactions')); ?>/<?php echo e($id); ?>">Rs <?php echo e($walletBalance); ?></a>
      
                        </div>
                      </div>
                        <?php endif; ?>
                        <?php $__env->startSection('container'); ?>
                        <?php echo $__env->yieldSection(); ?>
                   
                    </div>
                </div>
            </div>
  </section><!-- End Hero -->



  <!-- ======= Footer ======= -->
  <footer id="footer" class="d-none">

    <div class="footer-newsletter">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-6">
            <h4>Join with Us</h4>
            <p>if you have any enquiry, send your email id, we will contact with us</p>
            <form action="" method="post">
              <input type="email" name="email"><input type="submit" value="Subscribe">
            </form>
          </div>
        </div>
      </div>
    </div>

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>Meonpay<span>.</span></h3>
            <p>
              Silchar<br>
              Assam,788001<br>
              India <br><br>
              <strong>Phone:</strong> +91 84868 36330<br>
              <strong>Email:</strong> info@meoanpay.com<br>
            </p>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Services</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Terms of service</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Privacy policy</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Services</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Recharge</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Bill Payment</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Commission</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Money Transfer</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Review</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Social Networks</h4>
            <p>You can connect with us through social networks</p>
            <div class="social-links mt-3">
              <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
              <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
              <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
              <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
              <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
            </div>
          </div>

        </div>
      </div>
    </div>

    <div class="container py-4">
      <div class="copyright">
        &copy; Copyright <strong><span>BizLand</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/bizland-bootstrap-business-template/ -->
        Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="<?php echo e(asset('admin_assets/vendor/purecounter/purecounter_vanilla.js')); ?>"></script>
  <script src="<?php echo e(asset('admin_assets/vendor/aos/aos.js')); ?>"></script>
  <script src="<?php echo e(asset('admin_assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin_assets/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin_assets/vendor/isotope-layout/isotope.pkgd.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin_assets/vendor/swiper/swiper-bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin_assets/vendor/waypoints/noframework.waypoints.js')); ?>"></script>
  <script src="<?php echo e(asset('admin_assets/vendor/php-email-form/validate.js')); ?>"></script>

<!-- import from cool admin template -->
    <script src="<?php echo e(asset('admin_assets/vendor/bootstrap-4.1/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_assets/vendor/bootstrap-4.1/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_assets/vendor/wow/wow.min.js')); ?>"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo e(asset('admin_assets/js/main.js')); ?>"></script>


</body>

</html><?php /**PATH E:\wamp64\www\statusdeal\resources\views/admin/layout.blade.php ENDPATH**/ ?>