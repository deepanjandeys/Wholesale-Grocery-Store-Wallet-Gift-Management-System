;
<?php $__env->startSection('page_title','admin Login'); ?>
<?php $__env->startSection('login_select','active'); ?>
<?php $__env->startSection('container'); ?>
<script type="text/javascript">
  function SignUp_click()
  {
    window.location='/sign_up';
  }
  
 </script>
<section class="get_in_touch">
        <h1 class="title"><?php echo e(Config::get('constants.SITE_NAME')); ?> ADMIN Reset Password</h1>
        <form action="<?php echo e(route('admin.manage_password_reset')); ?>" method="post">
            <?php echo csrf_field(); ?>
        <div class="container">
           <?php if(session('error')): ?>
<div class="alert alert-danger"><?php echo e(session('error')); ?></div>
<?php endif; ?>
            <div class="contact-form row">
              <div class="form-field col-lg-4">
                  <label for="user" class="label">User </label>
              </div>
              <div class="form-field col-lg-4">
                  <label for="user" class="label"><?php echo e($name); ?> </label>
              </div>
              <input type="hidden" name="id" value="<?php echo e($id); ?>">
            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-4">
                  <label for="password" class="label">Old Password</label>
              </div>
              <div class="form-field col-lg-8">
                <input type="password" name="password" id="password" class="input-text" value="<?php echo e(old('password')); ?>">
              </div>
            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-4">
                  <label for="newPassword" class="label">New Password</label>
              </div>
              <div class="form-field col-lg-8">
                <input type="password" name="newPassword" id="newPassword" class="input-text" value="<?php echo e(old('newPassword')); ?>">
              </div>
            </div>
            <div class="row">
              <div class="col-lg-6">
              <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <div class="alert alert-danger" role="alert">
                    <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="col-lg-6">
              <?php $__errorArgs = ['newPassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <div class="alert alert-danger" role="alert">
                    <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

              </div>
              
            </div>
            <div class="contact-form row">
              
               <div class="form-field col-lg-6">
                
               </div>
               <div class="form-field col-lg-6">
                <input class="submit-btn" type="submit" value="Reset" name="Reset">
               </div>
            </div>
        </div>
      </form>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\statusdeal\resources\views/admin/admin_reset_password.blade.php ENDPATH**/ ?>