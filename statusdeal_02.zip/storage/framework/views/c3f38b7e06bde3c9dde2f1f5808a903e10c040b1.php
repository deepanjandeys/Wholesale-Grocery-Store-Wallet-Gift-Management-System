;
<?php $__env->startSection('page_title','Gift History List'); ?>
<?php $__env->startSection('Report_select','active'); ?>
<?php $__env->startSection('container'); ?>
<?php echo e($AJAX_ROOT=Config::get('constants.AJAX_ROOT')); ?>

<section class="get_in_touch">
        <h1 class="title"><?php echo e(Config::get('constants.SITE_NAME')); ?> Gift History List</h1>
        
        <div class="container">
          <form>
         <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Month</label>
              </div>
              <div class="form-field col-lg-4">
                  
                  <select name="month" id="month" onchange="selMonth_Change()" class="input-text font-weight-bold" >
                        <option value=""></option>
                        <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($month==$list->id): ?>
                    <option selected value="<?php echo e($list->id); ?>" ><?php echo e($list->name); ?></option>
                            <?php else: ?>
                    <option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
              </div>
              <div class="form-field col-lg-1">
                  <label for="year" class="label">Year</label>
              </div>
              <div class="form-field col-lg-4">
                  
                  <select name="year" id="year" onchange="selMonth_Change()" class="input-text font-weight-bold" >
                        <option value=""></option>
                        <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($year==$list->value): ?>
                    <option selected ><?php echo e($list->value); ?></option>
                            <?php else: ?>
                    <option ><?php echo e($list->value); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

              </div>

            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Search</label>
              </div>
              <div class="form-field col-lg-9">
              <input type="search" name="search" placeholder="customer name/mobile/address" class="input-text" value="<?php echo e($search); ?>">
              </div>
              <div class="form-field col-lg-1">
                <input type="submit" name="search-btn" class="btn btn-primary" value="search">
              </div>
            </div>

            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Date From</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="Date_From" id="Date_From" placeholder="Date From" class="input-text" value="<?php echo e($Date_From); ?>">
              </div>
              <div class="form-field col-lg-1">
                  <label for="year" class="label">To</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="Date_To" id="Date_To" placeholder="Date To" class="input-text" value="<?php echo e($Date_To); ?>">

              </div>

            </div>
            </form>
          </div>
    </section>
    <div class="container">
            <div class="contact-form row">
              <div class="col-lg-12 overflow-scroll">
                <table class="table table-responsive table-dark table-light">
                  <tr> 
                     <th>
                      id
                    </th>
                    <th>
                      Date
                    </th>
                    <th>
                      Month
                    </th>
                    <th>
                      Cust id
                    </th>
                    <th>
                      Customer Name
                    </th>
                    <th>
                      Mobile No.
                    </th>
                    <th>
                      Address
                    </th>
                    <th>
                      Amount
                    </th>
                    <th colspan="2" class="text-center">action</th>
                   
                  </tr>
                  <?php if($CustomerGift->count()>0): ?>
                
                  <tbody>
                                            <?php $__currentLoopData = $CustomerGift; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                           
                                                <td><?php echo e($list->id); ?></td>
                                                <td><?php echo e($list->created_at); ?></td>
                                                <td><?php echo e($list->getMonths->name); ?></td>
                                                <td><?php echo e($list->custId); ?></td>
                                                <td><?php echo e($list->getCustomers->name); ?></td>
                                                <td><?php echo e($list->getCustomers->mobile); ?></td>
                                                <td><?php echo e($list->getCustomers->address); ?></td>
                                                <td style="text-align: right;"><?php echo e(number_format($list->basedAmount,2)); ?>

                                                  </td>
                                                 <td>
                                                    <?php if($list->status==1): ?>
                                                    
                                                       
                                                    <a href="<?php echo e(url('admin/CustomerGift/status/0/')); ?>/<?php echo e($list->id); ?>">
                                                    <button type="button" class="btn btn-warning">Disapprove</button>
                                                    </a>
                                                   
                                                    <?php endif; ?>
                                                    
                                                </td>
                                                 
                                                <td>
                                                  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal1" onclick="showViewDetails(<?php echo e($list->custId); ?>,<?php echo e($month); ?>,<?php echo e($year); ?>)"> View Detail</button>
                                                </td>
                                               
                                              </tr>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                              
                      </tbody>
                      <?php else: ?>
                      <tbody>
                        <tr>
                          <td colspan="10">Nothing to show</td>
                        </tr>
                      </tbody>
                      <?php endif; ?>
                </table>
              </div>
              <?php echo e($CustomerGift->links()); ?>

            </div>
            
            
        </div>
<!-- Modal -->
<div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">View Purchase Amount List</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <div id="divTable">please wait</div>
      </div>
      <div class="modal-footer">
        <input type="hidden" id="curPurchaseId" >
        <button type="button" class="btn btn-secondary" data-dismiss="modal">close</button>
        <button type="button" class="btn btn-primary d-none">Yes</button>
      </div>
    </div>
  </div>
</div>
<script>
function selMonth_Change()
{
  var m=$('#month').val();
  var y=$('#year').val();
  //var firstDay = new Date(y, m, 1);
  
  if (m<10) 
  {
    m = '0'+m;
  }

  var firstDay = '01-'+m+'-'+y;
  var lastDay = new Date(y, m , 0); //new Date(y, m + 1, 0);
  lastDay = lastDay.getDate()+'-'+m+'-'+y;

  $('#Date_From').val(firstDay);
  $('#Date_To').val(lastDay);

//console.log(firstDay+' '+lastDay);
}
    $('#Date_From').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

    $('#Date_To').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });


function showViewDetails(custId,month,year) {
   $.ajax({
    type: "POST",
    url: '<?php echo e($AJAX_ROOT); ?>/admin/getViewDetails',
    data: { custId: custId,month,year, _token: '<?php echo e(csrf_token()); ?>' },
    success: function (data) 
    {
        //console.log(' ** '+ data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
            $('#divTable').html(obj.str);
           
            }
        else
        {
            $('#divTable').html('');
           
        }
    
    },
    error: function (data, textStatus, errorThrown) {
        console.log(data+' '+textStatus+' '+errorThrown);
 
    },
});
}
  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\statusdeal\resources\views/admin/CustomerGiftHistortList.blade.php ENDPATH**/ ?>