;
<?php $__env->startSection('page_title','Password Rest link sent successfully'); ?>
<?php $__env->startSection('dashboard_select','active'); ?>
<?php $__env->startSection('container'); ?>
<script type="text/javascript">
   function home_click()
  {
    window.location='/';
  }
 </script>
 
<section class="get_in_touch">
        <h1 class="title">Password reset link</h1>
        <div class="card text-center">
  <div class="card-header">
    
  </div>
  <div class="card-body">
    <h5 class="card-title">Submitted Successfully</h5>
    <p class="card-text">An email is sent to your resgisterd email <?php echo e($email); ?>, open the link sent to your email and change your password</p>
 
    <a href="javascript:void(0)" onclick="home_click()" class="btn btn-primary" class="card-link">Go Home</a>
  </div>
  <div class="card-footer text-muted">
    status deal
  </div>
</div>

    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\statusdeal\resources\views/admin/forget_password_success.blade.php ENDPATH**/ ?>