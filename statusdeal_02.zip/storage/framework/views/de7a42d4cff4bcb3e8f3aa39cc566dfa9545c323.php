;
<?php $__env->startSection('page_title','Birth Day List'); ?>
<?php $__env->startSection('Report_select','active'); ?>
<?php $__env->startSection('container'); ?>

<section class="get_in_touch">
        <h1 class="title"><?php echo e(Config::get('constants.SITE_NAME')); ?> Birth Day List</h1>
        
        <div class="container">
          <form id="myForm">
         <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Month</label>
              </div>
              <div class="form-field col-lg-4">
                  
                  <select name="month" id="month" class="input-text font-weight-bold" >
                        <option value=""></option>
                        <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($month==$list->id): ?>
                    <option selected value="<?php echo e($list->id); ?>" ><?php echo e($list->name); ?></option>
                            <?php else: ?>
                    <option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
              </div>
              <div class="form-field col-lg-1">
                  <label for="year" class="label">Year</label>
              </div>
              <div class="form-field col-lg-4">
                  
                  <select name="year" id="year" class="input-text font-weight-bold" >
                        <option value=""></option>
                        <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($year==$list->value): ?>
                    <option selected ><?php echo e($list->value); ?></option>
                            <?php else: ?>
                    <option ><?php echo e($list->value); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

              </div>

            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Search</label>
              </div>
              <div class="form-field col-lg-9">
              <input type="search" name="search" placeholder="customer name/mobile/address" class="input-text" value="<?php echo e($search); ?>">
              </div>
              <div class="form-field col-lg-1">
                <input type="submit" name="search-btn" class="btn btn-primary" value="search">
              </div>
            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Filter By</label>
              </div>
              <div class="form-field col-lg-2">
                <?php 
                $a=''; $b='';
                if($rdbFilterBy=='m')
                {
                  $a='checked';
                }
                else if($rdbFilterBy=='d')
                {
                  $b='checked';
                }
                else 
                {
                  $a='checked'; // default is month
                }
                ?>
              <input type="radio" class="btn-check" name="rdbFilterBy" id="rdbMonth" autocomplete="off" value="m" <?php echo e($a); ?> >
              <label class="btn btn-outline-success" for="success-outlined" onclick="rdbMonth_click()">Month</label>
              </div>
              <div class="form-field col-lg-2">           
              <input type="radio" class="btn-check" name="rdbFilterBy" id="rdbToday" autocomplete="off" value="d" <?php echo e($b); ?> >
              <label class="btn btn-outline-success" for="success-outlined" onclick="rdbToday_click()" >To Day</label>
              </div>
             
            </div>
            </form>
          </div>
    </section>
    <div class="container">
            <div class="contact-form row">
              <div class="col-lg-12 overflow-scroll">
                <table class="table table-responsive table-dark table-light">
                  <tr> 
                     
                    <th>
                      Cust id
                    </th>
                    <th>
                      Customer Name
                    </th>
                    <th>
                      Mobile No.
                    </th>
                    <th>
                      Address
                    </th>
                    <th>
                      Date of Birth
                    </th>
                    <th>Birth Day</th>
                    <th>Status </th>
                    <th>Action</th>
                  </tr>
                  <?php if($birthDayList->count()>0): ?>
                  <?php 
                  $today=strtotime(date('d-m-Y'));
                  ?>
                  <tbody>
                                            <?php $__currentLoopData = $birthDayList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                           
                                                <td><?php echo e($list->id); ?></td>
                                                <td><?php echo e($list->name); ?></td>
                                                <td><?php echo e($list->mobile); ?></td>
                                                <td><?php echo e($list->address); ?></td>
                                                <td><?php echo e($list->DateOfBirth); ?></td>
                                                <td><?php echo e($list->BirthDay); ?></td>
                                                <td><?php 
                                                if(strtotime($list->BirthDay)<$today) 
                                                  {
                                                    echo "<span class='btn btn-warning'>past date</span>";
                                                  }
                                                  else if(strtotime($list->BirthDay)==$today) 
                                                  {
                                                    echo "<span class='btn btn-primary'>Today</span>";
                                                  }
                                                  else 
                                                  {
                                                      echo "<span class='btn btn-success'>up comming</span>";
                                                  }
                                                  
                                                ?></td>
                                                <td><input type="checkbox" id="chk<?php echo e($list->id); ?>"></td>
                                              </tr>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                      <?php else: ?>
                      <tbody>
                        <tr>
                          <td colspan="10">Nothing to show</td>
                        </tr>
                      </tbody>
                      <?php endif; ?>
                </table>
                <input type="button" style="text-align:right;" class="btn btn-primary" value="Send message">
              </div>
            </div>
            
            
        </div>
<script>

    $('#DateOfBirth').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

    function rdbMonth_click()
    {
      $('#rdbMonth').prop('checked', true);
      document.getElementById("myForm").submit();
    }

    function rdbToday_click()
    {
      $('#rdbToday').prop('checked', true);
      document.getElementById("myForm").submit();
    }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\statusdeal\resources\views/admin/customerBirthDayList.blade.php ENDPATH**/ ?>