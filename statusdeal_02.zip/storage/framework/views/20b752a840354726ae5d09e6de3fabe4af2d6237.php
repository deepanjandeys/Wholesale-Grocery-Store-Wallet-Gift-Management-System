;
<?php $__env->startSection('page_title','Bank Details'); ?>
<?php $__env->startSection('AddFund_select','active'); ?>
<?php $__env->startSection('container'); ?>
<span class="d-none">
    <?php echo e($typeName=session()->get('typeName')); ?>

</span>
<style type="text/css">
    .myClass
    {
    background-image: var(--bs-gradient);
    }
</style>
<div class="container">
	<div class="row bg-dark text-light mb-2">
        <div class="col-lg-12">
			<h2 class="title-1 m-b-10">Bank Details </h2>
        </div>
    </div>
    <div class="row bg-dark text-light rounded myClass mx-1">
        <div class="col-lg-12 pt-1">
            <div class="font-wight-bold">Bank Details of ICIC Bank A/C of MAA ENTERPRISE </div>
        </div>
        <div class="col-lg-12">
            
    <h2 class="h2Label d-none" style="text-align:center;">QR Code</h2>
    
        <img class="d-none" src="images/QRCode.jpg" style="width:250px;border:thin 2px red;" id="retailerImage" /><br />
        
        <table class="table table-dark table-light my-2">
                 <tr>
                    <th>Bank Name</th>
                    <td>ICICI BANK </td>
                </tr>
                <tr>
                    <th>Branch Name</th>
                    <td>U K DUTTA SARANI ROAD</td>
                </tr>

                <tr>
                    <th>A/C No. </th>
                    <td>252405500484</td>
                </tr>
                <tr>
                    <th>IFSC</th>
                    <td>ICIC0002524</td>
                </tr>
             </table>
</div>
</div>
<div class="row bg-dark text-light rounded myClass mx-1 my-2">
    <div class="col-lg-12">
        <div class="font-wight-bold">Bank Details of YES Bank Account of MAA ENTERPRISE </div>

        <table class="table table-dark table-light my-2">
                 <tr>
                    <th>A/C Holder Name</th>
                    <td>MAA ENTERPRISE </td>
                </tr>
                <tr>
                    <th>A/C No. </th>
                    <td>015163300001491</td>
                </tr>
                <tr>
                    <th>IFSC</th>
                    <td>YESB0000151</td>
                </tr>
              
                <tr>
                    <th>Bank Name</th>
                    <td>YES BANK</td>
                </tr>
                <tr>
                    <th>Branch Name</th>
                    <td>ShillongPatty, Silchar</td>
                </tr>
                
             </table>
         </div>
</div>
 </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\test.mt\api\resources\views/admin/BankDetails.blade.php ENDPATH**/ ?>