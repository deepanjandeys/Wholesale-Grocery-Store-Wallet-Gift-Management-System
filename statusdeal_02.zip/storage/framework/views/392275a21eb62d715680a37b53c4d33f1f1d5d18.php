;
<?php $__env->startSection('page_title','Customer Forget Password'); ?>
<?php $__env->startSection('dashboard_select','active'); ?>
<?php $__env->startSection('container'); ?>
<script type="text/javascript">
  function SignUp_click()
  {
    window.location='/sign_up';
  }
  function forget_password()
  {
    window.location='/customer/forget_password';
  }
 </script>
 
<section class="get_in_touch">
        <h1 class="title"><?php echo e(Config::get('constants.SITE_NAME')); ?> Forget Password</h1>
        <form action="<?php echo e(route('cust.forget.password')); ?>" method="post">
            <?php echo csrf_field(); ?>
        <div class="container">
           <?php if(session('error')): ?>
<div class="alert alert-danger"><?php echo e(session('error')); ?></div>
<?php endif; ?>
            <div class="contact-form row">
              <div class="form-field col-12 col-lg-4">
                  <label for="mobile" class="label">Mobile No.</label>
              </div>
              <div class="form-field col-12 col-lg-8">
                  <input type="text" name="mobile" id="mobile" class="input-text" value="<?php echo e(old('mobile')); ?>" >
              </div>
            </div>
            
            <div class="contact-form d-flex flex-column-reverse flex-lg-row ">
              
               <div class="form-field col-lg-6 text-center">
               </div>
               <div class="form-field col-lg-6">
                <input class="submit-btn" type="submit" value="Submit" name="Submit">
               </div>
            </div>
            
        </div>
      </form>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\statusdeal\resources\views/admin/forget_password.blade.php ENDPATH**/ ?>