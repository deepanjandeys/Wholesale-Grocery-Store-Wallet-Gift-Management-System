;
<?php $__env->startSection('page_title','Edit Callback'); ?>
<?php $__env->startSection('setting_select','active'); ?>
<?php $__env->startSection('container'); ?>
<h2 class="title-1 m-b-10">Call Back</h2>
<a href="<?php echo e(url('admin/dashboard')); ?>" >
<button type="button" class="btn btn-success"><i class="bi bi-box-arrow-left"></i></button>
</a>
         <div class="row m-t-30">
                            
                                <div class="col-lg-12">
                                    
                                <div class="card bg-dark text-light">
                                    <div class="card-body">
                                        <form action="<?php echo e(route('manage_callBack_process')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <label for="callBackRecharge" class="control-label mb-1">Call Back URL for Recharge</label>
                                                <input id="callBackRecharge" name="callBackRecharge" type="text" value="<?php echo e($callBackRecharge); ?>" class="form-control" aria-required="true" aria-invalid="false" >
                                                
                                                    <?php $__errorArgs = ['callBackRecharge'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger" role="alert">
                                                    <?php echo e($message); ?>

                                                    </div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                
                                            </div>
                                            <div class="form-group">
                                                <label for="callBackBill" class="control-label mb-1">Call Back URL for Bill</label>
                                                <input id="callBackBill" name="callBackBill" type="text" value="<?php echo e($callBackBill); ?>" class="form-control" aria-required="true" aria-invalid="false" >
                                                    <?php $__errorArgs = ['callBackBill'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger" role="alert">
                                                    <?php echo e($message); ?>

                                                    </div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="form-group">
                                                <label for="callBackMoney" class="control-label mb-1">CallBack URL for Money Transfer</label>
                                                <input id="callBackMoney" name="callBackMoney" type="text" value="<?php echo e($callBackMoney); ?>" class="form-control" aria-required="true" aria-invalid="false" >
                                                    <?php $__errorArgs = ['callBackMoney'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger" role="alert">
                                                    <?php echo e($message); ?>

                                                    </div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group">
                                                <label for="domain" class="control-label mb-1">Domain</label>
                                                <input id="domain" name="domain" type="text" value="<?php echo e($domain); ?>" class="form-control" aria-required="true" aria-invalid="false" >
                                                    <?php $__errorArgs = ['domain'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger" role="alert">
                                                    <?php echo e($message); ?>

                                                    </div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div>
                                                <input type="hidden" name="Mem_ID" value="<?php echo e($Mem_ID); ?>">
                                                <button id="callback-button" type="submit" class="btn btn-lg btn-info btn-block mt-2">
                                                    Submit
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\test.mt\api\resources\views/admin/edit_callBack.blade.php ENDPATH**/ ?>