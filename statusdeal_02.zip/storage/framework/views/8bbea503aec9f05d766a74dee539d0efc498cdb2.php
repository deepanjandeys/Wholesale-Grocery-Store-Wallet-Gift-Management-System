<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title><?php echo $__env->yieldContent('page_title'); ?></title>

    <!-- Fontfaces CSS-->
    <link href="<?php echo e(asset('admin_assets/css/font-face.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('admin_assets/vendor/font-awesome-4.7/css/font-awesome.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('admin_assets/vendor/font-awesome-5/css/fontawesome-all.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('admin_assets/vendor/mdi-font/css/material-design-iconic-font.min.css')); ?>" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="<?php echo e(asset('admin_assets/vendor/bootstrap-4.1/bootstrap.min.css')); ?>" rel="stylesheet" media="all">
    <style type="text/css">
        datalist {
  position: absolute;
  max-height: 20em;
  border: 0 none;
  overflow-x: hidden;
  overflow-y: auto;
}

datalist option {
  font-size: 0.8em;
  padding: 0.3em 1em;
  background-color: #ccc;
  cursor: pointer;
}

/* option active styles */
datalist option:hover,
datalist option:focus {
  color: #fff;
  background-color: #036;
  outline: 0 none;
}

#browserdata option {
  font-size: 1.8em;
  padding: 0.3em 1em;
  background-color: #ccc;
  cursor: pointer;
}
    </style>
<link href="<?php echo e(asset('admin_assets/css/theme.css')); ?>" rel="stylesheet" media="all">
<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
<!-- Jquery JS-->
    <script src="<?php echo e(asset('admin_assets/vendor/jquery-3.2.1.min.js')); ?>"></script>
    
<!--
<link href="<?php echo e(asset('admin_assets/dataList/dataList.css')); ?>" rel="stylesheet" media="all">
<script src="<?php echo e(asset('admin_assets/dataList/dataList.js')); ?>"></script>
<script src="<?php echo e(asset('admin_assets/dataList/dataList-stable.js')); ?>"></script>
-->
</head>
<span class="d-none">
<?php echo e($image=session()->get('ADMIN_IMAGE')); ?>

<?php echo e($name=session()->get('ADMIN_NAME')); ?>

<?php echo e($email=session()->get('ADMIN_EMAIL')); ?>

<?php echo e($type=session()->get('ADMIN_TYPE')); ?>

<?php echo e($Mem_ID=session()->get('ADMIN_ID')); ?>

<?php if($image==''): ?>
<?php echo e($image="NoImage.png"); ?>

<?php endif; ?>

<?php echo e($typeName=session()->get('typeName')); ?>

<?php echo e($AJAX_ROOT=Config::get('constants.AJAX_ROOT')); ?>

</span>
<body class="animsition">
    
   
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <header class="header-mobile d-block d-lg-none">
            <div class="header-mobile__bar">
                <div class="container-fluid">
                    <div class="header-mobile-inner">
                        <a class="logo" href="index.html">
                            <img src="<?php echo e(asset('admin_assets/images/icon/logo.png')); ?>" alt="User" />
                        </a>
                        <button class="hamburger hamburger--slider" type="button">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <nav class="navbar-mobile">
                <div class="container-fluid">
                    <ul class="navbar-mobile__list list-unstyled">
                        <li >
                            <a href="<?php echo e(url('$typeName/dashboard')); ?>">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                            
                        </li>
                       
                         <li>
                            <a href="<?php echo e(url('$typeName/dashboard')); ?>">
                                <i class="fas fa-tachometer-alt"></i>Customer</a>
                            
                        </li>
                        
                        <li>
                            <a href="<?php echo e(url('$typeName/whitelistIP')); ?>">
                                <i class="fas fa-tachometer-alt"></i>White List IPs</a>
                            
                        </li>
                        <li>
                            <a href="<?php echo e(url('$typeName/callBack')); ?>">
                                <i class="fas fa-tachometer-alt"></i>Callback</a>
                            
                        </li>
                        <li>
                            <a href="<?php echo e(url('$typeName/rechargeLog')); ?>">
                            <i class="fas fa-tachometer-alt"></i>Recharge Report</a>
                            
                        </li>
                    </ul>
                </div>
            </nav>
        </header>
        <!-- END HEADER MOBILE-->

        <!-- MENU SIDEBAR-->
        <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="#">
                    <img src="<?php echo e(asset('admin_assets/images/icon/logo.png')); ?>" alt="Cool Admin" />
                </a>
            </div>
            <div class="menu-sidebar__content js-scrollbar">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                  <li class="<?php echo $__env->yieldContent('dashboard_select'); ?>">
                      <a href="<?php echo e(url($typeName.'/dashboard')); ?>" onclick="toggleMenu('')">
                          <i class="fas fa-tachometer-alt"></i>Dashboard </a>
                  </li>
                 </ul>
             </nav>
                <nav class="navbar-sidebar">
                    <a href="javascript:void(0)" onclick="toggleMenu('menuMaster')">Master</a>

                    <ul class="list-unstyled navbar__list" id="menuMaster">
                      
                        <li class="<?php echo $__env->yieldContent('customer_select'); ?>">
                            <a href="<?php echo e(url($typeName.'/dashboard')); ?>">
                            <i class="fas fa-user"></i>Customer</a>
                        </li>
                        <li class="<?php echo $__env->yieldContent('whitelistIP_select'); ?>">
                            <a href="<?php echo e(url($typeName.'/whitelistIP')); ?>">
                            <i class="fas fa-user"></i>White List IPs</a>
                        </li>
                        <li class="<?php echo $__env->yieldContent('CallBack_select'); ?>">
                            <a href="<?php echo e(url($typeName.'/callBack')); ?>">
                            <i class="fas fa-user"></i>Callback link</a>
                        </li>
                        <li class="<?php echo $__env->yieldContent('APIkey_select'); ?>">
                            <a href="<?php echo e(url($typeName.'/APIkey')); ?>">
                            <i class="fas fa-user"></i>API Key</a>
                        </li>
                        <li class="<?php echo $__env->yieldContent('RechargeLog_select'); ?>">
                            <a href="<?php echo e(url($typeName.'/rechargeLog')); ?>">
                            <i class="fas fa-user"></i>Recharge Report</a>
                        </li>
                                                
                        <?php if($type==1): ?>
                        <li class="<?php echo $__env->yieldContent('User_select'); ?>">
                            <a href="<?php echo e(url('admin/users')); ?>">
                            <i class="fas fa-address-card"></i>Users</a>
                        </li>
                        <?php endif; ?>
                        
                    </ul>
                </nav>

                
            </div>
        </aside>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <header class="header-desktop">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="header-wrap">
                            <form class="form-header" action="" method="POST">
                                <input class="au-input au-input--xl" type="text" name="search" placeholder="Search for datas &amp; reports..." />
                                <button class="au-btn--submit" type="submit">
                                    <i class="zmdi zmdi-search"></i>
                                </button>
                            </form>
                            <div class="header-button">
                                <div class="noti-wrap">
                                    <div class="noti__item js-item-menu">
                                        <i class="zmdi zmdi-comment-more"></i>
                                        <span class="quantity">2</span>
                                        <div class="mess-dropdown js-dropdown">
                                            <div class="mess__title">
                                                <p>You have 2 news records need to approve</p>
                                            </div>
                                            <div class="mess__item">
                                                <div class="image img-cir img-40">
                                                    <img src="<?php echo e(asset('/storage/media').'/'.$image); ?>" alt="Sale agent " />
                                                </div>
                                                <div class="content">
                                                    <h6>Sale agent 1 create an account</h6>
                                                    <p>Approve this</p>
                                                    <span class="time">3 min ago</span>
                                                </div>
                                            </div>
                                            <div class="mess__item">
                                                <div class="image img-cir img-40">
                                                    <img src="<?php echo e(asset('/storage/media').'/'.$image); ?>" alt="Diane Myers" />
                                                </div>
                                                <div class="content">
                                                    <h6>Sale agent 1 </h6>
                                                    <p>Make sale to Customer 1</p>
                                                    <span class="time">Yesterday</span>
                                                </div>
                                            </div>
                                            <div class="mess__footer">
                                                <a href="#">View all messages</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="noti__item js-item-menu">
                                        <i class="zmdi zmdi-email"></i>
                                        <span class="quantity">1</span>
                                        <div class="email-dropdown js-dropdown">
                                            <div class="email__title">
                                                <p>You have 3 New Emails</p>
                                            </div>
                                            <div class="email__item">
                                                <div class="image img-cir img-40">
                                                    <img src="<?php echo e(asset('/storage/media').'/'.$image); ?>" alt="Cynthia Harvey" />
                                                </div>
                                                <div class="content">
                                                    <p>Meeting about new dashboard...</p>
                                                    <span>Cynthia Harvey, 3 min ago</span>
                                                </div>
                                            </div>
                                            <div class="email__item">
                                                <div class="image img-cir img-40">
                                                    <img src="<?php echo e(asset('/storage/media').'/'.$image); ?>" alt="Cynthia Harvey" />
                                                </div>
                                                <div class="content">
                                                    <p>Meeting about new dashboard...</p>
                                                    <span>Cynthia Harvey, Yesterday</span>
                                                </div>
                                            </div>
                                            <div class="email__item">
                                                <div class="image img-cir img-40">
                                                    <img src="<?php echo e(asset('/storage/media').'/'.$image); ?>" alt="Cynthia Harvey" />
                                                </div>
                                                <div class="content">
                                                    <p>Meeting about new dashboard...</p>
                                                    <span>Cynthia Harvey, April 12,,2018</span>
                                                </div>
                                            </div>
                                            <div class="email__footer">
                                                <a href="#">See all emails</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="noti__item js-item-menu">
                                        <i class="zmdi zmdi-notifications"></i>
                                        <span class="quantity">3</span>
                                        <div class="notifi-dropdown js-dropdown">
                                            <div class="notifi__title">
                                                <p>You have 3 Notifications</p>
                                            </div>
                                            <div class="notifi__item">
                                                <div class="bg-c1 img-cir img-40">
                                                    <i class="zmdi zmdi-email-open"></i>
                                                </div>
                                                <div class="content">
                                                    <p>You got a email notification</p>
                                                    <span class="date">April 12, 2018 06:50</span>
                                                </div>
                                            </div>
                                            <div class="notifi__item">
                                                <div class="bg-c2 img-cir img-40">
                                                    <i class="zmdi zmdi-account-box"></i>
                                                </div>
                                                <div class="content">
                                                    <p>Your account has been blocked</p>
                                                    <span class="date">April 12, 2018 06:50</span>
                                                </div>
                                            </div>
                                            <div class="notifi__item">
                                                <div class="bg-c3 img-cir img-40">
                                                    <i class="zmdi zmdi-file-text"></i>
                                                </div>
                                                <div class="content">
                                                    <p>You got a new file</p>
                                                    <span class="date">April 12, 2018 06:50</span>
                                                </div>
                                            </div>
                                            <div class="notifi__footer">
                                                <a href="#">All notifications</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu">
                                        <div class="image">
                                            <img src="<?php echo e(asset('/storage/media').'/'.$image); ?>" alt="John Doe" />
                                        </div>
                                        <div class="content">
                                            <a class="js-acc-btn" href="#"><?php echo e($name); ?></a>
                                        </div>
                                        <div class="account-dropdown js-dropdown">
                                            <div class="info clearfix">
                                                <div class="image">
                                                    <a href="#">
                                                        <img src="<?php echo e(asset('/storage/media').'/'.$image); ?>" alt="<?php echo e($name); ?>" />
                                                    </a>
                                                </div>
                                                <div class="content">
                                                    <h5 class="name">
                                                        <a href="#"><?php echo e($name); ?></a>
                                                    </h5>
                                                    <span class="email"><?php echo e($name); ?></span>
                                                </div>
                                            </div>
                                            <div class="account-dropdown__body">
                                                <div class="account-dropdown__item">
                                                    <a href="#">
                                                        <i class="zmdi zmdi-account"></i>Report</a>
                                                </div>
                                                <div class="account-dropdown__item">
                                                    <a href="#">
                                                        <i class="zmdi zmdi-settings"></i>Setting</a>
                                                </div>
                                                <div class="account-dropdown__item">
                                                    <a href="#">
                                                        <i class="zmdi zmdi-money-box"></i>Billing</a>
                                                </div>
                                            </div>
                                            <div class="account-dropdown__footer">
                                                <a href="<?php echo e(url($typeName.'/logout')); ?>">
                                                    <i class="zmdi zmdi-power"></i>Logout</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <!-- HEADER DESKTOP-->
           <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <?php $__env->startSection('container'); ?>
                        <?php echo $__env->yieldSection(); ?>
                   
                    </div>
                </div>
            </div>
            <!-- END PAGE CONTAINER-->
        </div>

    </div>

    <!-- Bootstrap JS-->
    <script src="<?php echo e(asset('admin_assets/vendor/bootstrap-4.1/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_assets/vendor/bootstrap-4.1/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_assets/vendor/wow/wow.min.js')); ?>"></script>
    <!-- Main JS-->
    <script src="<?php echo e(asset('admin_assets/js/main.js')); ?>"></script>
    <?php echo e($curMenu=session()->get('curMenu')); ?>

  
    <script type="text/javascript">
        var showMaster=1;
        var showTran;
        var showReport;
        var showTool;

         $('#menuMaster').show();
         /*
        <?php if($curMenu=='menuMaster'): ?>
                 $('#menuMaster').show();
                 showMaster=1;
         <?php else: ?> 
                $('#menuMaster').hide();
                showMaster=0;
         <?php endif; ?>

          <?php if($curMenu=='menuTran'): ?>
                 $('#menuTran').show();
                 showTran=1;
         <?php else: ?> 
                $('#menuTran').hide();
                showTran=0;
         <?php endif; ?>

        <?php if($curMenu=='menuReport'): ?>
            $('#menuReport').show();
            showReport=1;
        <?php else: ?> 
            $('#menuReport').hide();
            showReport=0;
        <?php endif; ?>

        <?php if($curMenu=='menuTool'): ?>
            $('#menuTool').show();
            showTool=1;
        <?php else: ?> 
            $('#menuTool').hide();
            showTool=0;
        <?php endif; ?>
        */
        
    
function setCurmenu(value) {
   $.ajax({
    type: "POST",
    url: '<?php echo e($AJAX_ROOT); ?>/<?php echo e($typeName); ?>/setCurmenu',
    data: { curMenu: value, _token: '<?php echo e(csrf_token()); ?>' },
    success: function (data) 
    {
        console.log(data);
    },   
    error: function (data, textStatus, errorThrown) {
        console.log(data);
 
    },
});
}
var oldCurMenu='none';
function toggleMenu(s)
    {
        if(s != oldCurMenu)
        {
        $('#'+oldCurMenu).hide('slow');    
        }

        oldCurMenu=s;
        //////////////
        $('#'+s).toggle('slow');

        if(s=='menuMaster' && showMaster==1)
            {
                showMaster=0;
                s='';
            }
        else if(s=='menuMaster' && showMaster==0)
            {
                showMaster=1;
            }
        else if(s=='menuTran' && showTran==1)
            {
                showTran=0;
                s='';
            }
        else if(s=='menuTran' && showTran==0)
            {
                showTran=1;
            }
        else if(s=='menuReport' && showReport==1)
            {
                showReport=0;
                s='';
            }
        else if(s=='menuReport' && showReport==0)
            showReport=1;
        else if(s=='menuTool' && showTool==1)
            {
                showTool=0;
                s='';
            }
        else if(s=='menuTool' && showTool==0)
            showTool=1;
        
        setCurmenu(s);
    }
</script>
<?php //dd(Session::all()); ?>
</body>

</html>
<!-- end document-->
<?php /**PATH E:\wamp64\www\test.mt\services\resources\views/admin/layout.blade.php ENDPATH**/ ?>