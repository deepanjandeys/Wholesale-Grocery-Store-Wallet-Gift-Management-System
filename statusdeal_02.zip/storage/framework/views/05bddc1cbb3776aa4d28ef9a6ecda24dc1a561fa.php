;
<?php $__env->startSection('page_title','Set Default Credit Limit vaue of Customer'); ?>
<?php $__env->startSection('Setting_select','active'); ?>
<?php $__env->startSection('container'); ?>

<section class="get_in_touch">
        <h1 class="title"><?php echo e(Config::get('constants.SITE_NAME')); ?> set Default Credit Limit vaue of Customer</h1>
        <form action="<?php echo e(route('admin.credit_limit_set')); ?>" method="post">
            <?php echo csrf_field(); ?>
        <div class="container">
           <?php if(session('error')): ?>
<div class="alert alert-danger"><?php echo e(session('error')); ?></div>
<?php endif; ?>
            <div class="contact-form row">
              <div class="form-field col-lg-4">
                  <label for="credit_limit" class="label">Default Credit Limit value of Customer</label>
              </div>
              <div class="form-field col-lg-8">
                  <input type="text" name="credit_limit" id="credit_limit" class="input-text" value="<?php echo e($credit_limit); ?>" >
              </div>
            </div>
            
            <div class="contact-form row">
              
               <div class="form-field col-lg-6">
                
               </div>
               <div class="form-field col-lg-6">
                <input class="submit-btn" type="submit" value="Save" name="Save">
               </div>
            </div>
        </div>
      </form>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\statusdeal\resources\views/admin/edit_defaultCreditLimit.blade.php ENDPATH**/ ?>