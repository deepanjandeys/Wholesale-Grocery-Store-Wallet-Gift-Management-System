;
<?php $__env->startSection('page_title','images List'); ?>
<?php $__env->startSection('Setting_select','active'); ?>
<?php $__env->startSection('container'); ?>

<section class="get_in_touch">
        <h1 class="title"><?php echo e(Config::get('constants.SITE_NAME')); ?> images List</h1>
        
        <div class="container">
          <form id="myForm">
         <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">type</label>
              </div>
              <div class="form-field col-lg-4">
                  
                  <select name="type" id="type" class="input-text font-weight-bold" >
                        <option value=""></option>
                        <?php $__currentLoopData = $image_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($img_type==$list->id): ?>
                    <option selected value="<?php echo e($list->id); ?>" ><?php echo e($list->name); ?></option>
                            <?php else: ?>
                    <option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
              </div>
              <div class="form-field col-lg-1">
                  
              </div>
              <div class="form-field col-lg-4">
                  
                  

              </div>

            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Search</label>
              </div>
              <div class="form-field col-lg-9">
              <input type="search" name="search" placeholder="caption " class="input-text" value="<?php echo e($search); ?>">
              </div>
              <div class="form-field col-lg-1">
                <input type="submit" name="search-btn" class="btn btn-primary" value="search">
              </div>
            </div>
            
            </form>
          </div>
    </section>
    <div class="container">
            <div class="contact-form row">
              <div class="col-lg-12 overflow-scroll">
                
                <a href="<?php echo e(url('admin/images/edit_images/')); ?>/<?php echo e($img_type); ?>" >
<button type="button" class="btn btn-success">Add images</button>
</a>

                <table class="table table-responsive table-dark table-light" border="1">
                  
                  <?php if($Images->count()>0): ?>
                  <?php 
                  $today=strtotime(date('d-m-Y'));
                  ?>
                  <tbody>
                                            <?php $__currentLoopData = $Images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr><td colspan="4"> - </td></tr>
                                                <tr>
                                                <td>id</td>
                                                <th><?php echo e($list->id); ?></th>
                                                <td rowspan="3">
                                                    <img src="<?php echo e(asset('/storage').'/media/'.$list->filename); ?>" alt="<?php echo e(asset('/storage').'/media/'.$list->filename); ?>" style="width:350px;" />
                                                    
                                                </td>
                                                <td rowspan="3">
  <a href="<?php echo e(url('admin/images/edit_images/')); ?>/<?php echo e($img_type); ?>/<?php echo e($list->id); ?>">
                                                    <button type="button" class="btn btn-success">Edit</button>
                                                    </a>
  <a href="<?php echo e(url('admin/images/delete/')); ?>/<?php echo e($img_type); ?>/<?php echo e($list->id); ?>">
                                                    <button type="button" class="btn btn-danger">Delete</button>
                                                    </a>
                                                </td>
                                                
                                      
                                </tr>
                                <tr>
                                    <td>Caption</td>
                                    <th><?php echo e($list->caption); ?></th>
                                </tr>
                                <tr>
                                    <td>sub-caption</td>
                                    <th><?php echo e($list->sub_caption); ?></th>
                                </tr>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                      <?php else: ?>
                      <tbody>
                        <tr>
                          <td colspan="10">Nothing to show</td>
                        </tr>
                      </tbody>
                      <?php endif; ?>
                </table>
                
              </div>
            </div>
            
            
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\statusdeal\resources\views/admin/imagesList.blade.php ENDPATH**/ ?>