;
<?php $__env->startSection('page_title','Edit Payment Request'); ?>
<?php $__env->startSection('AddFund_select','active'); ?>
<?php $__env->startSection('container'); ?>
<h2 class="title-1 m-b-10">Payment Request</h2>
<a href="<?php echo e(url('admin/dashboard')); ?>" >
<button type="button" class="btn btn-success"><i class="bi bi-box-arrow-left"></i></button>
</a>
         <div class="row m-t-30">
                            
                                <div class="col-lg-12">
                                    
                                <div class="card bg-dark text-light">
                                    <div class="card-body">
                                        <form action="<?php echo e(route('manage_paymentRequest_process')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <label for="txnDate" class="control-label mb-1">Date</label>
                                                <input id="txnDate" name="txnDate" type="text" value="<?php echo e($txnDate); ?>" class="form-control" aria-required="true" aria-invalid="false" >
                                                
                                                    <?php $__errorArgs = ['txnDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger" role="alert">
                                                    <?php echo e($message); ?>

                                                    </div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                
                                            </div>
                                            <div class="form-group">
                                                <label for="payAmount" class="control-label mb-1">Amount</label>
                                                <input id="payAmount" name="payAmount" type="text" value="<?php echo e($payAmount); ?>" class="form-control" aria-required="true" aria-invalid="false" >
                                                    <?php $__errorArgs = ['payAmount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger" role="alert">
                                                    <?php echo e($message); ?>

                                                    </div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="form-group">
                                                <label for="UTR_U_Number" class="control-label mb-1">UTR or Unique Number</label>
                                                <input id="UTR_U_Number" name="UTR_U_Number" type="text" value="<?php echo e($UTR_U_Number); ?>" class="form-control" aria-required="true" aria-invalid="false" >
                                                    <?php $__errorArgs = ['UTR_U_Number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger" role="alert">
                                                    <?php echo e($message); ?>

                                                    </div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group">
                                                <label for="tranMode" class="control-label mb-1">Transaction Mode</label>
                                                <input id="tranMode" name="tranMode" type="text" value="<?php echo e($tranMode); ?>" class="form-control" aria-required="true" aria-invalid="false" >
                                                    <?php $__errorArgs = ['tranMode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger" role="alert">
                                                    <?php echo e($message); ?>

                                                    </div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group">
                                                <label for="tranType" class="control-label mb-1">Transaction Type</label>
                                                <input id="tranType" name="tranType" type="text" value="<?php echo e($tranType); ?>" class="form-control" aria-required="true" aria-invalid="false" >
                                                    <?php $__errorArgs = ['tranType'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger" role="alert">
                                                    <?php echo e($message); ?>

                                                    </div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            
                                            <div class="form-group">
                                                <label for="Remarks" class="control-label mb-1">Remarks</label>
                                                <input id="Remarks" name="Remarks" type="text" value="<?php echo e($Remarks); ?>" class="form-control" aria-required="true" aria-invalid="false" >
                                                    <?php $__errorArgs = ['Remarks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger" role="alert">
                                                    <?php echo e($message); ?>

                                                    </div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            

                                            <div>
                                                <input type="hidden" name="memID" value="<?php echo e($memID); ?>">
                                                <input type="hidden" name="id" value="<?php echo e($id); ?>">
                                                <button id="paymentRequest-button" type="submit" class="btn btn-lg btn-info btn-block mt-2">
                                                    Submit
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
<script>

    $('#txnDate').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });
   

    <?php 
        if (isset($txnDate) && $id>0 )
        {
    ?>
    $('#txnDate').val('<?php echo $txnDate; ?>');
    <?php 
    }
    ?>
     
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\test.mt\api\resources\views/admin/edit_PaymentRequest.blade.php ENDPATH**/ ?>