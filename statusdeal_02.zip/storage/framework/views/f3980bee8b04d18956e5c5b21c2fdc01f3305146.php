;
<?php $__env->startSection('page_title','Edit whitelistIP'); ?>
<?php $__env->startSection('whitelistIP_select','active'); ?>
<?php $__env->startSection('container'); ?> 
<h2 class="title-1 m-b-10">Edit whitelist IP</h2>


<a href="<?php echo e(url('admin/whitelistIP_select')); ?>" >
<button type="button" class="btn btn-success">Back</button>
</a>
         <div class="row m-t-30">
                            
                                <div class="col-lg-12">
                                    
                                <div class="card">
                                    <div class="card-body">
                                        <form action="<?php echo e(route('manage_whitelistIP_process')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <label for="Branch_name" class="control-label mb-1">whitelist IP</label>
                                                <input id="ip_address" name="ip_address" type="text" value="<?php echo e($ip_address); ?>" class="form-control" aria-required="true" aria-invalid="false" required>
                                                
                                                    <?php $__errorArgs = ['ip_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger" role="alert">
                                                    <?php echo e($message); ?>

                                                    </div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                
                                            </div>
                                            
                                            <div class="form-group">
                                                <label for="status" class="control-label mb-1">status</label>
                                                    <select id="status" name="status" class="form-control" aria-required="true" aria-invalid="false" required>
                                                        <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($status==$list->id): ?>
                                                        <option selected value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
                                                            <?php else: ?>
                                                        <option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                           
                                                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger" role="alert">
                                                    <?php echo e($message); ?>

                                                    </div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div>
                                                <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
                                                    Submit
                                                </button>
                                            </div>
                                            <input type="hidden" name="Mem_ID" value="<?php echo e($Mem_ID); ?>">
                                            <input type="hidden" name="id" value="<?php echo e($id); ?>">
                                        </form>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\test.mt\services\resources\views/admin/edit_whitelistIP.blade.php ENDPATH**/ ?>