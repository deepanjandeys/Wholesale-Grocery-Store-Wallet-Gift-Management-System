;
<?php $__env->startSection('page_title','Dashboard'); ?>
<?php $__env->startSection('dashboard_select','active'); ?>
<?php $__env->startSection('container'); ?>
<script type="text/javascript">
  function SignUp_click()
  {
    window.location='/sign_up';
  }
  
 </script>
<section class="get_in_touch">
        <h1 class="title"><?php echo e(Config::get('constants.SITE_NAME')); ?> Login</h1>
        <form action="<?php echo e(route('cust.auth')); ?>" method="post">
            <?php echo csrf_field(); ?>
        <div class="container">
           <?php if(session('error')): ?>
<div class="alert alert-danger"><?php echo e(session('error')); ?></div>
<?php endif; ?>
            <div class="contact-form row">
              <div class="form-field col-4">
                  <label for="mobile" class="label">Mobile No.</label>
              </div>
              <div class="form-field col-8">
                  <input type="text" name="mobile" id="mobile" class="input-text" value="<?php echo e(old('mobile')); ?>" >
              </div>
            </div>
            <div class="contact-form row">
              <div class="form-field col-4">
                  <label for="password" class="label">password</label>
              </div>
              <div class="form-field col-8">
                <input type="password" name="password" id="password" class="input-text" value="<?php echo e(old('password')); ?>">
              </div>
            </div>
            <div class="contact-form row">
              
               <div class="form-field col-lg-6">
                <input class="submit-btn" type="button" onclick="SignUp_click()" value="Sign Up" name="SignUp">
               </div>
               <div class="form-field col-lg-6">
                <input class="submit-btn" type="submit" value="Login" name="SignIn">
               </div>
            </div>
        </div>
      </form>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\statusdeal\resources\views/admin/login.blade.php ENDPATH**/ ?>