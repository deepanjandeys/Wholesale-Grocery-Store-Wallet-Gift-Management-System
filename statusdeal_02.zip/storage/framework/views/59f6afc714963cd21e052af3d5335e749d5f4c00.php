<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oleo+Script&family=Rubik:wght@300&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" integrity="sha384-EvBWSlnoFgZlXJvpzS+MAUEjvN7+gcCwH+qh7GRFOGgZO0PuwOFro7qPOJnLfe7l" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_assets/css/style.css')); ?>">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <title><?php echo e(Config::get('constants.SITE_NAME')); ?>    </title>
    <style type="text/css">
     /* .slideImg 
      {
        height: 400px;
      }
      @media  screen and (max-width: 576px)
      {
        .slideImg 
      {
        height: 500px;
      }
      }*/
	  
      .card-img
      {
        height: 200px;
      }
	  .bgColor
	  {
	  background:#F5F5F5;
	  }
    </style>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <div class="container">
        <a class="navbar-brand" href="index.html"><?php echo e(Config::get('constants.SITE_NAME')); ?>

        </a>
      <a class="btn btn-outline-success" href="/admin">
        <i class="bi bi-person-plus-fill"></i>&nbsp;<b>login</b>
      </a>
      </div>

    </nav>
    <section class="banner">
      <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
          <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1">
          </button>
          <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2">
          </button>
          <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3">
          </button>
          
        </div>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="<?php echo e(asset('admin_assets/images/mobileRecharge-01.jpg')); ?>" class="d-block w-100 slideImg" alt="">
          </div>
          <div class="carousel-item">
            <img src="<?php echo e(asset('admin_assets/images/mobileRecharge-02.jpg')); ?>" class="d-block w-100 slideImg" alt="">
          </div>
          <div class="carousel-item">
            <img src="<?php echo e(asset('admin_assets/images/mobileRecharge-03.jpg')); ?>" class="d-block w-100 slideImg" alt="">
          </div>
          
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true">
          </span>
          <span class="visually-hidden">Previous
          </span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true">
          </span>
          <span class="visually-hidden">Next
          </span>
        </button>
      </div>
    </section>
    <div class="m-5">-</div>
    <section class="content">
      <div class="container">
      <div class="row">
        <div class="col-lg-6  mb-3 bgColor shadow rounded">
          <h3 class="h3" style="color:#AA026F;" >Welcome to <?php echo e(Config::get('constants.SITE_NAME')); ?>

          </h3>
          <p class="text-justify pl-2">
		  We provide purchase of goods with very easy payment mode. 
          </p>
        </div>
        <div class="col-lg-6">
          <div class="rounded bgColor">
            <h3 class="h3">Contact Us
            </h3>
            <p class="font-weight-bold">
              <i class="bi bi-telephone-plus-fill">
              </i><a href="tel:9988776655"><b> 9988776655 <b/></a>
            <br/>
              <i class="bi bi-envelope">
              </i><a href="mailto:example@gmail.com">example@gmail.com</a>
            </p>
          </div>
          <div class="rounded bgColor shadow">
            <h4>Address
            </h4>
            <p class="lead">
              Silchar, Assam 788005
            </p>
          </div>
        </div>
      </div>
      </div>
    </section>


  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous">
  </script>
 </body>
</html>
<?php /**PATH E:\wamp64\www\test.mt\services\resources\views/index.blade.php ENDPATH**/ ?>