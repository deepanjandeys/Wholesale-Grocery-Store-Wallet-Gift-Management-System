;
<?php $__env->startSection('page_title','Recharge Log'); ?>
<?php $__env->startSection('Report_select','active'); ?>
<?php $__env->startSection('container'); ?>

<?php if(session()->has('message')): ?>
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="badge badge-pill badge-success">Message</span>
  <?php echo e(session('message')); ?>

<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
<?php endif; ?>
<?php 
if(isset($_GET['Date_FROM']))
    $Date_FROM=$_GET['Date_FROM'];
else
    $Date_FROM=date('d-m-Y');

if(isset($_GET['Date_TO']))
    $Date_TO=$_GET['Date_TO'];
else
    $Date_TO=date('d-m-Y');
?>
<h2 class="title-1 m-b-10">Report Recharge Log </h2>
<form action="" method="get" >
    <div class="row">
        <div class="col-lg-4 mb-1">
            <input type="search" name="search" class="form-control" placeholder="Ordrer No./Reference No." value="<?php echo e($search); ?>">        
        </div>
        <div class="col-lg-2 mb-1">
        <select id="Op_Code" name="Op_Code" class="form-control" aria-required="true" aria-invalid="false">
            <option value="">All Operator</option>
            <?php $__currentLoopData = $operators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($Op_Code==$list->Op_Code): ?>
                <option selected value="<?php echo e($list->Op_Code); ?>"><?php echo e($list->Op_Code); ?></option>
                <?php else: ?>
                <option value="<?php echo e($list->Op_Code); ?>"><?php echo e($list->Op_Code); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select> 
        </div>
        <div class="col-lg-2 mb-1">
        <select id="circle" name="circle" class="form-control" aria-required="true" aria-invalid="false">
            <option value="">All Circle</option>
            <?php $__currentLoopData = $circles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($circle==$list->Code): ?>
                <option selected value="<?php echo e($list->Code); ?>"><?php echo e($list->Ope_Cir_Name); ?></option>
                <?php else: ?>
                <option value="<?php echo e($list->Code); ?>"><?php echo e($list->Ope_Cir_Name); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select> 
        </div>
        <div class="col-lg-2 mb-1">
        <select id="status" name="status" class="form-control" aria-required="true" aria-invalid="false">
            
            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($status==$list->Sl): ?>
                <option selected value="<?php echo e($list->Sl); ?>"><?php echo e($list->Name); ?></option>
                <?php else: ?>
                <option value="<?php echo e($list->Sl); ?>"><?php echo e($list->Name); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select> 
        </div>
        <div class="col-lg-6 mb-1">
            <div class="row">
                <div class="col-lg-4 mb-1">
                    <select name="Date_OPR" id="Date_OPR" class="form-control" >
                        <option value="">Date</option>
                        <?php $__currentLoopData = $compOperators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($Date_OPR==$list->name): ?>
                    <option selected ><?php echo e($list->name); ?></option>
                            <?php else: ?>
                    <option ><?php echo e($list->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                </div>
                <div class="col-lg-4 mb-1">
                <input type="search" name="Date_FROM" id="Date_FROM" class="form-control" placeholder="From" value="<?php echo e($Date_FROM); ?>">  
            </div>
            <div class="col-lg-4 mb-1">
                <input type="search" name="Date_TO" id="Date_TO" class="form-control" placeholder="To" value="<?php echo e($Date_TO); ?>">    
            </div>
            
            </div>
        </div>
        <div class="col-2 mb-1">
        <button class="btn btn-primary" title="Search"><i class="bi bi-search"></i></button>   
    </div>
    <div class="col-2 mb-1">
        <a href="<?php echo e(url('admin/rechargeLog')); ?>" >
            <button type="button" class="btn btn-primary" title="Reset"><i class="bi bi-arrow-clockwise"></i></button>
        </a>     
        </div>
    </div>
</form>

         <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-dark table-light">
                                        <thead>
                                             <tr>
                                                <th>ID</th>
                                                <th>Number</th>
                                                <th>Operator</th>
                                                <th>Circle</th>
                                                <th>User Order ID</th>
                                                <th>Order ID</th>
                                                <th>Reference No.</th>
                                                <th>Date Time</th>
                                                <th>Amont</th>
                                                <th>Commission</th>
                                                <th>Status</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                           <?php $__currentLoopData = $rechargeLog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                
                                                <td><?php echo e($list->Sl); ?></td>
                                                <td><?php echo e($list->m_bill_no); ?></td>
                                                <td>                                  
                                                    <?php echo e($list->getOperator->Op_Name); ?>

                                                </td>
                                                <td>                                  
                                               <?php echo e($list->getCircle->Ope_Cir_Name); ?>

                                                </td>
                                                <td><?php echo e($list->API_Partner_OrderId); ?></td>
                                                <td><?php echo e($list->orderNo); ?></td>
                                                <td><?php echo e($list->TransId); ?></td>
                                                <td><?php echo e($list->date_tim); ?></td>
                                                <td><?php echo e(number_format($list->rechargeAmt,2)); ?></td>
                                                <td><?php echo e(number_format($list->Commission,2)); ?></td>
                                                <td>
                                                <span class="text-primary"><?php echo e($list->Status); ?></span>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <?php echo e($rechargeLog->links()); ?>

                                <!-- END DATA TABLE-->
                            </div>
                        </div>
<script>

    $('#Date_FROM').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });
    $('#Date_TO').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

    <?php 
        if (isset($_GET['Date_FROM']))
        {
    ?>
    $('#Date_FROM').val('<?php echo $_GET['Date_FROM']; ?>');
    <?php 
    }
    ?>
     <?php 
        if (isset($_GET['Date_TO']))
        {
    ?>
    $('#Date_TO').val('<?php echo $_GET['Date_TO']; ?>');
    <?php 
    }
    ?>
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\test.mt\api\resources\views/admin/recharge_log.blade.php ENDPATH**/ ?>