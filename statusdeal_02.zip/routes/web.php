<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\CustomerPurchaseController;
use App\Http\Controllers\CustomerGiftController;
use App\Http\Controllers\AjaxController;
use App\Http\Controllers\ImagesController;
use App\Http\Controllers\TestController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/*
Route::get('/', function () {
    return view('index');
});
*/
Route::get('/phpinfo', function()
{
    phpinfo();
});
Route::get('/paystack', function () {
    return view('admin.paystack');
});


Route::get('/', [AdminController::class,'home']);
Route::get('/test', [AdminController::class,'test']);
Route::get('/success', [AdminController::class,'success']);
Route::get('/cancel', [AdminController::class,'cancel']);


Route::get('/clear', function () {
       /*
    Artisan::call('route:clear');
    Artisan::call('cache:clear');*/
    Artisan::call('config:cache');
    Artisan::call('config:clear');
    /*Artisan::call('storage:link', [] );
    Artisan::call('storage:link');*/
});
Route::get('no-access', function () {
    return view('admin.no-access');
});

Route::get('sign_up', function () {
    return view('admin.sign_up');
});

Route::get('sign_up_success', function () {
    return view('admin.sign_up_success');
});

Route::get('customer/forget_password', function () {
    return view('admin.forget_password');
});


Route::get('addPurchaseAmount_success', function () {
    return view('admin.addPurchaseAmount_success');
});

Route::group(['middleware'=>'admin_auth'],function()
    {
        Route::get('admin/dashboard', [AdminController::class,'dashboard']);
        
        Route::get('admin/changePassword/{id}', [AdminController::class,'reset']);
        Route::post('admin/changePassword/Set', [AdminController::class,'manage_password_reset'])->name('admin.manage_password_reset');
        
        Route::get('admin/password_change_success/{id}', [AdminController::class,'password_change_success']);
        
        Route::get('admin/targetValue', [AdminController::class,'targetValue']);
        Route::post('admin/targetValue/targetSet', [AdminController::class,'targetSet'])->name('admin.targetSet');

        Route::get('admin/defaultCreditLimit', [AdminController::class,'defaultCreditLimit']);
        Route::post('admin/defaultCreditLimit/credit_limit_set', [AdminController::class,'credit_limit_set'])->name('admin.credit_limit_set');

        Route::get('admin/CustomerPurchase/pending', [CustomerPurchaseController::class,'pending_list']);
        Route::get('admin/CustomerPurchase/approved', [CustomerPurchaseController::class,'approved_list']);
         Route::get('admin/CustomerPurchase/summarize', [CustomerPurchaseController::class,'summarize']);
       
        Route::get('admin/CustomerPurchase/delete/{id}', [CustomerPurchaseController::class,'delete']);
        Route::get('admin/CustomerPurchase/trash', [CustomerPurchaseController::class,'trash']);
        Route::get('admin/CustomerPurchase/forceDelete/{id}', [CustomerPurchaseController::class,'forceDelete']);
        Route::get('admin/CustomerPurchase/restore/{id}', [CustomerPurchaseController::class,'restore']);
        Route::get('admin/CustomerPurchase/viewList/{custId}', [CustomerPurchaseController::class,'viewList']);

        Route::get('admin/CustomerPurchase/status/{status}/{id}', [CustomerPurchaseController::class,'status']);
        Route::post('admin/CustomerPurchase/manage_CustomerPurchase_process', [CustomerPurchaseController::class,'manage_CustomerPurchase_process'])->name('admin_CustomerPurchase_process');

        Route::get('admin/Customer/giftAchiever',[CustomerGiftController::class,'giftAchieve']);
        Route::get('admin/Customer/giftHistory',[CustomerGiftController::class,'giftHistory']);
        Route::get('admin/images/list/{img_type}',[ImagesController::class,'list']);
        Route::get('admin/images/edit_images/{img_type}', [ImagesController::class,'edit_image']);
        Route::get('admin/images/edit_images/{img_type}/{id}', [ImagesController::class,'edit_image']);
        Route::post('admin/images/manage_image_process', [ImagesController::class,'manage_image_process'])->name('image_save');
        Route::get('admin/images/delete/{img_type}/{id}', [ImagesController::class,'delete']);
        Route::get('admin/images/trash/{img_type}', [ImagesController::class,'trash']);
        Route::get('admin/images/forceDelete/{img_type}/{id}', [ImagesController::class,'forceDelete']);
        Route::get('admin/images/restore/{img_type}/{id}', [ImagesController::class,'restore']);


        Route::get('admin/Customer/sendGift/{custId}/{month}/{year}/{basedAmount}',[CustomerGiftController::class,'sendGift']);

        Route::get('admin/Customer/birthDayList',[CustomerController::class,'birthDayList']);
        Route::get('admin/Customer/List',[CustomerController::class,'List']);
        Route::get('admin/Customer/Transactions/{id}',[CustomerController::class,'Transactions']); 
        Route::get('admin/Customer/AllTransactions/',[CustomerController::class,'AllTransactions']);
        Route::get('admin/Customer/InActiveList',[CustomerController::class,'InActiveList']);
        Route::get('admin/Customer/viewNegtiveBalanceWarningList',[CustomerController::class,'viewNegtiveBalanceWarningList']);
        Route::post('admin/Customer/sendNegtiveBalanceWarning',[CustomerController::class,'sendNegtiveBalanceWarning'])->name('admin.sendNegtiveBalanceWarning');
        Route::get('admin/Customer/Wallet',[CustomerController::class,'Wallet']);
        Route::get('admin/Customer/inActiveList',[CustomerController::class,'inActiveList']);
        Route::get('admin/Customer/disApproveList',[CustomerController::class,'disApproveList']);
 
        Route::post('admin/getViewDetails',[AjaxController::class,'getViewDetails'])->name('admin.getViewDetails');
        Route::post('admin/setDefaultPassword',[AjaxController::class,'setDefaultPassword'])->name('admin.setDefaultPassword');
        Route::post('customer/getWalletBalance',[AjaxController::class,'getWalletBalance'])->name('admin.getWalletBalance');
        Route::post('customer/showTransactions',[AjaxController::class,'showTransactions'])->name('admin.showTransactions');
        Route::post('customer/addWalletBalance',[AjaxController::class,'addWalletBalance'])->name('admin.addWalletBalance');
        Route::post('customer/editWalletBalance',[AjaxController::class,'editWalletBalance'])->name('admin.editWalletBalance');
        Route::post('customer/withdrawWalletBalance',[AjaxController::class,'withdrawWalletBalance'])->name('admin.withdrawBalance');
        
        Route::get('admin/Customer/edit_customer/{custId}',[CustomerController::class,'edit_customer']);
        Route::post('admin/Customer/manage_customer_process', [CustomerController::class,'manage_customer_process'])->name('admin.customer_process');
////////////////////////////////////

        Route::get('admin/logout', function () {
            session()->forget('ADMIN_LOGIN');
            session()->forget('ADMIN_ID');
            session()->forget('ADMIN_TYPE');
            session()->forget('ADMIN_NAME');
            session()->forget('ADMIN_IMAGE');
            session()->forget('ADMIN_REFER_ID');
                        
            session()->flash('error','logout successfully');
            return redirect('admin');
    });

    }
);


Route::group(['middleware'=>'cust_auth'],function()
    {
    
        Route::get('customer/addPurchaseAmount/{custId}', [CustomerController::class,'addPurchaseAmount']);
        //Route::post('admin/whitelistIP/manage_whitelistIP_process', [WhitelistIPController::class,'manage_whitelistIP_process'])->name('manage_whitelistIP_process');
        Route::get('customer/profile/{custId}',[CustomerController::class,'edit_profile']);
        Route::get('customer/password_change/{custId}',[CustomerController::class,'password_change']);
        
        Route::post('customer/addPurchaseAmount/PurchaseAmount_process', [CustomerController::class,'PurchaseAmount_process'])->name('customer.PurchaseAmount_process');
        Route::post('customer/save_customer_profile', [CustomerController::class,'save_customer_profile'])->name('customer.save_profile');
        
        Route::post('customer/customer_password_change', [AdminController::class,'customer_password_change'])->name('customer.customer_password_change');

        Route::get('customer/giftAchieve/{custId}', [CustomerGiftController::class,'custGiftAchieve']);
        Route::get('customer/dashboard', [CustomerController::class,'dashboard']);
        Route::post('customer/getViewDetails',[AjaxController::class,'getViewDetails'])->name('admin.getViewDetails');
        Route::get('customer/Transactions/{id}', [CustomerController::class,'Transactions']);
        
        Route::get('customer/logout', function () {
            session()->forget('ADMIN_LOGIN');
            session()->forget('ADMIN_ID');
            session()->forget('ADMIN_TYPE');
            session()->forget('ADMIN_NAME');
            session()->forget('ADMIN_IMAGE');
            session()->forget('ADMIN_REFER_ID');
                        
            session()->flash('error','logout successfully');
            return redirect('customer');
    });

    }
);


Route::get('admin', [AdminController::class,'index']);
Route::post('admin/auth', [AdminController::class,'admin_auth'])->name('admin.auth');

Route::get('customer', [AdminController::class,'cust_index']);
Route::post('customer/auth', [AdminController::class,'cust_auth'])->name('cust.auth');
Route::post('customer/signUp', [AdminController::class,'signUp'])->name('cust.signUp');
Route::post('customer/forgetPassword', [AdminController::class,'forgetPassword'])->name('cust.forget.password');
Route::get('customer/forget_password_success/{id}',[AdminController::class,'forget_password_success']);

Route::get('customer/ResetPassword/{id}', [AdminController::class,'customer_password_reset']);
Route::post('customer/ResetPassword/Set', [AdminController::class,'manage_customer_password_reset'])->name('customer.customer_password_set');
        
Route::get('customer/password_change_success/{id}', [AdminController::class,'customer_password_change_success']);
