@extends('admin/layout');
@section('page_title','admin Login')
@section('login_select','active')
@section('container')
<script type="text/javascript">
  function SignUp_click()
  {
    window.location='/sign_up';
  }
  
 </script>
<section class="get_in_touch">
        <h1 class="title">{{Config::get('constants.SITE_NAME')}} ADMIN Password changed Successfully</h1>
        
        <div class="container">
           @if (session('error'))
<div class="alert alert-danger">{{ session('error') }}</div>
@endif
            <div class="contact-form row">
              <div class="form-field col-lg-4">
                  <label for="user" class="label">User </label>
              </div>
              <div class="form-field col-lg-4">
                  <label for="user" class="label">{{$name}} </label>
              </div>
              <input type="hidden" name="id" value="{{$id}}">
            </div>
        </div>
     
    </section>
@endsection