@extends('admin/layout');
@section('page_title','Password Rest link sent successfully')
@section('dashboard_select','active')
@section('container')
<script type="text/javascript">
   function home_click()
  {
    window.location='/';
  }
 </script>
 
<section class="get_in_touch">
        <h1 class="title">Password reset link</h1>
        <div class="card text-center">
  <div class="card-header">
    
  </div>
  <div class="card-body">
    <h5 class="card-title">Submitted Successfully</h5>
    <p class="card-text">An email is sent to your resgisterd email {{$email}}, open the link sent to your email and change your password</p>
 
    <a href="javascript:void(0)" onclick="home_click()" class="btn btn-primary" class="card-link">Go Home</a>
  </div>
  <div class="card-footer text-muted">
    status deal
  </div>
</div>

    </section>
@endsection