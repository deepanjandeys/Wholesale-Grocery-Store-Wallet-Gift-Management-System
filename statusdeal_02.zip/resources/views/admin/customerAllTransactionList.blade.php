@extends('admin/layout');
@section('page_title','Customer Transaction List')
@section('Report_select','active')
@section('container')
{{$AJAX_ROOT=Config::get('constants.AJAX_ROOT')}}
<section class="get_in_touch">
        <h1 class="title">All Transaction List </h1>
        
        <div class="container">
          <div class="container">
          <form id="myForm">
        <div class="contact-form row">

          <div class="form-field col-lg-2">
                  <label for="month" class="label">Month</label>
              </div>
              <div class="form-field col-lg-4">
                  
                  <select name="month" id="month" onchange="selMonth_Change()" class="input-text font-weight-bold" >
                       
                        @foreach($months as $list)
                            @if($month==$list->id)
                    <option selected value="{{$list->id}}" >{{$list->name}}</option>
                            @else
                    <option value="{{$list->id}}">{{$list->name}}</option>
                            @endif
                        @endforeach
                    </select>
              </div>
              <div class="form-field col-lg-1">
                  <label for="year" class="label">Year</label>
              </div>
              <div class="form-field col-lg-4">
                  
                  <select name="year" id="year" onchange="selMonth_Change()" class="input-text font-weight-bold" >
                        <option value=""></option>
                        @foreach($years as $list)
                            @if($year==$list->value)
                    <option selected >{{$list->value}}</option>
                            @else
                    <option >{{$list->value}}</option>
                            @endif
                        @endforeach
                    </select>

              </div>
              <div class="form-field col-lg-1">
                <input type="submit" name="search-btn" class="btn btn-primary" value="search">
              </div>
            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Date From</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="Date_From" id="Date_From" placeholder="Date From" class="input-text" value="{{$Date_From}}">
              </div>
              <div class="form-field col-lg-1">
                  <label for="year" class="label">To</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="Date_To" id="Date_To" placeholder="Date To" class="input-text" value="{{$Date_To}}">

              </div>

            </div>
            </form>
          </div>

    </section>
    <div class="container">
            <div class="contact-form row">
              <div class="col-lg-12 overflow-scroll">
                
                <table class="table table-responsive">
                  <tr>   
                   <th>Date</th>
                   <th>Name</th>
                   <th>Tran type</th>
                   <th>amount</th>
                   <th>Balance</th>
                   <th>Remarks</th>
                  </tr>
                  @if($customer_Wallet->count()>0)
                  <?php 
                  $today=strtotime(date('d-m-Y'));
                  ?>
                  <tbody>
                                            @foreach($customer_Wallet as $list)
 <?php 
            $created_at   =date('d-m-Y h:i:s A', strtotime($list->created_at));
            $amount         = number_format($list->amount,2);
            $balance         = number_format($list->curBalance,2);
            $tranType=$list->tranType;
            $tranTypes='';
            if($tranType=='0')
            {
                $tranTypes="Opening";
            }
            else if($tranType=='1')
            {
                $tranTypes='Debit';
            }
            else if($tranType=='2')
            {
                $tranTypes="Credit";
            }
            
            $remarks = $list['remarks'];
            $name=$list->getCustomers->name;
  ?>                                           <tr>
                                           
                                                <td>{{$created_at}}</td>
                                                <td>{{$name}}</td>
                                                <td>{{$tranTypes}}</td>
                                                <td>{{$amount}}</td>
                                                <td>{{$balance}}</td>
                                                <td>{{$remarks}}</td>
                                                
                                                </tr>
                                              @endforeach
                      </tbody>
                      @else
                      <tbody>
                        <tr>
                          <td colspan="10">Nothing to show</td>
                        </tr>
                      </tbody>
                      @endif
                </table>
                
              </div>
            </div>
            
            
        </div>
<script type="text/javascript">
function selMonth_Change()
{
  var m=$('#month').val();
  var y=$('#year').val();
  //var firstDay = new Date(y, m, 1);
  
  if (m<10) 
  {
    m = '0'+m;
  }

  var firstDay = '01-'+m+'-'+y;
  var lastDay = new Date(y, m , 0); //new Date(y, m + 1, 0);
  lastDay = lastDay.getDate()+'-'+m+'-'+y;

  $('#Date_From').val(firstDay);
  $('#Date_To').val(lastDay);

//console.log(firstDay+' '+lastDay);
}
    $('#Date_From').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

    $('#Date_To').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

  function setDefaultPassword(id) {
    if (confirm("do You want to reset password to default password !") == false) 
    {
  return;
    } 
   $.ajax({
    type: "POST",
    url: '{{$AJAX_ROOT}}/admin/setDefaultPassword',
    data: { id: id, _token: '{{csrf_token()}}' },
    success: function (data) 
    {
        //console.log(' ** '+ data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
            $('#divPwd'+id).html(obj.msg);
           
            }
        else
        {
            $('#divPwd'+id).html('');
           
        }
    
    },
    error: function (data, textStatus, errorThrown) {
        console.log(data+' '+textStatus+' '+errorThrown);
 
    },
});
}
</script>
@endsection