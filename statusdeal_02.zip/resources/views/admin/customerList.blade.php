@extends('admin/layout');
@section('page_title','Customer List')
@section('Report_select','active')
@section('container')
{{$AJAX_ROOT=Config::get('constants.AJAX_ROOT')}}
<section class="get_in_touch">
        <h1 class="title">{{Config::get('constants.SITE_NAME')}} Customer List</h1>
        
        <div class="container">
          <div class="container">
          <form id="myForm">
        <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="id" class="label">ID</label>
              </div>
              <div class="form-field col-lg-4">
                <input type="search" name="id" placeholder="customer id" class="input-text" value="{{$id}}">
              </div>
              <div class="form-field col-lg-1">
                  <label for="name" class="label">Name</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="search" name="name" placeholder="customer name" class="input-text" value="{{$name}}">
              </div>

            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Mobile</label>
              </div>
              <div class="form-field col-lg-4">
              <input type="search" name="mobile" placeholder="customer mobile" class="input-text" value="{{$mobile}}">
              </div>
              <div class="form-field col-lg-1">
                  <label for="bal_opr" class="label">Address</label>
              </div>
              <div class="form-field col-lg-3">
              <input type="search" name="address" placeholder="Address" class="input-text" value="{{$address}}">
              </div>
              <div class="form-field col-lg-1">
                <input type="submit" name="search-btn" class="btn btn-primary" value="search">
              </div>
            </div>
       
            </form>
          </div>

    </section>
    <div class="container">
            <div class="contact-form row">
              <div class="col-lg-12 overflow-scroll">
                go to <a href="{{url('admin/Customer/inActiveList')}}">In Active Customer List</a> &nbsp; go to <a href="{{url('admin/Customer/disApproveList')}}">Disapproved Customer list</a>
                <table class="table table-responsive table-dark table-light">
                  <tr> 
                     
                    <th>
                      Cust id
                    </th>
                    <th>
                      Customer Name
                    </th>
                    <th>
                      Mobile No.
                    </th>
                    <th>
                      email
                    </th>
                    <th>
                      Address
                    </th>
                    <th>
                      Date of Birth
                    </th>
                    <th>
                      Credit Limit
                    </th>
                    <th>Action 1</th>
                    <th>Action 2</th>
                  </tr>
                  @if($customers->count()>0)
                  <?php 
                  $today=strtotime(date('d-m-Y'));
                  ?>
                  <tbody>
                                            @foreach($customers as $list)
                                            <tr>
                                           
                                                <td>{{$list->id}}</td>
                                                <td>{{$list->name}}</td>
                                                <td>{{$list->mobile}}</td>
                                                <td>{{$list->email}}</td>
                                                <td>{{$list->address}}</td>
                                                <td>{{$list->DateOfBirth}}</td>
                                                <td>{{$list->credit_limit}}</td>
                                                <td>
                                                  <a href="javascript:void(0)" 
                                                  onclick="setDefaultPassword({{$list->id}})">Reset Password</a>
                                                  <div id="divPwd{{$list->id}}"></div>
                                                </td>
                                                <td>
                                                   <a href="{{url('admin/Customer/edit_customer/')}}/{{$list->id}}">
                                                    <button type="button" class="btn btn-warning">Edit</button>
                                                    </a>
                                                  </div>
                                                </td>
                                                </tr>
                                              @endforeach
                      </tbody>
                      @else
                      <tbody>
                        <tr>
                          <td colspan="10">Nothing to show</td>
                        </tr>
                      </tbody>
                      @endif
                </table>
                
              </div>
            </div>
            
            
        </div>
<script type="text/javascript">
  function setDefaultPassword(id) {
    if (confirm("do You want to reset password to default password !") == false) 
    {
  return;
    } 
   $.ajax({
    type: "POST",
    url: '{{$AJAX_ROOT}}/admin/setDefaultPassword',
    data: { id: id, _token: '{{csrf_token()}}' },
    success: function (data) 
    {
        //console.log(' ** '+ data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
            $('#divPwd'+id).html(obj.msg);
           
            }
        else
        {
            $('#divPwd'+id).html('');
           
        }
    
    },
    error: function (data, textStatus, errorThrown) {
        console.log(data+' '+textStatus+' '+errorThrown);
 
    },
});
}
</script>
@endsection