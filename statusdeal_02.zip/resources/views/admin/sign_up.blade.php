@extends('admin/layout');
@section('page_title','Dashboard')
@section('dashboard_select','active')
@section('container')

<section class="get_in_touch">
        <h1 class="title">{{Config::get('constants.SITE_NAME')}} Sign Up</h1>
        <form action="{{route('cust.signUp')}}" method="post">
            @csrf
        <div class="container">
          @if (session('error'))
<div class="alert alert-danger">{{ session('error') }}</div>
@endif
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="name" class="label">Name </label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="name" id="name" class="input-text" value="{{old('name')}}">
                  
              </div>

              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Mobile No.</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="number" name="mobile" id="mobile" class="input-text" value="{{old('mobile')}}">
                   
              </div>
            </div>
            <div class="row">
              <div class="col-lg-6">
              @error('name')
                   <div class="alert alert-danger" role="alert">
                    {{$message}}
                    </div>
                    @enderror
              </div>
              <div class="col-lg-6">
              @error('mobile')
                   <div class="alert alert-danger" role="alert">
                    {{$message}}
                    </div>
                    @enderror

              </div>
            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="DateOfBirth" class="label">Date Of Birth</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="DateOfBirth" id="DateOfBirth" class="input-text" value="{{old('DateOfBirth')}}">
                   
              </div>

              <div class="form-field col-lg-2">
                  <label for="password" class="label">password</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="password" name="password" id="password" class="input-text" value="{{old('password')}}">
                   
              </div>
            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="email" class="label">email</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="email" id="email" class="input-text" value="{{old('email')}}">
                   
              </div>

              <div class="form-field col-lg-2">
                  <label for="gender" class="label">gender</label>
              </div>
              <div class="form-field col-lg-4">
                <select name="gender" class="input-text">
                  <option value="0"></option>
                  <option value="1">Male</option>
                  <option value="2">Female</option>
                  <option value="3">Other</option>
                </select>
                   
              </div>
            </div>
            <div class="row">
              <div class="col-lg-6">@error('DateOfBirth')
                   <div class="alert alert-danger" role="alert">
                    {{$message}}
                    </div>
                    @enderror
                  </div>
              <div class="col-lg-6">
              @error('password')
                   <div class="alert alert-danger" role="alert">
                    {{$message}}
                    </div>
                    @enderror
                </div>
            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                <label for="address" class="label">address</label>
              </div>
              <div class="form-field col-lg-10">
                <textarea id="address" name="address" class="input-text">{{old('address')}}</textarea>
                 
              </div>
            </div>
            <div class="row">
              <div class="col-lg-12">
                @error('address')
                   <div class="alert alert-danger" role="alert">
                    {{$message}}
                    </div>
                    @enderror
              </div>
            </div>
            <div class="contact-form row">
              
               <div class="form-field col-lg-6">
                Are you existing Customer, <a href="/customer">Login</a> here
               </div>
               <div class="form-field col-lg-6">
                <input type="hidden" name="id" value="0">
                <input class="submit-btn" type="submit" value="Submit" name="Submit">
               </div>
            </div>
        </div>
      </form>
    </section>
<script>

    $('#DateOfBirth').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

    $('#DateOfBirth').val('');
  </script>
@endsection