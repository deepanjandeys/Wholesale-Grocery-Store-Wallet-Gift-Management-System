@extends('admin/layout');
@section('page_title','Pending list')
@section('Purchase_select','active')
@section('container')

<section class="get_in_touch">
        <h1 class="title">{{Config::get('constants.SITE_NAME')}} List for Approval </h1>
        
        <div class="container">
          <form>
         <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Month</label>
              </div>
              <div class="form-field col-lg-4">
                  
                  <select name="month" id="month" onchange="selMonth_Change()" class="input-text font-weight-bold" >
                        <option value=""></option>
                        @foreach($months as $list)
                            @if($month==$list->id)
                    <option selected value="{{$list->id}}" >{{$list->name}}</option>
                            @else
                    <option value="{{$list->id}}">{{$list->name}}</option>
                            @endif
                        @endforeach
                    </select>
              </div>
              <div class="form-field col-lg-1">
                  <label for="year" class="label">Year</label>
              </div>
              <div class="form-field col-lg-4">
                  
                  <select name="year" id="year" onchange="selMonth_Change()" class="input-text font-weight-bold" >
                        <option value=""></option>
                        @foreach($years as $list)
                            @if($year==$list->value)
                    <option selected >{{$list->value}}</option>
                            @else
                    <option >{{$list->value}}</option>
                            @endif
                        @endforeach
                    </select>

              </div>

            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Search</label>
              </div>
              <div class="form-field col-lg-9">
              <input type="search" name="search" placeholder="customer name/mobile/address" class="input-text" value="{{$search}}">
              </div>
              <div class="form-field col-lg-1">
                <input type="submit" name="search-btn" class="btn btn-primary" value="search">
              </div>
            </div>

            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Date From</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="Date_From" id="Date_From" placeholder="Date From" class="input-text" value="{{$Date_From}}">
              </div>
              <div class="form-field col-lg-1">
                  <label for="year" class="label">To</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="Date_To" id="Date_To" placeholder="Date To" class="input-text" value="{{$Date_To}}">

              </div>

            </div>
            </form>
          </div>
    </section>
    <div class="container">
            <div class="contact-form row">
              <div class="col-lg-12 overflow-scroll">
                <table class="table table-responsive table-dark table-light">
                  <tr> 
                    
                    <th>
                      id
                    </th>
                    <th>
                      Date
                    </th>
                    <th>
                      Cust id
                    </th>
                    <th>
                      Customer Name
                    </th>
                    <th>
                      Mobile No.
                    </th>
                    <th>
                      Address
                    </th>
                    <th>
                      Amount
                    </th>
                    <th colspan="2" class="text-center">action</th>
                    
                    <th>
                      remarks
                    </th>
                  </tr>
                  @if($customerPurchase->count()>0)
                  <?php $sum=0;?>
                  <tbody>
                                            @foreach($customerPurchase as $list)
                                            <tr>
                                           
                                                <td>{{$list->id}}</td>
                                                <td>{{$list->purchaseDate}}</td>
                                                <td>{{$list->custId}}</td>
                                                <td>{{$list->getCustomers->name}}</td>
                                                <td>{{$list->getCustomers->mobile}}</td>
                                                <td>{{$list->getCustomers->address}}</td>
                                                <td style="text-align: right;">{{number_format($list->amount,2)}}
                                                <?php $sum += $list->amount;?></td>
                                                 <td>
                                                    @if($list->status==0)
                                                    
                                                    <a href="{{url('admin/CustomerPurchase/status/1/')}}/{{$list->id}}">
                                                    <button type="button" class="btn btn-success">Approve</button>
                                                    </a>
                                                    @endif
                                                    
                                                </td>
                                                 <td>               
                                          <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#exampleModal" onclick="setPurchaseID({{$list->id}})"> Decline</button>
                                                
                                                </td>
                                                
                                                
                                                <td>time: {{$list->created_at}} {{$list->remarks}}</td>
                                              </tr>
                                              @endforeach
                                              <tr><td colspan="6" style="text-align: right;">Total </td>
                                                <td style="text-align: right;">{{number_format($sum,2)}}</td>
                                                <td colspan="3"></td>
                                              </tr>
                      </tbody>
                      @else
                      <tbody>
                        <tr>
                          <td colspan="11">Nothing to show</td>
                        </tr>
                      </tbody>
                      @endif
                </table>
              </div>
              {{
                  $customerPurchase->links();
              }}
            </div>
            
            
        </div>
        

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Confirmation to decline</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Purchase entry with id <span id="spnPurId"></span> will be decline
      </div>
      <div class="modal-footer">
        <input type="hidden" id="curPurchaseId" >
        <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
        <button type="button" class="btn btn-primary" onclick="delete_Purchase_Entry()">Yes</button>
      </div>
    </div>
  </div>
</div>


<script language="javascript">
function selMonth_Change()
{
  var m=$('#month').val();
  var y=$('#year').val();
  //var firstDay = new Date(y, m, 1);
  
  if (m<10) 
  {
    m = '0'+m;
  }

  var firstDay = '01-'+m+'-'+y;
  var lastDay = new Date(y, m , 0); //new Date(y, m + 1, 0);
  lastDay = lastDay.getDate()+'-'+m+'-'+y;

  $('#Date_From').val(firstDay);
  $('#Date_To').val(lastDay);

//console.log(firstDay+' '+lastDay);
}
    $('#Date_From').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

    $('#Date_To').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

  function setPurchaseID(id)
  {
    $('#curPurchaseId').val(id);
    $('#spnPurId').html(id);
  }

  function delete_Purchase_Entry()
  {
    var curPurchaseId=$('#curPurchaseId').val();
    window.location="{{url('admin/CustomerPurchase/delete/')}}/"+curPurchaseId;
  }
  </script>
@endsection