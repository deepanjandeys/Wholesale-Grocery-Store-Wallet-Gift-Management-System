@extends('admin/layout');
@section('page_title','Birth Day List')
@section('Report_select','active')
@section('container')

<section class="get_in_touch">
        <h1 class="title">{{Config::get('constants.SITE_NAME')}} Birth Day List</h1>
        
        <div class="container">
          <form id="myForm">
         <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Month</label>
              </div>
              <div class="form-field col-lg-4">
                  
                  <select name="month" id="month" class="input-text font-weight-bold" >
                        <option value=""></option>
                        @foreach($months as $list)
                            @if($month==$list->id)
                    <option selected value="{{$list->id}}" >{{$list->name}}</option>
                            @else
                    <option value="{{$list->id}}">{{$list->name}}</option>
                            @endif
                        @endforeach
                    </select>
              </div>
              <div class="form-field col-lg-1">
                  <label for="year" class="label">Year</label>
              </div>
              <div class="form-field col-lg-4">
                  
                  <select name="year" id="year" class="input-text font-weight-bold" >
                        <option value=""></option>
                        @foreach($years as $list)
                            @if($year==$list->value)
                    <option selected >{{$list->value}}</option>
                            @else
                    <option >{{$list->value}}</option>
                            @endif
                        @endforeach
                    </select>

              </div>

            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Search</label>
              </div>
              <div class="form-field col-lg-9">
              <input type="search" name="search" placeholder="customer name/mobile/address" class="input-text" value="{{$search}}">
              </div>
              <div class="form-field col-lg-1">
                <input type="submit" name="search-btn" class="btn btn-primary" value="search">
              </div>
            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Filter By</label>
              </div>
              <div class="form-field col-lg-2">
                <?php 
                $a=''; $b='';
                if($rdbFilterBy=='m')
                {
                  $a='checked';
                }
                else if($rdbFilterBy=='d')
                {
                  $b='checked';
                }
                else 
                {
                  $a='checked'; // default is month
                }
                ?>
              <input type="radio" class="btn-check" name="rdbFilterBy" id="rdbMonth" autocomplete="off" value="m" {{$a}} >
              <label class="btn btn-outline-success" for="success-outlined" onclick="rdbMonth_click()">Month</label>
              </div>
              <div class="form-field col-lg-2">           
              <input type="radio" class="btn-check" name="rdbFilterBy" id="rdbToday" autocomplete="off" value="d" {{$b}} >
              <label class="btn btn-outline-success" for="success-outlined" onclick="rdbToday_click()" >To Day</label>
              </div>
             
            </div>
            </form>
          </div>
    </section>
    <div class="container">
            <div class="contact-form row">
              <div class="col-lg-12 overflow-scroll">
                <table class="table table-responsive table-dark table-light">
                  <tr> 
                     
                    <th>
                      Cust id
                    </th>
                    <th>
                      Customer Name
                    </th>
                    <th>
                      Mobile No.
                    </th>
                    <th>
                      Address
                    </th>
                    <th>
                      Date of Birth
                    </th>
                    <th>Birth Day</th>
                    <th>Status </th>
                    <th>Action</th>
                  </tr>
                  @if($birthDayList->count()>0)
                  <?php 
                  $today=strtotime(date('d-m-Y'));
                  ?>
                  <tbody>
                                            @foreach($birthDayList as $list)
                                            <tr>
                                           
                                                <td>{{$list->id}}</td>
                                                <td>{{$list->name}}</td>
                                                <td>{{$list->mobile}}</td>
                                                <td>{{$list->address}}</td>
                                                <td>{{$list->DateOfBirth}}</td>
                                                <td>{{$list->BirthDay}}</td>
                                                <td><?php 
                                                if(strtotime($list->BirthDay)<$today) 
                                                  {
                                                    echo "<span class='btn btn-warning'>past date</span>";
                                                  }
                                                  else if(strtotime($list->BirthDay)==$today) 
                                                  {
                                                    echo "<span class='btn btn-primary'>Today</span>";
                                                  }
                                                  else 
                                                  {
                                                      echo "<span class='btn btn-success'>up comming</span>";
                                                  }
                                                  
                                                ?></td>
                                                <td><input type="checkbox" id="chk{{$list->id}}"></td>
                                              </tr>
                                              @endforeach
                      </tbody>
                      @else
                      <tbody>
                        <tr>
                          <td colspan="10">Nothing to show</td>
                        </tr>
                      </tbody>
                      @endif
                </table>
                <input type="button" style="text-align:right;" class="btn btn-primary" value="Send message">
              </div>
            </div>
            
            
        </div>
<script>

    $('#DateOfBirth').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

    function rdbMonth_click()
    {
      $('#rdbMonth').prop('checked', true);
      document.getElementById("myForm").submit();
    }

    function rdbToday_click()
    {
      $('#rdbToday').prop('checked', true);
      document.getElementById("myForm").submit();
    }
  </script>
@endsection