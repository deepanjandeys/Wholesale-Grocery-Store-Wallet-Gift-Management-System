@extends('admin/layout');
@section('page_title','admin Login')
@section('login_select','active')
@section('container')
<script type="text/javascript">
  function SignUp_click()
  {
    window.location='/sign_up';
  }
  
 </script>
<section class="get_in_touch">
        <h1 class="title">{{Config::get('constants.SITE_NAME')}} ADMIN Login</h1>
        <form action="{{route('admin.auth')}}" method="post">
            @csrf
        <div class="container">
           @if (session('error'))
<div class="alert alert-danger">{{ session('error') }}</div>
@endif
            <div class="contact-form row">
              <div class="form-field col-lg-4">
                  <label for="user" class="label">User </label>
              </div>
              <div class="form-field col-lg-8">
                  <input type="text" name="user" id="user" class="input-text" value="{{old('user')}}" >
              </div>
            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-4">
                  <label for="password" class="label">password</label>
              </div>
              <div class="form-field col-lg-8">
                <input type="password" name="password" id="password" class="input-text" value="{{old('password')}}">
              </div>
            </div>
            <div class="contact-form row">
              
               <div class="form-field col-lg-6">
                
               </div>
               <div class="form-field col-lg-6">
                <input class="submit-btn" type="submit" value="Login" name="SignIn">
               </div>
            </div>
        </div>
      </form>
    </section>
@endsection