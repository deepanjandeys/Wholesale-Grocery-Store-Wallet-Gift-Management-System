@extends('admin/layout');
@section('page_title','Dashboard')
@section('dashboard_select','active')
@section('container')
<script type="text/javascript">
  function dashboard()
  {
    window.location='/customer/dashboard';
  }
  function home_click()
  {
    window.location='/';
  }
 </script>
<section class="get_in_touch">
      <h1 class="title">{{Config::get('constants.SITE_NAME')}} add Purchase Amount</h1>
        <form action="{{route('customer.PurchaseAmount_process')}}" method="post">
            @csrf
        <div class="container">
          @if (session('error'))
<div class="alert alert-danger">{{ session('error') }}</div>
@endif
            <div class="contact-form row ">
              <div class="form-field col-lg-12 myClass" style="color:white;font-weight: bold;">
                  <label for="name" class="label">Name {{$name}} </label> 
                  <label for="mobile" class="label">Mobile No. {{$mobile}}</label>
              </div>
              
            </div>
            
            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="DateOfBirth" class="label">Purchase Date</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="purchaseDate" id="purchaseDate" class="input-text" value="{{old('purchaseDate')}}">
                   
              </div>

              <div class="form-field col-lg-2">
                  <label for="amount" class="label">Amount</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="amount" id="amount" class="input-text" value="{{old('amount')}}">
                   
              </div>
            </div>
            <div class="row">
              <div class="col-lg-6">@error('purchaseDate')
                   <div class="alert alert-danger" role="alert">
                    {{$message}}
                    </div>
                    @enderror
                  </div>
              <div class="col-lg-6">
              @error('amount')
                   <div class="alert alert-danger" role="alert">
                    {{$message}}
                    </div>
                    @enderror
                </div>
            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                <label for="remarks" class="label">Remarks</label>
              </div>
              <div class="form-field col-lg-10">
                <textarea id="remarks" name="remarks" class="input-text" placeholder="optional">{{old('remarks')}}</textarea>
                 
              </div>
            </div>
            <div class="row">
              <div class="col-lg-12">
                @error('remarks')
                   <div class="alert alert-danger" role="alert">
                    {{$message}}
                    </div>
                    @enderror
              </div>
            </div>
            <div class="contact-form row">
              
               <div class="form-field col-lg-6">
              click here to go <a href="javascript:void(0)" onclick="dashboard()">Dashboard</a>
               </div>
               <div class="form-field col-lg-6">
                <input type="hidden" name="custId" value="{{$custId}}">
                <input type="hidden" name="id" value="{{$id}}">
                <input class="submit-btn" type="submit" value="Submit" name="Submit">
               </div>
            </div>
        </div>
      </form>
    </section>
<script>

    $('#purchaseDate').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });
  </script>
@endsection