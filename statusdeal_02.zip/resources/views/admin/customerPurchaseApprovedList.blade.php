@extends('admin/layout');
@section('page_title','Approved List')
@section('Purchase_select','active')
@section('container')

<section class="get_in_touch">
        <h1 class="title">{{Config::get('constants.SITE_NAME')}} Approved List</h1>
        
        <div class="container">
          <form>
         <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Month</label>
              </div>
              <div class="form-field col-lg-4">
                  
                  <select name="month" id="month" onchange="selMonth_Change()" class="input-text font-weight-bold" >
                        <option value=""></option>
                        @foreach($months as $list)
                            @if($month==$list->id)
                    <option selected value="{{$list->id}}" >{{$list->name}}</option>
                            @else
                    <option value="{{$list->id}}">{{$list->name}}</option>
                            @endif
                        @endforeach
                    </select>
              </div>
              <div class="form-field col-lg-1">
                  <label for="year" class="label">Year</label>
              </div>
              <div class="form-field col-lg-4">
                  
                  <select name="year" id="year" onchange="selMonth_Change()" class="input-text font-weight-bold" >
                        <option value=""></option>
                        @foreach($years as $list)
                            @if($year==$list->value)
                    <option selected >{{$list->value}}</option>
                            @else
                    <option >{{$list->value}}</option>
                            @endif
                        @endforeach
                    </select>

              </div>

            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Search</label>
              </div>
              <div class="form-field col-lg-9">
              <input type="search" name="search" placeholder="customer name/mobile/address" class="input-text" value="{{$search}}">
              </div>
              <div class="form-field col-lg-1">
                <input type="submit" name="search-btn" class="btn btn-primary" value="search">
              </div>
            </div>

            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Date From</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="Date_From" id="Date_From" placeholder="Date From" class="input-text" value="{{$Date_From}}">
              </div>
              <div class="form-field col-lg-1">
                  <label for="year" class="label">To</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="Date_To" id="Date_To" placeholder="Date To" class="input-text" value="{{$Date_To}}">

              </div>

            </div>
            </form>
          </div>
    </section>
    <div class="container">
            <div class="contact-form row">
              <div class="col-lg-12 overflow-scroll">
                <table class="table table-responsive table-dark table-light">
                  <tr> 
                     <th>
                      id
                    </th>
                    <th>
                      Date
                    </th>
                    <th>
                      Cust id
                    </th>
                    <th>
                      Customer Name
                    </th>
                    <th>
                      Mobile No.
                    </th>
                    <th>
                      Address
                    </th>
                    <th>
                      Amount
                    </th>
                    <th class="text-center">action</th>
                    
                    <th>
                      remarks
                    </th>
                  </tr>
                  @if($customerPurchase->count()>0)
                  <?php $sum=0;?>
                  <tbody>
                                            @foreach($customerPurchase as $list)
                                            <tr>
                                           
                                                <td>{{$list->id}}</td>
                                                <td>{{$list->purchaseDate}}</td>
                                                <td>{{$list->custId}}</td>
                                                <td>{{$list->getCustomers->name}}</td>
                                                <td>{{$list->getCustomers->mobile}}</td>
                                                <td>{{$list->getCustomers->address}}</td>
                                                <td style="text-align: right;">{{number_format($list->amount,2)}}
                                                  <?php $sum += $list->amount;?></td>
                                                 <td>
                                                    @if($list->status==1)
                                                    
                                                       
                                                    <a href="{{url('admin/CustomerPurchase/status/0/')}}/{{$list->id}}">
                                                    <button type="button" class="btn btn-warning">Disapprove</button>
                                                    </a>
                                                   
                                                    @endif
                                                    
                                                </td>
                                                 
                                                
                                                
                                                
                                                <td>time: {{$list->created_at}} {{$list->remarks}}</td>
                                              </tr>
                                              @endforeach
                                              <tr><td colspan="6" style="text-align: right;">Total </td>
                                                <td style="text-align: right;">{{number_format($sum,2)}}</td>
                                                <td colspan="3"></td>
                                              </tr>
                      </tbody>
                      @else
                      <tbody>
                        <tr>
                          <td colspan="10">Nothing to show</td>
                        </tr>
                      </tbody>
                      @endif
                </table>
              </div>
              {{
                  $customerPurchase->links();
              }}
            </div>
            
            
        </div>
<script>
function selMonth_Change()
{
  var m=$('#month').val();
  var y=$('#year').val();
  //var firstDay = new Date(y, m, 1);
  
  if (m<10) 
  {
    m = '0'+m;
  }

  var firstDay = '01-'+m+'-'+y;
  var lastDay = new Date(y, m , 0); //new Date(y, m + 1, 0);
  lastDay = lastDay.getDate()+'-'+m+'-'+y;

  $('#Date_From').val(firstDay);
  $('#Date_To').val(lastDay);

//console.log(firstDay+' '+lastDay);
}
    $('#Date_From').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

    $('#Date_To').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });
  </script>

@endsection