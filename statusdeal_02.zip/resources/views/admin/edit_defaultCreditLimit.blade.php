@extends('admin/layout');
@section('page_title','Set Default Credit Limit vaue of Customer')
@section('Setting_select','active')
@section('container')

<section class="get_in_touch">
        <h1 class="title">{{Config::get('constants.SITE_NAME')}} set Default Credit Limit vaue of Customer</h1>
        <form action="{{route('admin.credit_limit_set')}}" method="post">
            @csrf
        <div class="container">
           @if (session('error'))
<div class="alert alert-danger">{{ session('error') }}</div>
@endif
            <div class="contact-form row">
              <div class="form-field col-lg-4">
                  <label for="credit_limit" class="label">Default Credit Limit value of Customer</label>
              </div>
              <div class="form-field col-lg-8">
                  <input type="text" name="credit_limit" id="credit_limit" class="input-text" value="{{$credit_limit}}" >
              </div>
            </div>
            
            <div class="contact-form row">
              
               <div class="form-field col-lg-6">
                
               </div>
               <div class="form-field col-lg-6">
                <input class="submit-btn" type="submit" value="Save" name="Save">
               </div>
            </div>
        </div>
      </form>
    </section>
@endsection