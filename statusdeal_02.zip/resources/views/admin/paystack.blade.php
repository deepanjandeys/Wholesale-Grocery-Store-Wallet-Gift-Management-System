@extends('admin/layout');
@section('page_title','Pay Stack')
@section('dashboard_select','active')
@section('container')

<section class="get_in_touch">
        <h1 class="title">Pay stack</h1>
        <div class="container">
 <form id="paymentForm">
  
  <div class="contact-form row">
              <div class="form-field col-lg-4">
                  <label for="email" class="label">email </label>
              </div>
              <div class="form-field col-lg-8">
                  <input type="email" name="email" id="email-address" class="input-text" value="{{old('email')}}" >
              </div>
            </div>
    <div class="contact-form row">
              <div class="form-field col-lg-4">
                  <label for="amount" class="label">amount </label>
              </div>
              <div class="form-field col-lg-8">
                  <input type="tel" name="amount" id="amount" class="input-text" value="{{old('amount')}}" >
              </div>
            </div>

        <div class="contact-form row">
              <div class="form-field col-lg-4">
                  <label for="first-name" class="label">First name</label>
              </div>
              <div class="form-field col-lg-8">
                  <input type="text" name="first-name" id="first-name" class="input-text" value="{{old('first-name')}}" >
              </div>
            </div>

          <div class="contact-form row">
              <div class="form-field col-lg-4">
                  <label for="last-name" class="label">Last name </label>
              </div>
              <div class="form-field col-lg-8">
                  <input type="text" name="last-name" id="last-name" class="input-text" value="{{old('last-name')}}" >
              </div>
            </div>
  
  <div class="form-submit">
    <button type="submit" class="submit-btn" onclick="payWithPaystack()"> Pay </button>
  </div>
</form>
</div>
<script src="https://js.paystack.co/v1/inline.js"></script> 
</section>
<script type="text/javascript">
  debugger;
   const paymentForm = document.getElementById('paymentForm');
paymentForm.addEventListener("submit", payWithPaystack, false);
function payWithPaystack(e) {
  e.preventDefault();

  let handler = PaystackPop.setup({
    key: 'pk_test_xxxxxxxxxx', // Replace with your public key
    email: document.getElementById("email-address").value,
    amount: document.getElementById("amount").value * 100,
    ref: ''+Math.floor((Math.random() * 1000000000) + 1), // generates a pseudo-unique reference. Please replace with a reference you generated. Or remove the line entirely so our API will generate one for you
    // label: "Optional string that replaces customer email"
    onClose: function(){
      alert('Window closed.');
    },
    callback: function(response){
      let message = 'Payment complete! Reference: ' + response.reference;
      alert(message);
    }
  });

  handler.openIframe();
}
  
 </script>
@endsection