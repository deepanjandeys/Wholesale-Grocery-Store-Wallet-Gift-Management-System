<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   
    <!-- Title Page-->
    <title>add Purchase Amount Success</title>

  <link href="{{asset('admin_assets/vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">
  <link href="{{asset('admin_assets/css/style2.css')}}" rel="stylesheet">
 
 <script type="text/javascript">
  function dashnoard()
  {
    window.location='/customer/dashboard';
  }
  function home_click()
  {
    window.location='/';
  }
 </script>
</head>

<body >

<section class="get_in_touch">
        <h1 class="title">You Successfully add Purchase Amount</h1>
        <p>* this purchase amount effect after approved by admin</p>
        <div class="container">
           <div class="contact-form row">
               <div class="form-field col-lg-6">
                <input class="submit-btn" type="button" value="Home" onclick="home_click()" name="Home">
               </div>
               <div class="form-field col-lg-6">
                <input class="submit-btn" type="button" value="dashboard" onclick="dashnoard()" name="dashboard">
               </div>
            </div>
        </div>
    </section>
    <!-- Jquery JS-->
    <script src="{{asset('admin_assets/vendor/jquery-3.2.1.min.js')}}"></script>
    <!-- Bootstrap JS-->
    <script src="{{asset('admin_assets/vendor/bootstrap-4.1/popper.min.js')}}"></script>
    <script src="{{asset('admin_assets/vendor/bootstrap-4.1/bootstrap.min.js')}}"></script>
    <script src="{{asset('admin_assets/vendor/wow/wow.min.js')}}"></script>
    <!-- Main JS-->
    <script src="{{asset('admin_assets/js/main.js')}}"></script>

</body>

</html>
<!-- end document-->