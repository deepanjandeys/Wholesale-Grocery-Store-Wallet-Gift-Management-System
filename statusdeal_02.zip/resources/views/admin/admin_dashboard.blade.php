@extends('admin/layout');
@section('page_title','Dashboard')
@section('dashboard_select','active')
@section('container')

<span class="d-none">
    {{$typeName=session()->get('typeName')}}
    {{$ADMIN_ID=session()->get('ADMIN_ID')}}
</span>
<style type="text/css">
    .myClass
    {
    background-image: var(--bs-gradient);
    }
</style> 
<?php 
if(isset($_GET['Date_FROM']))
    $Date_FROM=$_GET['Date_FROM'];
else
    $Date_FROM=date('d-m-Y');

if(isset($_GET['Date_TO']))
    $Date_TO=$_GET['Date_TO'];
else
    $Date_TO=date('d-m-Y');
?>



<section class="get_in_touch">
        <h1 class="title">{{$typeName}}  Dashboard </h1>
        <form action="{{route('admin.auth')}}" method="post">
            @csrf
        <div class="container">
         
            <div class="contact-form row">
              
               <div class="form-field col-lg-6">
                
                <input class="submit-btn" type="button" onclick="pendingList_click()" value="List for approval " name="pendingList">
               </div>
              <div class="form-field col-lg-6">
                <input class="submit-btn" type="button" onclick="summarize_click()" value="summarise list" name="summarize">
               </div>
               <div class="form-field col-lg-6">
                
                <input class="submit-btn" type="button" onclick="approveList_click()" value="Approved list" name="approve">
               </div>
               <div class="form-field col-lg-6">
                <input class="submit-btn" type="button" onclick="giftAchieve_click()" value="Gift Achieve list" name="giftAchieve">
               </div>
               
               <div class="form-field col-lg-6">
                
                <input class="submit-btn" type="button" onclick="declineList_click()" value="Declined list" name="declined">
               </div>
               <div class="form-field col-lg-6">
                
                <input class="submit-btn" type="button" onclick="birthDayList_click()" value="Birth Day list" name="declined">
               </div>
               
            </div>
        </div>
    </form>
    
</section>
<script type="text/javascript">
function pendingList_click()
{
    window.location="/admin/CustomerPurchase/pending";
}
function approveList_click()
{
    window.location="/admin/CustomerPurchase/approved";
}

function declineList_click()
{
    window.location="/admin/CustomerPurchase/trash";
}

function giftAchieve_click()
{
    window.location="/admin/Customer/giftAchiever";
}

function birthDayList_click()
{
    window.location="/admin/Customer/birthDayList";
}
function summarize_click()
{
    window.location="/admin/CustomerPurchase/summarize";
}
</script>
@endsection