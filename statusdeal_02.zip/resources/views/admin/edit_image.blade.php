@extends('admin/layout');
@section('page_title','image edit')
@section('Setting_select','active')
@section('container')
<script type="text/javascript">
function readURL(input) {
    
  if (input.files && input.files[0]) {
    var reader = new FileReader();
    
    reader.onload = function(e) {
      $('#ProductImage').attr('src', e.target.result);
    }
    
    reader.readAsDataURL(input.files[0]);
  }
}
</script>
<section class="get_in_touch">
        <h1 class="title">{{Config::get('constants.SITE_NAME')}} Image edit</h1>
        <form action="{{route('image_save')}}" enctype="multipart/form-data" method="post">
            @csrf
        <div class="container">
          @if (session('error'))
<div class="alert alert-danger">{{ session('error') }}</div>
@endif
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Type</label>
              </div>
              <div class="form-field col-lg-4">
                  
                  <select name="img_type" id="img_type" class="input-text font-weight-bold" >
                        <option value=""></option>
                        @foreach($image_types as $list)
                            @if($img_type==$list->id)
                    <option selected value="{{$list->id}}" >{{$list->name}}</option>
                            @else
                    <option value="{{$list->id}}">{{$list->name}}</option>
                            @endif
                        @endforeach
                    </select>
              </div>
              <div class="form-field col-lg-1">
                  
              </div>
              <div class="form-field col-lg-4">
                  
                  

              </div>

            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="caption" class="label">Caption </label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="caption" id="caption" class="input-text" value="{{old('caption')}}">
                  
              </div>
 
              <div class="form-field col-lg-2">
                  <label for="sub_caption" class="label">sub caption</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="sub_caption" id="sub_caption" class="input-text" value="{{old('sub_caption')}}">
                   
              </div>
            </div>
            <div class="row">
              <div class="col-lg-6">
              @error('caption')
                   <div class="alert alert-danger" role="alert">
                    {{$message}}
                    </div>
                    @enderror
              </div>
              <div class="col-lg-6">
              @error('sub_caption')
                   <div class="alert alert-danger" role="alert">
                    {{$message}}
                    </div>
                    @enderror

              </div>
            </div>
            
            <div class="form-group">
                                        <div class="row">
                                            <div class="col-9">
                                                <label for="file" class="control-label mb-1">Image</label>
                                                <input id="filename" name="filename" type="file" accept="image/*" value="{{$filename}}" class="form-control" aria-required="true" aria-invalid="false" onchange="readURL(this)" {{$image_required}}>
                                                    @error('filename')
                                                    <div class="alert alert-danger" role="alert">
                                                    {{$message}}
                                                    </div>
                                                    @enderror
                                                </div>
                                                <div class="col-3">
                                                    @if($filename !='')
                                                         <img id="ProductImage" src="{{asset('/storage/media').'/'.$filename}}" style="width:150px;" alt="{{asset('/storage/media').'/'.$filename}}" />
                                                    @else 
                                                     <img id="ProductImage" src="{{asset('/storage/media').'/NoImage.png'}}" style="width:150px;" alt="{{asset('/storage/media').'/NoImage.png'}}" />
                                                    @endif
                                                    </div>
                                                </div>
                                            </div>
        
            <div class="contact-form row">
              
               <div class="form-field col-lg-6">
                
               </div>
               <div class="form-field col-lg-6">
                <input type="hidden" name="id" value="{{$id}}">
                <input class="submit-btn" type="submit" value="Submit" name="Submit">
               </div>
            </div>
        </div>
      </form>
    </section>

@endsection