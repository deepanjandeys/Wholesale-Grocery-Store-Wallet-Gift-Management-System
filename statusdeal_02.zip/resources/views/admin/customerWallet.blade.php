@extends('admin/layout');
@section('page_title','Customer Wallet')
@section('Report_select','active')
@section('container')
{{$AJAX_ROOT=Config::get('constants.AJAX_ROOT')}}
<style type="text/css">
  .table-responsive {
    max-height:300px;
}
</style>
<section class="get_in_touch">
        <h1 class="title">{{Config::get('constants.SITE_NAME')}} Customer Wallet</h1>
        
        <div class="container">
          <form id="myForm">
        <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="id" class="label">ID</label>
              </div>
              <div class="form-field col-lg-4">
                <input type="search" name="id" placeholder="customer id" class="input-text" value="{{$id}}">
              </div>
              <div class="form-field col-lg-1">
                  <label for="name" class="label">Name</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="search" name="name" placeholder="customer name" class="input-text" value="{{$name}}">
              </div>

            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Mobile</label>
              </div>
              <div class="form-field col-lg-4">
              <input type="search" name="mobile" placeholder="customer mobile" class="input-text" value="{{$mobile}}">
              </div>
              <div class="form-field col-lg-1">
                  <label for="bal_opr" class="label">Balance</label>
              </div>
              <div class="form-field col-lg-1">
                <select name="bal_opr" id="bal_opr" onchange="selMonth_Change()" class="input-text font-weight-bold" >

                        @foreach($operators as $list)
                            @if($bal_opr==$list->name)
                    <option selected value="{{$list->name}}" >{{$list->name}}</option>
                            @else
                    <option value="{{$list->name}}">{{$list->name}}</option>
                            @endif
                        @endforeach
                </select>             

              </div>
              
              <div class="form-field col-lg-3">
              <input type="search" name="balance" placeholder="Wallet Balance" class="input-text" value="{{$balance}}">
              </div>
              <div class="form-field col-lg-1">
                <input type="submit" name="search-btn" class="btn btn-primary" value="search">
              </div>
            </div>
       
            </form>
          </div>
    </section>
    <div class="container">
            <div class="contact-form row">
              <div class="col-lg-12 overflow-scroll">
                go to <a href="{{url('admin/Customer/inActiveList')}}">In Active Customer List</a> &nbsp; go to <a href="{{url('admin/Customer/disApproveList')}}">Disapproved Customer list</a>

               &nbsp; &nbsp; <a href="{{url('admin/Customer/viewNegtiveBalanceWarningList')}}" class="btn btn-secondary" target="_blank">Send Negative Balance warning</a> 
               @if(count($lastMonthAlert)>0)
               {{$lastMonthAlert[0]->name}} / {{$lastMonthAlert[0]->year}}
               <?php echo date('d-M-y H:i:s',strtotime($lastMonthAlert[0]->date_time));?>
               @endif
                <table class="table table-responsive table-dark table-light">
                  <tr> 
                     
                    <th>
                      Cust id
                    </th>
                    <th>
                      Customer Name
                    </th>
                    <th>
                      Mobile No.
                    </th>
                    <th>
                      email
                    </th>
                    <th>
                      Address
                    </th>
                    <th>
                      Balance
                    </th>
                    <th>Action 1</th>
                    <th>Action 2</th>
                  </tr>
                  @if($customers->count()>0)
                  <?php 
                  $today=strtotime(date('d-m-Y'));
                  ?>
                  <tbody>
                                            @foreach($customers as $list)
                                            <tr>
                                           
                                                <td>{{$list->id}}</td>
                                                <td>{{$list->name}}</td>
                                                <td>{{$list->mobile}}</td>
                                                <td>{{$list->email}}</td>
                                                <td>{{$list->address}}</td>
                                                <td id="td{{$list->id}}">{{$list->balance}}</td>
                                                <td>
                                                  
                                                   <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalShowWallet" onclick="getWalletBalance({{$list->id}},1)"> add Wallet Balance</button>
                                                   <div id="divAddBalMsg{{$list->id}}"></div>
                                                </td>
                                                <td>
                                                  <a class="btn btn-warning" target="_blank" href="{{url('admin/Customer/Transactions/')}}/{{$list->id}}">View Transctions</a>
                                                 <!--   <a href="javascript:void(0)" data-toggle="modal" data-target="#exampleModalShowTransactions" onclick="ShowTransactions({{$list->id}})">Mini Statement </a>
                                                 -->
                                                  </div>
                                                </td>
                                                </tr>
                                              @endforeach
                      </tbody>
                      @else
                      <tbody>
                        <tr>
                          <td colspan="10">Nothing to show</td>
                        </tr>
                      </tbody>
                      @endif
                </table>
                
              </div>
            </div>
            
            
        </div>
<!-- Modal -->
<div class="modal fade" id="exampleModalShowWallet" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add/Edit Wallet Balance</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <div id="divTable">please wait</div>
      </div>
      <div class="modal-footer">
        <input type="hidden" id="curPurchaseId" >
        <button type="button" id="btnClose" class="btn btn-secondary" data-dismiss="modal">close</button>
        <button type="button" class="btn btn-primary d-none">Yes</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModalShowTransactions" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" >
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">View Transactions</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <div id="divTableTrans">please wait</div>
      </div>
      <div class="modal-footer">
        <input type="hidden" id="curPurchaseId" >
        <button type="button" id="btnClose" class="btn btn-secondary" data-dismiss="modal">close</button>
        <button type="button" class="btn btn-primary d-none">Yes</button>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
 
function getWalletBalance(id,add,WalletId=0,amount=0) {
    
   $.ajax({
    type: "POST",
    url: '{{$AJAX_ROOT}}/customer/getWalletBalance',
    data: { custId: id,add:add,WalletId:WalletId,amount:amount, _token: '{{csrf_token()}}' },
    success: function (data) 
    {
        //console.log(' ** '+ data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
            $('#divTable').html(obj.str);
            $('#exampleModalLabel').html(obj.action+' Wallet Balance')
            }
        else
        {
            $('#divTable').html('');
            $('#exampleModalLabel').html('Add/Edit Wallet Balance');
        }
    
    },
    error: function (data, textStatus, errorThrown) {
        console.log(data+' '+textStatus+' '+errorThrown);
 
    },
});
}

function ShowTransactions(id) 
{
  //console.log(id);
   $.ajax({
    type: "POST",
    url: '{{$AJAX_ROOT}}/customer/showTransactions',
    data: { custId: id, _token: '{{csrf_token()}}' },
    success: function (data) 
    {
        //console.log(' ** '+ data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
            $('#divTableTrans').html(obj.str);
           
            }
        else
        {
            $('#divTableTrans').html('');
           
        }
    
    },
    error: function (data, textStatus, errorThrown) {
        console.log(data+' '+textStatus+' '+errorThrown);
 
    },
});
}

function AddWalletBalance(id) {

  var AddBalance = $('#AddBalance').val();
  var Remarks =  $('#txtRemarks').val();

  if(AddBalance==undefined)
    {
    return;
    }    
    else
    {
      AddBalance=parseFloat(AddBalance);
    }
    if(isNaN(AddBalance))
      return;
    if(Remarks==undefined)
      Remarks='';
    Remarks = Remarks.trim();

//console.log(id+' '+AddBalance); 
   $.ajax({
    type: "POST",
    url: '{{$AJAX_ROOT}}/customer/addWalletBalance',
    data: { custId: id,AddBalance:AddBalance, Remarks:Remarks ,_token: '{{csrf_token()}}' },
    success: function (data) 
    {
        console.log(' ## '+ data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
            $('#divAddBalMsg'+id).html(obj.msg);    
            $('#td'+id).html(obj.newBalance+'<br><a class="btn-primary" data-toggle="modal" data-target="#exampleModalShowWallet" onclick="getWalletBalance('+obj.id+',0,'+obj.WalletId+','+obj.amount+')"> Edit Wallet Balance</a>');      
          console.log(obj.msg);
        }
        else
        {
            $('#divAddBalMsg'+id).html('');    
        }
      $('#btnClose').click();
    },
    error: function (data, textStatus, errorThrown) {
        console.log(data+' '+textStatus+' '+errorThrown);
 
    },
});
}


function EditWalletBalance(id) {

  var EditBalance = $('#EditBalance').val();
  var WalletId = $('#WalletId').val();
  var Remarks = $('#txtRemarks').val();

  if(EditBalance==undefined)
    {
    return;
    }    
    else
    {
      EditBalance=parseFloat(EditBalance);
    }
    if(isNaN(EditBalance))
      return;

    if(WalletId==undefined)
      WalletId=0;

    if(Remarks==undefined)
      Remarks='';

    Remarks = Remarks.trim();

//console.log('custId '+id+' , EditBalance '+EditBalance+' , WalletId '+WalletId);
   $.ajax({
    type: "POST",
    url: '{{$AJAX_ROOT}}/customer/editWalletBalance',
    data: { custId: id,EditBalance:EditBalance,WalletId:WalletId, Remarks:Remarks,  _token: '{{csrf_token()}}' },
    success: function (data) 
    {
        //console.log(' ## '+ data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
            $('#divAddBalMsg'+id).html(obj.msg);    
            $('#td'+id).html(obj.newBalance+'<br><a class="btn-primary" data-toggle="modal" data-target="#exampleModalShowWallet" onclick="getWalletBalance('+obj.id+',0,'+obj.WalletId+','+obj.amount+')"> Edit Wallet Balance</a>');      
        }
        else
        {
            $('#divAddBalMsg'+id).html('');    
        }
      $('#btnClose').click();
    },
    error: function (data, textStatus, errorThrown) {
        console.log(data+' '+textStatus+' '+errorThrown);
 
    },
});
}
function setRemarks(str)
{
  $('#txtRemarks').val(str);
}
</script>
@endsection