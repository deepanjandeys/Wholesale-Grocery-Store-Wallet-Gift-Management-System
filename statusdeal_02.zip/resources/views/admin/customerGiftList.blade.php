@extends('admin/layout');
@section('page_title','Gift list')
@section('Purchase_select','active')
@section('container')
{{$AJAX_ROOT=Config::get('constants.AJAX_ROOT')}}
<section class="get_in_touch">
        <h1 class="title">{{Config::get('constants.SITE_NAME')}} Gift List</h1>
        
        <div class="container">
          <form>
         <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="month" class="label">Month</label>
              </div>
              <div class="form-field col-lg-4">
                  
                  <select name="month" id="month" onchange="selMonth_Change()" class="input-text font-weight-bold" >
                       
                        @foreach($months as $list)
                            @if($month==$list->id)
                    <option selected value="{{$list->id}}" >{{$list->name}}</option>
                            @else
                    <option value="{{$list->id}}">{{$list->name}}</option>
                            @endif
                        @endforeach
                    </select>
              </div>
              <div class="form-field col-lg-1">
                  <label for="year" class="label">Year</label>
              </div>
              <div class="form-field col-lg-4">
                  
                  <select name="year" id="year" onchange="selMonth_Change()" class="input-text font-weight-bold" >
                        <option value=""></option>
                        @foreach($years as $list)
                            @if($year==$list->value)
                    <option selected >{{$list->value}}</option>
                            @else
                    <option >{{$list->value}}</option>
                            @endif
                        @endforeach
                    </select>

              </div>

            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Search</label>
              </div>
              <div class="form-field col-lg-9">
              <input type="search" name="search" placeholder="customer name/mobile/address" class="input-text" value="{{$search}}">
              </div>
              <div class="form-field col-lg-1">
                <input type="submit" name="search-btn" class="btn btn-primary" value="search">
              </div>
            </div>

            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Date From</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="Date_From" id="Date_From" placeholder="Date From" class="input-text" value="{{$Date_From}}">
              </div>
              <div class="form-field col-lg-1">
                  <label for="year" class="label">To</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="Date_To" id="Date_To" placeholder="Date To" class="input-text" value="{{$Date_To}}">

              </div>

            </div>
            </form>
          </div>
    </section>
    <div class="container">
            <div class="contact-form row">
              <div class="col-lg-12 overflow-scroll">
                <table class="table table-responsive table-dark table-light">
                  <tr> 
                    
                    <th>
                      Date
                    </th>
                    <th>
                      Month
                    </th>
                    <th>
                      Amount
                    </th>
                    
                  </tr>
                  @if(count($giftAchieves)>0)
                  <?php $sum=0;?>
                  <tbody>
                                   @foreach($giftAchieves as $giftAchieve)
                                            @foreach($giftAchieve as $list)
                                            <tr>
                                                <td>{{$list->created_at}}</td>
                                                <td>{{$list->name}}</td>
                                                <td style="text-align:right;">{{number_format($list->basedAmount,2)}}</td>
                                               
                                              </tr>
                                              @endforeach
                                      @endforeach
                      </tbody>
                      @else
                      <tbody>
                        <tr>
                          <td colspan="11">Nothing to show</td>
                        </tr>
                      </tbody>
                      @endif
                </table>
              </div>
              
            </div>
            
            
        </div>
        

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Confirmation to decline</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Purchase entry with id <span id="spnPurId"></span> will be decline
      </div>
      <div class="modal-footer">
        <input type="hidden" id="curPurchaseId" >
        <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
        <button type="button" class="btn btn-primary" onclick="delete_Purchase_Entry()">Yes</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">View Purchase Amount List</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <div id="divTable">please wait</div>
      </div>
      <div class="modal-footer">
        <input type="hidden" id="curPurchaseId" >
        <button type="button" class="btn btn-secondary" data-dismiss="modal">close</button>
        <button type="button" class="btn btn-primary d-none">Yes</button>
      </div>
    </div>
  </div>
</div>
<script language="javascript">
function selMonth_Change()
{
  var m=$('#month').val();
  var y=$('#year').val();
  //var firstDay = new Date(y, m, 1);
  
  if (m<10) 
  {
    m = '0'+m;
  }

  var firstDay = '01-'+m+'-'+y;
  var lastDay = new Date(y, m , 0); //new Date(y, m + 1, 0);
  lastDay = lastDay.getDate()+'-'+m+'-'+y;

  $('#Date_From').val(firstDay);
  $('#Date_To').val(lastDay);

//console.log(firstDay+' '+lastDay);
}
    $('#Date_From').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

    $('#Date_To').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

  function setPurchaseID(id)
  {
    $('#curPurchaseId').val(id);
    $('#spnPurId').html(id);
  }

  function delete_Purchase_Entry()
  {
    var curPurchaseId=$('#curPurchaseId').val();
    window.location="{{url('admin/CustomerPurchase/delete/')}}/"+curPurchaseId;
  }

 
function showViewDetails(custId,month,year) {
   $.ajax({
    type: "POST",
    url: '{{$AJAX_ROOT}}/admin/getViewDetails',
    data: { custId: custId,month,year, _token: '{{csrf_token()}}' },
    success: function (data) 
    {
        //console.log(' ** '+ data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
            $('#divTable').html(obj.str);
           
            }
        else
        {
            $('#divTable').html('');
           
        }
    
    },
    error: function (data, textStatus, errorThrown) {
        console.log(data+' '+textStatus+' '+errorThrown);
 
    },
});
}
</script>
@endsection