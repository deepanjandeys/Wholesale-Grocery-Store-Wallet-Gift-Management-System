@extends('admin/layout');
@section('page_title','Dashboard')
@section('profile_select','active')
@section('container')
{{$AJAX_ROOT=Config::get('constants.AJAX_ROOT')}}
<section class="get_in_touch">
        <h1 class="title">{{Config::get('constants.SITE_NAME')}} Profile Edit</h1>
        <form action="{{route('customer.save_profile')}}" method="post">
            @csrf
        <div class="container">
          @if (session('error'))
<div class="alert alert-danger">{{ session('error') }}</div>
@endif
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="name" class="label">Name </label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="name" id="name" class="input-text" value="{{$name}}">
                  
              </div>

              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Mobile No.</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="number" name="mobile" id="mobile" class="input-text" value="{{$mobile}}" readonly>
                   
              </div>
            </div>
            <div class="row">
              <div class="col-lg-6">
              @error('name')
                   <div class="alert alert-danger" role="alert">
                    {{$message}}
                    </div>
                    @enderror
              </div>
              <div class="col-lg-6">
              @error('mobile')
                   <div class="alert alert-danger" role="alert">
                    {{$message}}
                    </div>
                    @enderror

              </div>
            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="DateOfBirth" class="label">Date Of Birth</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="DateOfBirth" id="DateOfBirth" class="input-text" value="{{$DateOfBirth}}">
                   
              </div>

              <div class="form-field col-lg-2">
                  <label for="password" class="label">Password</label>
              </div>
              <div class="form-field col-lg-4">
          <a href="{{url('customer/password_change')}}/{{$id}}" >Change Password</a>
                  <div id="divPwd{{$id}}"></div>
                </div>
            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="email" class="label">email</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="email" id="email" class="input-text" value="{{$email}}">
                   
              </div>

              <div class="form-field col-lg-2">
                  <label for="gender" class="label">gender</label>
              </div>
              <div class="form-field col-lg-4">
                <?php 
                $a='selected';
                $b='';
                $c='';
                $d='';

                if($gender=='1')
                  $b='selected';
                elseif ($gender=='2') 
                  $c='selected';
                elseif ($gender=='3')
                  $d='selected';
                ?>

                <select name="gender" class="input-text">
                  <option value="0" {{$a}}></option>
                  <option value="1" {{$b}}>Male</option>
                  <option value="2" {{$c}}>Female</option>
                  <option value="3" (($d}}>Other</option>
                </select>
                   
              </div>
            </div>
            <div class="row">
              <div class="col-lg-6">@error('DateOfBirth')
                   <div class="alert alert-danger" role="alert">
                    {{$message}}
                    </div>
                    @enderror
                  </div>
              <div class="col-lg-6">
              @error('password')
                   <div class="alert alert-danger" role="alert">
                    {{$message}}
                    </div>
                    @enderror
                </div>
            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                <label for="address" class="label">Address</label>
              </div>
              <div class="form-field col-lg-10">
                <textarea id="address" name="address" class="input-text">{{$address}}</textarea>
                 
              </div>
            </div>
            <div class="row">
              <div class="col-lg-12">
                @error('address')
                   <div class="alert alert-danger" role="alert">
                    {{$message}}
                    </div>
                    @enderror
              </div>
            </div>
           
            <div class="contact-form row">
              <div class="col-lg-2">Credit Limit</div>
              <div class="col-lg-4">
                {{$credit_limit}}
              </div>
               <div class="form-field col-lg-6 float-end">
                <input type="hidden" name="isApproved" value="{{$isApproved}}">
                <input type="hidden" name="status" value="{{$status}}">
                <input type="hidden" name="id" value="{{$id}}">
                <input class="submit-btn" type="submit" value="Submit" name="Submit">
               </div>
            </div>
        </div>
        
                                            
      </form>
</section>
<script type="text/javascript">

    $('#DateOfBirth').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

<?php if($DateOfBirth=='') { ?>
    $('#DateOfBirth').val('');
<?php 
  }
?>
  
</script>

@endsection