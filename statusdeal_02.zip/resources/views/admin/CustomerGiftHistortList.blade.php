@extends('admin/layout');
@section('page_title','Gift History List')
@section('Report_select','active')
@section('container')
{{$AJAX_ROOT=Config::get('constants.AJAX_ROOT')}}
<section class="get_in_touch">
        <h1 class="title">{{Config::get('constants.SITE_NAME')}} Gift History List</h1>
        
        <div class="container">
          <form>
         <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Month</label>
              </div>
              <div class="form-field col-lg-4">
                  
                  <select name="month" id="month" onchange="selMonth_Change()" class="input-text font-weight-bold" >
                        <option value=""></option>
                        @foreach($months as $list)
                            @if($month==$list->id)
                    <option selected value="{{$list->id}}" >{{$list->name}}</option>
                            @else
                    <option value="{{$list->id}}">{{$list->name}}</option>
                            @endif
                        @endforeach
                    </select>
              </div>
              <div class="form-field col-lg-1">
                  <label for="year" class="label">Year</label>
              </div>
              <div class="form-field col-lg-4">
                  
                  <select name="year" id="year" onchange="selMonth_Change()" class="input-text font-weight-bold" >
                        <option value=""></option>
                        @foreach($years as $list)
                            @if($year==$list->value)
                    <option selected >{{$list->value}}</option>
                            @else
                    <option >{{$list->value}}</option>
                            @endif
                        @endforeach
                    </select>

              </div>

            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Search</label>
              </div>
              <div class="form-field col-lg-9">
              <input type="search" name="search" placeholder="customer name/mobile/address" class="input-text" value="{{$search}}">
              </div>
              <div class="form-field col-lg-1">
                <input type="submit" name="search-btn" class="btn btn-primary" value="search">
              </div>
            </div>

            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Date From</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="Date_From" id="Date_From" placeholder="Date From" class="input-text" value="{{$Date_From}}">
              </div>
              <div class="form-field col-lg-1">
                  <label for="year" class="label">To</label>
              </div>
              <div class="form-field col-lg-4">
                  <input type="text" name="Date_To" id="Date_To" placeholder="Date To" class="input-text" value="{{$Date_To}}">

              </div>

            </div>
            </form>
          </div>
    </section>
    <div class="container">
            <div class="contact-form row">
              <div class="col-lg-12 overflow-scroll">
                <table class="table table-responsive table-dark table-light">
                  <tr> 
                     <th>
                      id
                    </th>
                    <th>
                      Date
                    </th>
                    <th>
                      Month
                    </th>
                    <th>
                      Cust id
                    </th>
                    <th>
                      Customer Name
                    </th>
                    <th>
                      Mobile No.
                    </th>
                    <th>
                      Address
                    </th>
                    <th>
                      Amount
                    </th>
                    <th colspan="2" class="text-center">action</th>
                   
                  </tr>
                  @if($CustomerGift->count()>0)
                
                  <tbody>
                                            @foreach($CustomerGift as $list)
                                            <tr>
                                           
                                                <td>{{$list->id}}</td>
                                                <td>{{$list->created_at}}</td>
                                                <td>{{$list->getMonths->name}}</td>
                                                <td>{{$list->custId}}</td>
                                                <td>{{$list->getCustomers->name}}</td>
                                                <td>{{$list->getCustomers->mobile}}</td>
                                                <td>{{$list->getCustomers->address}}</td>
                                                <td style="text-align: right;">{{number_format($list->basedAmount,2)}}
                                                  </td>
                                                 <td>
                                                    @if($list->status==1)
                                                    
                                                       
                                                    <a href="{{url('admin/CustomerGift/status/0/')}}/{{$list->id}}">
                                                    <button type="button" class="btn btn-warning">Disapprove</button>
                                                    </a>
                                                   
                                                    @endif
                                                    
                                                </td>
                                                 
                                                <td>
                                                  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal1" onclick="showViewDetails({{$list->custId}},{{$month}},{{$year}})"> View Detail</button>
                                                </td>
                                               
                                              </tr>
                                              @endforeach
                                              
                      </tbody>
                      @else
                      <tbody>
                        <tr>
                          <td colspan="10">Nothing to show</td>
                        </tr>
                      </tbody>
                      @endif
                </table>
              </div>
              {{
                  $CustomerGift->links();
              }}
            </div>
            
            
        </div>
<!-- Modal -->
<div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">View Purchase Amount List</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <div id="divTable">please wait</div>
      </div>
      <div class="modal-footer">
        <input type="hidden" id="curPurchaseId" >
        <button type="button" class="btn btn-secondary" data-dismiss="modal">close</button>
        <button type="button" class="btn btn-primary d-none">Yes</button>
      </div>
    </div>
  </div>
</div>
<script>
function selMonth_Change()
{
  var m=$('#month').val();
  var y=$('#year').val();
  //var firstDay = new Date(y, m, 1);
  
  if (m<10) 
  {
    m = '0'+m;
  }

  var firstDay = '01-'+m+'-'+y;
  var lastDay = new Date(y, m , 0); //new Date(y, m + 1, 0);
  lastDay = lastDay.getDate()+'-'+m+'-'+y;

  $('#Date_From').val(firstDay);
  $('#Date_To').val(lastDay);

//console.log(firstDay+' '+lastDay);
}
    $('#Date_From').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

    $('#Date_To').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });


function showViewDetails(custId,month,year) {
   $.ajax({
    type: "POST",
    url: '{{$AJAX_ROOT}}/admin/getViewDetails',
    data: { custId: custId,month,year, _token: '{{csrf_token()}}' },
    success: function (data) 
    {
        //console.log(' ** '+ data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
            $('#divTable').html(obj.str);
           
            }
        else
        {
            $('#divTable').html('');
           
        }
    
    },
    error: function (data, textStatus, errorThrown) {
        console.log(data+' '+textStatus+' '+errorThrown);
 
    },
});
}
  </script>

@endsection