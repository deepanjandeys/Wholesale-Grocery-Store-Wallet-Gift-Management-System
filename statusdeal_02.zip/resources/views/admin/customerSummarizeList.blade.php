@extends('admin/layout');
@section('page_title','summarize List')
@section('Report_select','active')
@section('container')
{{$AJAX_ROOT=Config::get('constants.AJAX_ROOT')}}
<section class="get_in_touch">
        <h1 class="title">{{Config::get('constants.SITE_NAME')}} Summarize List</h1>
        
        <div class="container">
          <form>
         <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Month</label>
              </div>
              <div class="form-field col-lg-4">
                  
                  <select name="month" id="month" class="input-text font-weight-bold" >
                        <option value=""></option>
                        @foreach($months as $list)
                            @if($month==$list->id)
                    <option selected value="{{$list->id}}" >{{$list->name}}</option>
                            @else
                    <option value="{{$list->id}}">{{$list->name}}</option>
                            @endif
                        @endforeach
                    </select>
              </div>
              <div class="form-field col-lg-1">
                  <label for="year" class="label">Year</label>
              </div>
              <div class="form-field col-lg-4">
                  
                  <select name="year" id="year" class="input-text font-weight-bold" >
                        <option value=""></option>
                        @foreach($years as $list)
                            @if($year==$list->value)
                    <option selected >{{$list->value}}</option>
                            @else
                    <option >{{$list->value}}</option>
                            @endif
                        @endforeach
                    </select>

              </div>

            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Search</label>
              </div>
              <div class="form-field col-lg-9">
              <input type="search" name="search" placeholder="customer name/mobile/address" class="input-text" value="{{$search}}">
              </div>
              <div class="form-field col-lg-1">
                <input type="submit" name="search-btn" class="btn btn-primary" value="search">
              </div>
            </div>
            </form>
          </div>
    </section>
    <div class="container">
            <div class="contact-form row">
              <div class="col-lg-12 overflow-scroll">
                <table class="table table-responsive table-dark table-light">
                  <tr> 
                     
                    <th>
                      Cust id
                    </th>
                    <th>
                      Customer Name
                    </th>
                    <th>
                      Mobile No.
                    </th>
                    <th>
                      Address
                    </th>
                    <th>
                      Amount
                    </th>
                    
                    <th>
                      Gift Given in this Month
                    </th>
                    <th></th>
                  </tr>
                  @if($summarize->count()>0)
                  <tbody>
                                            @foreach($summarize as $list)
                                            <tr>
                                           
                                                <td>{{$list->custId}}</td>
                                                <td>{{$list->name}}</td>
                                                <td>{{$list->mobile}}</td>
                                                <td>{{$list->address}}</td>
                                                <td style="text-align:right;">{{number_format($list->sumAmt,2)}}</td>
                                                
                                                  <td>
                                                  <?php 
                                            $prev_gifts = DB::table('customer_gifts')
                                    ->select('basedAmount','created_at')
                                    ->where('customer_gifts.custId','=', $list->custId)
                                    ->where('customer_gifts.monthId','=', $month)                    ->get();
                                    foreach($prev_gifts as $list1)
                                    {
                                      echo 'on '.date('d-m-Y',strtotime($list1->created_at)).' @ <span class="bg-primary" title="when total amount was ">'.number_format($list1->basedAmount,2).'</span> <br>';
                                    }
                                                  ?>
                                                </td>
                                                <td>
                                                  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal1" onclick="showViewDetails({{$list->custId}},{{$month}},{{$year}})"> View Detail</button>
                                                </td>
                                              </tr>
                                              @endforeach
                      </tbody>
                      @else
                      <tbody>
                        <tr>
                          <td colspan="10">Nothing to show</td>
                        </tr>
                      </tbody>
                      @endif
                </table>
              </div>
            </div>
            
            
        </div>
<!-- Modal -->
<div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">View Purchase Amount List</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <div id="divTable">please wait</div>
      </div>
      <div class="modal-footer">
        <input type="hidden" id="curPurchaseId" >
        <button type="button" class="btn btn-secondary" data-dismiss="modal">close</button>
        <button type="button" class="btn btn-primary d-none">Yes</button>
      </div>
    </div>
  </div>
</div>
<script>

    $('#DateOfBirth').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

    function showViewDetails(custId,month,year) {
   $.ajax({
    type: "POST",
    url: '{{$AJAX_ROOT}}/admin/getViewDetails',
    data: { custId: custId,month,year, _token: '{{csrf_token()}}' },
    success: function (data) 
    {
        //console.log(' ** '+ data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
            $('#divTable').html(obj.str);
           
            }
        else
        {
            $('#divTable').html('');
           
        }
    
    },
    error: function (data, textStatus, errorThrown) {
        console.log(data+' '+textStatus+' '+errorThrown);
 
    },
});
}
  </script>
@endsection