@extends('admin/layout');
@section('page_title','images List')
@section('Setting_select','active')
@section('container')

<section class="get_in_touch">
        <h1 class="title">{{Config::get('constants.SITE_NAME')}} Images List</h1>
        
        <div class="container">
          <form id="myForm">
         <div class="contact-form row">
              <div class="form-field col-lg-2">
                  <label for="mobile" class="label">Type</label>
              </div>
              <div class="form-field col-lg-4">
                  
                  <select name="type" id="type" class="input-text font-weight-bold" >
                        <option value=""></option>
                        @foreach($image_types as $list)
                            @if($img_type==$list->id)
                    <option selected value="{{$list->id}}" >{{$list->name}}</option>
                            @else
                    <option value="{{$list->id}}">{{$list->name}}</option>
                            @endif
                        @endforeach
                    </select>
              </div>
              <div class="form-field col-lg-1">
                  
              </div>
              <div class="form-field col-lg-4">
              </div>

            </div>

            
            </form>
          </div>
    </section>
    <div class="container">
            <div class="contact-form row">
              <div class="col-lg-12 overflow-scroll">
                
<a href="{{url('admin/images/list/')}}/{{$img_type}}" >
<button type="button" class="btn btn-success">Go to image</button>
</a>
                <table class="table table-responsive table-dark table-light">
                  
                  @if($Images->count()>0)
                  <?php 
                  $today=strtotime(date('d-m-Y'));
                  ?>
                  <tbody>
                                            @foreach($Images as $list)
                                                <tr>
                                                <td>id</td>
                                                <th>{{$list->id}}</th>
                                                <td rowspan="7">
                                                    <img src="{{asset('/storage/media').'/'.$list->filename}}" alt="{{asset('/storage/media').'/'.$list->filename}}" style="width:350px;" />
                                                </td>
                                                <td rowspan="6">
                                                    <a href="{{url('admin/images/restore/')}}/{{$list->img_type}}/{{$list->id}}">
                                                    <button type="button" class="btn btn-success">Restore</button>
                                                    </a>
                                                    <a href="{{url('admin/images/forceDelete/')}}/{{$list->img_type}}/{{$list->id}}">
                                                    <button type="button" class="btn btn-danger">Delete</button>
                                                    </a>
                                                </td>
                                                
                                      
                                </tr>
                                <tr>
                                    <td>Caption</td>
                                    <th>{{$list->caption}}</th>
                                </tr>
                                <tr>
                                    <td>sub-caption</td>
                                    <th>{{$list->sub_caption}}</th>
                                </tr>
                                              @endforeach
                      </tbody>
                      @else
                      <tbody>
                        <tr>
                          <td colspan="10">Nothing to show</td>
                        </tr>
                      </tbody>
                      @endif
                </table>
                
              </div>
            </div>
            
            
        </div>

@endsection