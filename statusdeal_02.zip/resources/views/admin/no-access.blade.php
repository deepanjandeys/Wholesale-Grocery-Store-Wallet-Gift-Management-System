@extends('admin/layout');
@section('page_title','Dashboard')
@section('dashboard_select','active')
@section('container')
<span class="d-none">
    {{$typeName=session()->get('typeName')}}
</span>

	<div class="row">
			<h2 class="title-1 m-b-10">{{Config::get('constants.SITE_NAME')}} {{$typeName}}  
            No access </h2>

        <div class="col-lg-6 d-none">
            <div class="au-card--no-shadow au-card--no-pad m-b-40">
     		</div>
         </div>
     </div>
@endsection