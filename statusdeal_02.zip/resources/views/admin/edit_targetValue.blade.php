@extends('admin/layout');
@section('page_title','Target set vaue')
@section('Setting_select','active')
@section('container')

<section class="get_in_touch">
        <h1 class="title">{{Config::get('constants.SITE_NAME')}} set target vaue</h1>
        <form action="{{route('admin.targetSet')}}" method="post">
            @csrf
        <div class="container">
           @if (session('error'))
<div class="alert alert-danger">{{ session('error') }}</div>
@endif
            <div class="contact-form row">
              <div class="form-field col-lg-4">
                  <label for="Value" class="label">Target Value</label>
              </div>
              <div class="form-field col-lg-8">
                  <input type="text" name="Value" id="Value" class="input-text" value="{{$Value}}" >
              </div>
            </div>
            
            <div class="contact-form row">
              
               <div class="form-field col-lg-6">
                
               </div>
               <div class="form-field col-lg-6">
                <input class="submit-btn" type="submit" value="Save" name="Save">
               </div>
            </div>
        </div>
      </form>
    </section>
@endsection