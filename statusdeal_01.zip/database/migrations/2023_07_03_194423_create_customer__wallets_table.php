<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCustomerWalletsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('customer__wallets', function (Blueprint $table) {
            $table->id(); 
            $table->integer('custId');
            $table->float('amount');
            $table->float('curBalance');
            $table->tinyInteger('tranType');
            $table->string('remarks',20);
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('customer__wallets');
    }
}
